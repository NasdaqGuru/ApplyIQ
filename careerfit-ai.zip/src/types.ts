export type WorkArrangement = 'remote' | 'hybrid' | 'onsite' | 'any';

export type ApplicationStatus =
  | 'Interested'
  | 'Analyzing'
  | 'Resume Ready'
  | 'Applied'
  | 'Interview'
  | 'Final Round'
  | 'Offer'
  | 'Rejected'
  | 'Withdrawn';

export type RequirementClassification =
  | 'REQUIRED'
  | 'STRONGLY PREFERRED'
  | 'PREFERRED'
  | 'IMPLIED'
  | 'OPTIONAL';

export type RequirementCategory =
  | 'Leadership'
  | 'Management'
  | 'Finance'
  | 'Accounting'
  | 'Analytics'
  | 'Technology'
  | 'Strategy'
  | 'Operations'
  | 'Communication'
  | 'Project Management'
  | 'Regulatory/Compliance'
  | 'Education'
  | 'Certification'
  | 'Industry Knowledge'
  | 'People Management'
  | 'Technical Tools'
  | 'Other';

export type MatchClassification =
  | 'EXACT MATCH'
  | 'STRONG MATCH'
  | 'TRANSFERABLE MATCH'
  | 'PARTIAL MATCH'
  | 'WEAK MATCH'
  | 'NOT FOUND';

export interface WorkExperience {
  id: string;
  title: string;
  company: string;
  location?: string;
  startDate: string;
  endDate: string;
  isCurrent?: boolean;
  bullets: string[];
  technologies?: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  field: string;
  institution: string;
  graduationYear: string;
}

export interface CertificationItem {
  id: string;
  name: string;
  issuer: string;
  year?: string;
}

export interface ProjectItem {
  id: string;
  name: string;
  description: string;
  url?: string;
  technologies?: string[];
}

export interface CandidateProfile {
  id?: string;
  fullName: string;
  email: string;
  phone: string;
  location: string;
  linkedinUrl?: string;
  portfolioUrl?: string;
  websiteUrl?: string;
  headline: string;
  summary: string;
  targetJobTitles: string[];
  targetSalary?: string;
  targetJobLevels: string[];
  preferredIndustries: string[];
  workArrangement: WorkArrangement;
  skills: string[];
  experience: WorkExperience[];
  education: EducationItem[];
  certifications: CertificationItem[];
  projects: ProjectItem[];
  rawResumeText: string;
  lastUpdated: string;
}

export interface JobPostingData {
  id?: string;
  jobTitle: string;
  employer: string;
  department?: string;
  location?: string;
  state?: string;
  numberOfOpenings?: number;
  applicantCount?: number;
  workArrangement?: string;
  salaryRange?: string;
  employmentType?: string;
  jobLevel?: string;
  reportingRelationship?: string;
  jobSummary?: string;
  responsibilities?: string[];
  minimumQualifications?: string[];
  preferredQualifications?: string[];
  requiredSkills?: string[];
  preferredSkills?: string[];
  educationRequirements?: string;
  certifications?: string[];
  technologyRequirements?: string[];
  leadershipRequirements?: string;
  yearsOfExperience?: string;
  industryExperience?: string;
  financialOperationalScope?: string;
  peopleManagementScope?: string;
  keywords?: string[];
  repeatedKeywords?: { word: string; count: number }[];
  applicationDeadline?: string;
  sourceUrl?: string;
  url?: string;
  rawDescription?: string;
  description?: string;
}


export interface JobRequirement {
  id: string;
  requirement: string;
  category: RequirementCategory;
  classification: RequirementClassification;
  importance: number; // 1-10
  candidateEvidence: string;
  matchLevel: MatchClassification;
  atsImpact: string;
  recommendedAction: string;
}

export interface ATSScoreBreakdownCategory {
  score: number;
  weight: number;
  explanation: string;
}

export interface ATSScorecard {
  ats_original: number;
  ats_tailored: number;
  improvement_points: number;
  improvement_explanation: string[];
  breakdown: {
    required_qualifications: ATSScoreBreakdownCategory;
    core_responsibilities: ATSScoreBreakdownCategory;
    skills_competencies: ATSScoreBreakdownCategory;
    job_title_seniority: ATSScoreBreakdownCategory;
    tools_systems_tech: ATSScoreBreakdownCategory;
    education_certifications: ATSScoreBreakdownCategory;
    industry_domain: ATSScoreBreakdownCategory;
    ats_keyword_coverage: ATSScoreBreakdownCategory;
  };
  strong_matches: string[];
  partial_matches: string[];
  missing_requirements: string[];
  missing_high_value_keywords: string[];
  potential_ats_risks: string[];
}

export interface QualificationMatch {
  score: number; // 0-100
  assessment: string;
  factors: { name: string; score: number; note: string }[];
}

export interface InterviewCompetitiveness {
  score: number; // 0-100
  tier:
    | 'Exceptional alignment'
    | 'Very strong'
    | 'Strong'
    | 'Competitive but gaps exist'
    | 'Moderate'
    | 'Significant mismatch';
  differentiating_factors: string[];
  risk_factors: string[];
}

export interface ApplicationOutlook {
  rating: 'EXCEPTIONAL' | 'VERY STRONG' | 'STRONG' | 'MODERATE' | 'WEAK' | 'MAJOR GAPS';
  range: string; // e.g. "55–70%"
  disclaimer: string;
}

export interface DealBreaker {
  id: string;
  severity: 'Critical' | 'Significant' | 'Minor';
  issue: string;
  impact: string;
  mitigationStrategy: string;
}

export interface CompetitiveAdvantage {
  id: string;
  advantage: string;
  candidateEvidence: string;
  employerValue: string;
  resumePlacement: string;
  coverLetterPlacement: string;
  interviewTalkingPoint: string;
}

export interface GapBridgingItem {
  id: string;
  missingOrPartialRequirement: string;
  transferableExperience: string;
  truthfulPositioning: string;
  guardrailNote: string;
}

export interface ATSKeywordItem {
  keyword: string;
  category:
    | 'Already Present'
    | 'Present but Underused'
    | 'Missing but Supported'
    | 'Missing and NOT Supported';
  jobCount: number;
  originalCount: number;
  tailoredCount: number;
  recommendation: string;
}

export interface HiringManagerView {
  whyInterview: string[];
  questionsAndConcerns: string[];
  whatMakesStronger: string[];
}

export interface Recruiter10SecondTest {
  continueReading: 'YES' | 'MAYBE' | 'NO';
  keyTakeaways: string[];
  firstImpression: string;
}

export interface ApplicationStrategy {
  recommendation:
    | 'APPLY — HIGH PRIORITY'
    | 'APPLY'
    | 'APPLY WITH CAUTION'
    | 'LOW PRIORITY'
    | 'NOT RECOMMENDED';
  strategicRationale: string;
  top3Changes: string[];
}

export interface TruthfulnessGuardrail {
  verified: { section: string; text: string; evidence: string }[];
  reworded: { section: string; text: string; originalFact: string }[];
  inferredNeedsApproval: { section: string; text: string; reason: string }[];
  unsupportedExcluded: { item: string; reason: string }[];
}

export interface ATSFormatQAItem {
  item: string;
  status: 'PASS' | 'WARN' | 'FAIL';
  note: string;
}

export interface ATSFormatQA {
  status: 'PASS' | 'REVIEW';
  score: number;
  checks: ATSFormatQAItem[];
}

export interface TailoredBullet {
  id: string;
  originalText: string;
  tailoredText: string;
  reason: string;
  status: 'accepted' | 'rejected' | 'original' | 'custom';
  truthStatus: 'Verified' | 'Reworded' | 'Inferred';
}

export interface TailoredExperience {
  id: string;
  originalCompany: string;
  originalTitle: string;
  tailoredTitle?: string;
  dates: string;
  location?: string;
  bullets: TailoredBullet[];
}

export interface TailoredResume {
  headline: string;
  summary: string;
  coreCompetencies: string[]; // 10-16
  selectedAchievements: string[]; // 3-6
  experience: TailoredExperience[];
  education: Array<{ degree: string; field: string; institution: string; year: string }>;
  certifications: Array<{ name: string; issuer: string; year?: string }>;
  technicalSkills: string[];
}

export interface CoverLetter {
  opening: string;
  employerNeed: string;
  candidateEvidence: string;
  differentiator: string;
  closing: string;
  fullText: string;
}

export interface StarStory {
  situation: string;
  task: string;
  action: string;
  result: string;
}

export interface InterviewQuestionItem {
  question: string;
  category: string;
  whyAsked: string;
  recommendedStrategy: string;
  candidateStarStory: StarStory;
}

export interface InterviewPreparation {
  likelyQuestions: InterviewQuestionItem[];
  questionsToAsk: string[];
  intro30Sec: string;
  tellMeAboutYourself90Sec: string;
  whyThisOrganization: string;
  whyThisPosition: string;
  whyHireYou: string;
  executiveThemes: string[];
}

export interface AnalysisConfidence {
  level: 'HIGH' | 'MEDIUM' | 'LOW';
  reasons: string[];
}

export interface FullJobAnalysis {
  id: string;
  analyzedAt: string;
  job: JobPostingData;
  scores: {
    ats: ATSScorecard;
    qualification: QualificationMatch;
    interview: InterviewCompetitiveness;
    outlook: ApplicationOutlook;
    confidence: AnalysisConfidence;
  };
  executiveAssessment: string;
  whyYouMatch: string[];
  whatCouldHurt: string[];
  howToImprove: string[];
  requirements: JobRequirement[];
  keywords: ATSKeywordItem[];
  dealBreakers: DealBreaker[];
  competitiveAdvantages: CompetitiveAdvantage[];
  gapBridging: GapBridgingItem[];
  hiringManagerView: HiringManagerView;
  recruiterTest: Recruiter10SecondTest;
  applicationStrategy: ApplicationStrategy;
  tailoredResume: TailoredResume;
  coverLetter: CoverLetter;
  interviewPrep: InterviewPreparation;
  truthfulnessGuardrail: TruthfulnessGuardrail;
  atsFormatQA: ATSFormatQA;
}

export interface SavedApplication {
  id: string;
  company: string;
  position: string;
  url?: string;
  dateAnalyzed: string;
  status: ApplicationStatus;
  priority: 'High' | 'Medium' | 'Low';
  notes: string;
  opportunityRanking: number; // 0-100
  originalAtsScore: number;
  tailoredAtsScore: number;
  qualificationScore: number;
  interviewScore: number;
  analysis: FullJobAnalysis;
}

export interface ComparisonJobSummary {
  id: string;
  company: string;
  position: string;
  location?: string;
  salary?: string;
  seniority?: string;
  atsMatch: number;
  qualificationMatch: number;
  interviewCompetitiveness: number;
  majorGaps: string[];
  competitiveAdvantages: string[];
  careerGrowthPotential: string;
}

export interface JobComparisonResult {
  jobs: ComparisonJobSummary[];
  bestStrategicFit: {
    jobId: string;
    company: string;
    position: string;
    reasoning: string;
    strategicTakeaways: string[];
  };
}

export interface CareerSkillFrequency {
  skill: string;
  percentage: number;
  count: number;
  statusInProfile: 'Strong' | 'Partial' | 'Missing';
  recommendation: string;
}

export interface CareerLearningInsights {
  analyzedJobsCount: number;
  roleProfilesAnalyzed: string[];
  frequentlyRequestedSkills: CareerSkillFrequency[];
  skillsWorthStrengthening: Array<{
    skill: string;
    marketDemand: string;
    currentEvidence: string;
    learningAction: string;
    roiImpact: string;
  }>;
  emergingMarketThemes: string[];
  strategicCareerAdvice: string[];
}

export interface SavedOpportunity {
  id: string;
  jobId: string;
  analysisId: string;
  jobTitle: string;
  company: string;
  location: string;
  state?: string;
  numberOfOpenings?: number;
  applicantCount?: number;
  salary?: string;
  originalScore: number;
  tailoredScore: number;
  outlook: string;
  status: 'Discovered' | 'Tailoring' | 'Applied' | 'Interviewing' | 'Offer' | 'Archived';
  priority: 'High' | 'Medium' | 'Low';
  createdAt: string;
  updatedAt: string;
}

export type CareerInsightSummary = CareerLearningInsights;
export type JobPosting = JobPostingData;


