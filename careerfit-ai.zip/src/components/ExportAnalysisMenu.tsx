import React, { useState, useRef, useEffect } from 'react';
import {
  Download,
  FileText,
  Copy,
  Check,
  Printer,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { FullJobAnalysis, CandidateProfile } from '../types';
import { exportAnalysisToPdf, copyAnalysisToClipboard } from '../utils/exportAnalysis';

interface ExportAnalysisMenuProps {
  analysis: FullJobAnalysis | null;
  profile?: CandidateProfile;
}

export const ExportAnalysisMenu: React.FC<ExportAnalysisMenuProps> = ({
  analysis,
  profile,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  if (!analysis) return null;

  const handleCopyClipboard = async () => {
    const success = await copyAnalysisToClipboard(analysis, profile);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
      setIsOpen(false);
    }
  };

  const handleDownloadPdf = () => {
    setIsExportingPdf(true);
    try {
      exportAnalysisToPdf(analysis, profile);
    } catch (e) {
      console.error(e);
    } finally {
      setIsExportingPdf(false);
      setIsOpen(false);
    }
  };

  const handlePrint = () => {
    setIsOpen(false);
    window.print();
  };

  return (
    <div className="relative inline-block text-left" ref={menuRef}>
      <button
        id="btn-top-export-analysis"
        onClick={() => setIsOpen(!isOpen)}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xs transition active:scale-98"
        title="Export or Copy Analysis"
        aria-expanded={isOpen}
      >
        {copied ? (
          <Check className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
        ) : (
          <Download className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
        )}
        <span>{copied ? 'Copied!' : 'Export'}</span>
        <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-1.5 w-60 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xl py-1.5 z-50 text-xs font-sans animate-in fade-in zoom-in-95 duration-100">
          <div className="px-3 py-1.5 border-b border-slate-100 dark:border-slate-800">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Export Dossier
            </span>
            <span className="text-[11px] font-medium text-slate-700 dark:text-slate-300 truncate block">
              {analysis.job.jobTitle}
            </span>
          </div>

          <div className="py-1">
            {/* Option 1: Download PDF */}
            <button
              onClick={handleDownloadPdf}
              disabled={isExportingPdf}
              className="w-full px-3 py-2 text-left flex items-center gap-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/80 text-slate-700 dark:text-slate-200 transition group"
            >
              <div className="w-6 h-6 rounded bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center flex-shrink-0 group-hover:bg-blue-100 dark:group-hover:bg-blue-900/60">
                <FileText className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-xs text-slate-900 dark:text-white">
                  Download PDF Report
                </div>
                <div className="text-[10px] text-slate-400">
                  Full scorecard, matrix & interview prep
                </div>
              </div>
            </button>

            {/* Option 2: Copy to Clipboard */}
            <button
              onClick={handleCopyClipboard}
              className="w-full px-3 py-2 text-left flex items-center gap-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/80 text-slate-700 dark:text-slate-200 transition group"
            >
              <div className="w-6 h-6 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center flex-shrink-0 group-hover:bg-slate-200 dark:group-hover:bg-slate-700">
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-green-600" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </div>
              <div className="flex-1">
                <div className="font-semibold text-xs text-slate-900 dark:text-white">
                  {copied ? 'Copied to Clipboard!' : 'Copy to Clipboard'}
                </div>
                <div className="text-[10px] text-slate-400">
                  Formatted Markdown analysis summary
                </div>
              </div>
            </button>

            {/* Option 3: Print */}
            <button
              onClick={handlePrint}
              className="w-full px-3 py-2 text-left flex items-center gap-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/80 text-slate-700 dark:text-slate-200 transition group"
            >
              <div className="w-6 h-6 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center flex-shrink-0 group-hover:bg-slate-200 dark:group-hover:bg-slate-700">
                <Printer className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-xs text-slate-900 dark:text-white">
                  Print Analysis View
                </div>
                <div className="text-[10px] text-slate-400">
                  Send current view to system printer
                </div>
              </div>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
