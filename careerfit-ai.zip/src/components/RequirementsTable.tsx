import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  CheckCircle2,
  AlertCircle,
  Clock,
  Zap,
} from 'lucide-react';
import { JobRequirement, MatchClassification, RequirementClassification } from '../types';

interface RequirementsTableProps {
  requirements: JobRequirement[];
}

export const RequirementsTable: React.FC<RequirementsTableProps> = ({ requirements }) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedMatch, setSelectedMatch] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'importance' | 'match' | 'category' | 'requirement'>('importance');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const categories = useMemo(() => {
    const set = new Set<string>();
    requirements.forEach((r) => r.category && set.add(r.category));
    return ['ALL', ...Array.from(set)];
  }, [requirements]);

  const matchRank: Record<MatchClassification, number> = {
    'EXACT MATCH': 6,
    'STRONG MATCH': 5,
    'TRANSFERABLE MATCH': 4,
    'PARTIAL MATCH': 3,
    'WEAK MATCH': 2,
    'NOT FOUND': 1,
  };

  const filteredAndSorted = useMemo(() => {
    return requirements
      .filter((req) => {
        const matchesSearch =
          !search ||
          req.requirement.toLowerCase().includes(search.toLowerCase()) ||
          req.candidateEvidence.toLowerCase().includes(search.toLowerCase()) ||
          req.category.toLowerCase().includes(search.toLowerCase());

        const matchesCategory = selectedCategory === 'ALL' || req.category === selectedCategory;
        const matchesMatch = selectedMatch === 'ALL' || req.matchLevel === selectedMatch;

        return matchesSearch && matchesCategory && matchesMatch;
      })
      .sort((a, b) => {
        let diff = 0;
        if (sortBy === 'importance') {
          diff = (a.importance || 0) - (b.importance || 0);
        } else if (sortBy === 'match') {
          diff = (matchRank[a.matchLevel] || 0) - (matchRank[b.matchLevel] || 0);
        } else if (sortBy === 'category') {
          diff = a.category.localeCompare(b.category);
        } else {
          diff = a.requirement.localeCompare(b.requirement);
        }
        return sortDirection === 'desc' ? -diff : diff;
      });
  }, [requirements, search, selectedCategory, selectedMatch, sortBy, sortDirection]);

  const getMatchBadge = (level: MatchClassification) => {
    switch (level) {
      case 'EXACT MATCH':
      case 'STRONG MATCH':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-green-50 dark:bg-green-950/40 text-green-700 dark:text-green-300 border border-green-100 dark:border-green-800">
            <CheckCircle2 className="w-2.5 h-2.5 text-green-600 dark:text-green-400" />
            {level}
          </span>
        );
      case 'TRANSFERABLE MATCH':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
            <Zap className="w-2.5 h-2.5 text-blue-600 dark:text-blue-400" />
            {level}
          </span>
        );
      case 'PARTIAL MATCH':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-100 dark:border-amber-800">
            <Clock className="w-2.5 h-2.5 text-amber-600 dark:text-amber-400" />
            {level}
          </span>
        );
      case 'WEAK MATCH':
      case 'NOT FOUND':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-800">
            <AlertCircle className="w-2.5 h-2.5 text-rose-600 dark:text-rose-400" />
            {level}
          </span>
        );
    }
  };

  const getClassificationBadge = (cls: RequirementClassification) => {
    switch (cls) {
      case 'REQUIRED':
        return (
          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-rose-50 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-800">
            Required
          </span>
        );
      case 'STRONGLY PREFERRED':
        return (
          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-purple-50 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 border border-purple-100 dark:border-purple-800">
            Strongly Preferred
          </span>
        );
      case 'PREFERRED':
        return (
          <span className="px-1.5 py-0.5 rounded text-[9px] font-medium bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
            Preferred
          </span>
        );
      case 'IMPLIED':
        return (
          <span className="px-1.5 py-0.5 rounded text-[9px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
            Implied
          </span>
        );
      case 'OPTIONAL':
      default:
        return (
          <span className="px-1.5 py-0.5 rounded text-[9px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-500">
            Optional
          </span>
        );
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden flex flex-col font-sans">
      {/* Header & Controls */}
      <div className="p-5 border-b border-slate-100 dark:border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Requirement Matrix & Evidence Heatmap</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-semibold border border-blue-100 dark:border-blue-800/60">
                {requirements.length} Requirements
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Comprehensive side-by-side evidence audit. No skills are assumed without factual backing.
            </p>
          </div>

          {/* Search box */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search requirements or evidence..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-slate-400 font-medium flex items-center gap-1 text-[11px]">
            <Filter className="w-3 h-3" /> Category:
          </span>
          <div className="flex flex-wrap gap-1 overflow-x-auto pb-1 max-w-full">
            {categories.slice(0, 10).map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2 py-1 rounded-md text-[11px] font-medium transition ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="ml-auto flex items-center gap-2">
            <span className="text-slate-400 font-medium text-[11px]">Match:</span>
            <select
              value={selectedMatch}
              onChange={(e) => setSelectedMatch(e.target.value)}
              className="text-[11px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-2 py-1 text-slate-700 dark:text-slate-300"
            >
              <option value="ALL">All Matches</option>
              <option value="EXACT MATCH">Exact Match</option>
              <option value="STRONG MATCH">Strong Match</option>
              <option value="TRANSFERABLE MATCH">Transferable Match</option>
              <option value="PARTIAL MATCH">Partial Match</option>
              <option value="NOT FOUND">Not Found / Missing</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-100 dark:border-slate-800">
            <tr>
              <th
                onClick={() => {
                  if (sortBy === 'requirement') {
                    setSortDirection((d) => (d === 'asc' ? 'desc' : 'asc'));
                  } else {
                    setSortBy('requirement');
                    setSortDirection('asc');
                  }
                }}
                className="p-3.5 cursor-pointer hover:text-blue-600 transition"
              >
                <div className="flex items-center gap-1">
                  <span>Requirement & Category</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>

              <th
                onClick={() => {
                  if (sortBy === 'importance') {
                    setSortDirection((d) => (d === 'asc' ? 'desc' : 'asc'));
                  } else {
                    setSortBy('importance');
                    setSortDirection('desc');
                  }
                }}
                className="p-3.5 text-center cursor-pointer hover:text-blue-600 transition w-24"
              >
                <div className="flex items-center justify-center gap-1">
                  <span>Importance</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>

              <th className="p-3.5 min-w-[240px]">
                Candidate Evidence in Master Profile
              </th>

              <th
                onClick={() => {
                  if (sortBy === 'match') {
                    setSortDirection((d) => (d === 'asc' ? 'desc' : 'asc'));
                  } else {
                    setSortBy('match');
                    setSortDirection('desc');
                  }
                }}
                className="p-3.5 cursor-pointer hover:text-blue-600 transition w-36"
              >
                <div className="flex items-center gap-1">
                  <span>Match Level</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>

              <th className="p-3.5 min-w-[200px]">
                Recommended Action & Positioning
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredAndSorted.map((req) => {
              const isMissing = req.matchLevel === 'NOT FOUND' || req.matchLevel === 'WEAK MATCH';
              return (
                <tr
                  key={req.id}
                  className={`hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition ${
                    isMissing ? 'bg-rose-50/20 dark:bg-rose-950/10' : ''
                  }`}
                >
                  {/* Requirement & Classification */}
                  <td className="p-3.5 align-top">
                    <div className="space-y-1.5">
                      <div className="font-semibold text-slate-900 dark:text-slate-100 leading-snug">
                        {req.requirement}
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {getClassificationBadge(req.classification)}
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                          {req.category}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Importance Score (1-10) */}
                  <td className="p-3.5 align-top text-center">
                    <div className="inline-flex flex-col items-center">
                      <span className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
                        req.importance >= 8
                          ? 'bg-rose-50 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-800'
                          : req.importance >= 6
                          ? 'bg-amber-50 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 border border-amber-100 dark:border-amber-800'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}>
                        {req.importance}
                      </span>
                      <span className="text-[9px] text-slate-400 mt-0.5">/10</span>
                    </div>
                  </td>

                  {/* Evidence in Master Profile */}
                  <td className="p-3.5 align-top">
                    <div className="text-slate-700 dark:text-slate-300 leading-relaxed text-xs">
                      {req.candidateEvidence ? (
                        <span>{req.candidateEvidence}</span>
                      ) : (
                        <span className="text-slate-400 italic">No direct documented evidence in profile</span>
                      )}
                    </div>
                    {req.atsImpact && (
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                        <strong>ATS Impact:</strong> {req.atsImpact}
                      </div>
                    )}
                  </td>

                  {/* Match Classification */}
                  <td className="p-3.5 align-top">
                    {getMatchBadge(req.matchLevel)}
                  </td>

                  {/* Action / Positioning */}
                  <td className="p-3.5 align-top text-slate-600 dark:text-slate-300 text-xs">
                    <div className="leading-relaxed">
                      {req.recommendedAction}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {filteredAndSorted.length === 0 && (
          <div className="p-8 text-center text-slate-400">
            No requirements match the current filters.
          </div>
        )}
      </div>
    </div>
  );
};

