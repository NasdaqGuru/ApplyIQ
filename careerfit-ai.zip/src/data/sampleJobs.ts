export interface PresetJob {
  id: string;
  title: string;
  company: string;
  url: string;
  description: string;
  category: string;
  state?: string;
  numberOfOpenings?: number;
  applicantCount?: number;
  location?: string;
  salaryRange?: string;
  department?: string;
}

export const samplePresetJobs: PresetJob[] = [
  {
    id: 'job-1',
    title: 'Director of Corporate Finance & FP&A',
    company: 'Stellaris Cloud Infrastructure',
    url: 'https://careers.stellaris.io/jobs/dir-finance-fpa',
    category: 'Finance / Executive',
    state: 'CA',
    numberOfOpenings: 2,
    applicantCount: 18,
    location: 'San Francisco, CA (Hybrid / Remote)',
    department: 'Strategic Finance',
    salaryRange: '$220,000 - $265,000 + Equity',
    description: `Title: Director of Corporate Finance & FP&A
Company: Stellaris Cloud Infrastructure
Location: San Francisco, CA (Hybrid / Remote eligible)
Department: Strategic Finance
Employment Type: Full-time
Salary Range: $220,000 - $265,000 + Equity + Comprehensive Benefits

ABOUT THE ROLE:
Stellaris is looking for a seasoned Director of Corporate Finance & FP&A to lead our global financial planning, strategic capital allocation, and executive decision support. In this pivotal role, you will report directly to the Chief Financial Officer (CFO) and lead a high-caliber team of 6-8 financial analysts and managers. You will drive enterprise annual operating plans, multi-year strategic forecasts, SaaS metrics analysis, and financial reporting for the Executive Leadership Team and Board of Directors.

RESPONSIBILITIES:
• Lead enterprise annual budgeting, long-range 3-5 year financial modeling, and quarterly rolling forecasts across North America and International markets.
• Partner closely with CEO, CFO, VP of Engineering, and CRO to evaluate business unit performance, pricing models, and investment ROI.
• Manage and mentor a global FP&A team of 7 professionals, fostering technical excellence, career progression, and analytical rigor.
• Oversee executive and board-level presentations, financial narrative synthesis, investor relations materials, and board packages.
• Spearhead financial systems architecture, driving integration between Oracle NetSuite, Workday Adaptive Planning, Salesforce, and BI reporting tools (Tableau/Power BI).
• Analyze core SaaS unit economics (ARR, CAC payback, NRR, Gross Margin, Cohort retention) to advise go-to-market leaders on monetization and expansion.
• Champion zero-based operational expense optimization, headcount modeling, and capital expenditure prioritization ($100M+ scope).
• Drive financial due diligence, commercial modeling, and post-merger integration for potential M&A and strategic partnerships.

MINIMUM QUALIFICATIONS (REQUIRED):
• Bachelor’s degree in Finance, Economics, Accounting, or related quantitative field; MBA or Master's degree strongly preferred.
• 8+ years of progressive experience in corporate FP&A, strategic finance, or investment banking, with at least 3+ years in a people management/leadership capacity.
• Demonstrated track record managing enterprise financial planning for organizations with $100M+ in revenue/ARR.
• Direct expertise with modern cloud ERP and financial planning software (e.g., Oracle NetSuite, Workday Adaptive Planning, Anaplan, or Hyperion).
• Exceptional executive presence and proven experience presenting complex financial insights to C-suite executives and Board members.
• Deep proficiency in advanced financial modeling, SaaS metrics, and data visualization tools (Tableau, Power BI, or SQL).

PREFERRED QUALIFICATIONS:
• Master of Business Administration (MBA) from a top-tier institution.
• Active professional certification such as FPAC (Corporate FP&A) or CFA.
• Experience in B2B SaaS, Cloud infrastructure, or high-growth recurring revenue business models.
• Prior experience leading enterprise ERP migrations or financial system modernization initiatives.
• Proven track record supporting M&A transactions and post-merger ledger integrations.`,
  },
  {
    id: 'job-2',
    title: 'Senior Director of Finance & Operations',
    company: 'FinPulse Global Technologies',
    url: 'https://careers.finpulse.com/positions/sr-dir-finance-ops',
    category: 'FinTech / Strategic',
    state: 'NY',
    numberOfOpenings: 1,
    applicantCount: 74,
    location: 'New York, NY / Remote (US)',
    department: 'Executive Operations',
    salaryRange: '$240,000 - $285,000 + 25% Bonus + Equity',
    description: `Title: Senior Director of Finance & Operations
Company: FinPulse Global Technologies
Location: New York, NY / Remote (US)
Salary Range: $240,000 - $285,000 + 25% Bonus + Equity

POSITION OVERVIEW:
FinPulse is seeking an accomplished Senior Director of Finance & Operations to steer financial strategy, treasury management, multi-entity accounting alignment, and operational efficiency across our fintech platform. Reporting to the Chief Operating Officer, you will oversee financial controllership, FP&A operations, regulatory compliance, and cross-functional operational infrastructure.

KEY RESPONSIBILITIES:
• Direct multi-entity financial consolidation, budgeting, working capital, and treasury operations across US and UK subsidiaries.
• Oversee cross-functional team of 12 spanning FP&A, accounting operations, and financial systems analysts.
• Develop predictive revenue models, interchange fee economics, and risk-adjusted capital allocation strategies.
• Maintain rigorous SOX internal control environments and coordinate external Big 4 audits.
• Modernize automated financial pipeline connecting Snowflake data warehouse with Oracle NetSuite and Looker.

REQUIREMENTS:
• 10+ years in finance and operations leadership within FinTech, Financial Services, or High-Tech.
• Strong foundation in US GAAP, SOX compliance, and regulatory reporting.
• Experience managing large teams (>8 direct and indirect reports).
• Active CPA or MBA preferred.
• Expertise in financial systems transformation, NetSuite, and advanced analytics tools.`,
  },
  {
    id: 'job-3',
    title: 'Head of FP&A & Strategic Finance',
    company: 'Nexus Health AI',
    url: 'https://careers.nexushealth.ai/jobs/head-of-fpa',
    category: 'Healthcare AI / Tech',
    state: 'MA',
    numberOfOpenings: 3,
    applicantCount: 12,
    location: 'Boston, MA / Remote',
    department: 'Strategic Planning',
    salaryRange: '$215,000 - $250,000 + Stock Options',
    description: `Title: Head of FP&A & Strategic Finance
Company: Nexus Health AI
Location: Boston, MA / Remote
Salary: $215,000 - $250,000 + Stock Options

Nexus Health AI is seeking a Head of FP&A to build our strategic finance function from the ground up. You will own long-range planning, hospital commercial deal structuring, fundraising diligence, and departmental budget controls.

Key Requirements:
• 7+ years of FP&A experience in high-growth technology or digital health.
• Proven experience building bottom-up revenue models and investor diligence rooms.
• Proficiency with Tableau/Power BI, SQL, and cloud financial planning platforms.
• Strong leadership and executive communication skills.`,
  },
  {
    id: 'job-4',
    title: 'VP of Finance & Corporate Development',
    company: 'Vertex Cloud Platforms',
    url: 'https://careers.vertexcloud.io/vp-finance',
    category: 'Enterprise SaaS',
    state: 'TX',
    numberOfOpenings: 4,
    applicantCount: 142,
    location: 'Austin, TX (Hybrid)',
    department: 'Corporate Finance',
    salaryRange: '$260,000 - $310,000 + Equity',
    description: `Title: VP of Finance & Corporate Development
Company: Vertex Cloud Platforms
Location: Austin, TX (Hybrid)
Salary: $260,000 - $310,000 + Equity

Vertex Cloud Platforms is looking for an executive finance leader to head our corporate development, capital allocation, and M&A pipeline across North America.

Key Requirements:
• 12+ years in corporate finance, investment banking, or growth equity.
• Experience managing $250M+ ARR budgets and multi-asset capital structures.
• Demonstrated M&A transaction execution and debt/equity capital structuring.`,
  },
  {
    id: 'job-5',
    title: 'Senior Manager, Strategic Financial Planning',
    company: 'Apex BioTech Innovations',
    url: 'https://careers.apexbio.com/sr-mgr-fpa',
    category: 'BioTech / Life Sciences',
    state: 'WA',
    numberOfOpenings: 1,
    applicantCount: 38,
    location: 'Seattle, WA (Remote Friendly)',
    department: 'R&D Finance',
    salaryRange: '$185,000 - $215,000 + Bonus',
    description: `Title: Senior Manager, Strategic Financial Planning
Company: Apex BioTech Innovations
Location: Seattle, WA (Remote Friendly)
Salary: $185,000 - $215,000 + Bonus

Apex BioTech is seeking a Senior Manager of FP&A to steer clinical R&D project financing, clinical trial budget forecasting, and grant allocation modeling.

Key Requirements:
• 6+ years in FP&A or life sciences finance.
• Strong modeling skills in Adaptive Planning, Excel, and SQL.
• Deep analytical competence in clinical trial financial tracking and milestone budgeting.`,
  },
];

export const sampleJobs = samplePresetJobs.map((p) => ({
  id: p.id,
  jobTitle: p.title,
  employer: p.company,
  url: p.url,
  location: p.location || 'San Francisco, CA (Hybrid / Remote)',
  state: p.state || 'CA',
  numberOfOpenings: p.numberOfOpenings || 1,
  applicantCount: p.applicantCount || 20,
  department: p.department || 'Strategic Finance',
  salaryRange: p.salaryRange || '$220,000 - $265,000 + Equity',
  description: p.description,
}));
