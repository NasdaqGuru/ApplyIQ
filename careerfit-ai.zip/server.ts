import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy GoogleGenAI initialization
function getGenAI(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in the environment.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 1. Extract job posting from URL using Gemini with URL tools/search
app.post('/api/extract-job-url', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url || typeof url !== 'string' || !url.startsWith('http')) {
      return res.status(400).json({
        success: false,
        error: 'Please provide a valid HTTP or HTTPS job posting URL.',
      });
    }

    const ai = getGenAI();

    // Use Gemini 3.7 Flash with tools to fetch and parse the URL
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: `You are an executive recruiting specialist. Access the content at the following URL: "${url}".
Extract the full job posting details accurately. If the URL is behind a login wall, protected by anti-bot measures, expired, or not accessible, state clearly that the posting could not be fetched.
DO NOT hallucinate or guess requirements if you cannot access the actual text of the page.

If successful, return a JSON object with this exact structure:
{
  "accessible": true,
  "jobTitle": "...",
  "employer": "...",
  "location": "...",
  "workArrangement": "remote | hybrid | onsite | unspecified",
  "salaryRange": "...",
  "employmentType": "Full-time | Part-time | Contract | ...",
  "jobLevel": "Director | Senior | Lead | Manager | ...",
  "jobSummary": "...",
  "rawDescription": "Complete full job description text...",
  "responsibilities": ["..."],
  "minimumQualifications": ["..."],
  "preferredQualifications": ["..."],
  "requiredSkills": ["..."],
  "preferredSkills": ["..."],
  "technologyRequirements": ["..."],
  "yearsOfExperience": "...",
  "applicationDeadline": "..."
}

If NOT accessible:
{
  "accessible": false,
  "reason": "Login required, bot blocked, or invalid page"
}`,
        config: {
          responseMimeType: 'application/json',
          tools: [{ googleSearch: {} }],
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      if (!parsed.accessible || !parsed.jobTitle || !parsed.rawDescription) {
        return res.json({
          success: false,
          error: "We couldn't reliably retrieve this posting. Paste the job description below.",
          details: parsed.reason,
        });
      }

      return res.json({
        success: true,
        data: parsed,
      });
    } catch (apiErr: any) {
      console.warn('URL extraction failed via tool:', apiErr);
      return res.json({
        success: false,
        error: "We couldn't reliably retrieve this posting. Paste the job description below.",
      });
    }
  } catch (error: any) {
    console.error('Error in /api/extract-job-url:', error);
    res.status(500).json({
      success: false,
      error: "We couldn't reliably retrieve this posting. Paste the job description below.",
    });
  }
});

// 2. Parse candidate resume text into structured Master Profile
app.post('/api/parse-resume', async (req, res) => {
  try {
    const { rawText } = req.body;
    if (!rawText || typeof rawText !== 'string') {
      return res.status(400).json({ error: 'Please provide resume text to parse.' });
    }

    const ai = getGenAI();
    const prompt = `You are an expert executive resume parser. Convert the candidate's resume text into a structured JSON Master Career Profile.
Never invent any facts, titles, dates, companies, metrics, or education not present in the text.

Resume Text:
"""
${rawText}
"""

Return a JSON object conforming to:
{
  "fullName": "...",
  "email": "...",
  "phone": "...",
  "location": "...",
  "linkedinUrl": "...",
  "portfolioUrl": "...",
  "websiteUrl": "...",
  "headline": "...",
  "summary": "...",
  "targetJobTitles": ["..."],
  "targetSalary": "...",
  "targetJobLevels": ["..."],
  "preferredIndustries": ["..."],
  "workArrangement": "remote | hybrid | onsite | any",
  "skills": ["..."],
  "experience": [
    {
      "id": "exp-1",
      "title": "...",
      "company": "...",
      "location": "...",
      "startDate": "YYYY-MM or string",
      "endDate": "YYYY-MM or Present",
      "isCurrent": false,
      "bullets": ["..."],
      "technologies": ["..."]
    }
  ],
  "education": [
    {
      "id": "edu-1",
      "degree": "...",
      "field": "...",
      "institution": "...",
      "graduationYear": "..."
    }
  ],
  "certifications": [
    {
      "id": "cert-1",
      "name": "...",
      "issuer": "...",
      "year": "..."
    }
  ],
  "projects": [
    {
      "id": "proj-1",
      "name": "...",
      "description": "...",
      "url": "...",
      "technologies": ["..."]
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    parsed.rawResumeText = rawText;
    parsed.lastUpdated = new Date().toISOString();

    res.json({ success: true, profile: parsed });
  } catch (error: any) {
    console.error('Error in /api/parse-resume:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 3. Full Job Match Analysis & Document Generation
app.post('/api/analyze-job', async (req, res) => {
  try {
    const { jobDescription, jobUrl, candidateProfile } = req.body;

    if (!jobDescription || !candidateProfile) {
      return res.status(400).json({ error: 'Job description and candidate profile are required.' });
    }

    const ai = getGenAI();

    const systemInstruction = `You are CareerFit AI, an elite combination of Executive Resume Writer, ATS Optimization Specialist, Recruiter, Hiring Manager, Career Strategist, Job-Description Analyst, and Interview Coach.

STRICT TRUTHFULNESS & ANTI-HALLUCINATION DIRECTIVES:
1. NEVER invent, hallucinate, or extrapolate experience, skills, education, certifications, job titles, dates, accomplishments, employers, technologies, or metrics not supported by the candidate's source profile.
2. If an accomplishment lacks metrics in the source material, refine the strategic wording without manufacturing numbers.
3. Distinguish strict REQUIREMENTS from PREFERRED qualifications.
4. ATS Score must follow the transparent 100% weighting model:
   - Required qualifications: 30%
   - Core responsibilities: 20%
   - Skills and competencies: 15%
   - Job-title / seniority alignment: 10%
   - Tools / systems / technologies: 10%
   - Education / certifications: 5%
   - Industry / functional domain relevance: 5%
   - ATS keyword coverage: 5%
5. Calculate Original Resume ATS score (e.g., 64%) and Tailored Resume ATS score (e.g., 88%), clearly explaining the +X point improvement based strictly on truthful repositioning, strategic phrasing, and highlighted existing evidence.
6. Qualification Match score (0-100%) represents whether the candidate can realistically perform the role.
7. Interview Competitiveness score (0-100) with classification tiers (90-100 Exceptional alignment, 80-89 Very strong, 70-79 Strong, 60-69 Competitive but gaps exist, 50-59 Moderate, Below 50 Significant mismatch).
8. Application Outlook provides a heuristic range (e.g., 55–70%) with a strict legal disclaimer that it is model-estimated alignment, not the employer's actual hiring probability.
9. Potential Deal Breakers must ONLY identify legitimate job-related gaps (e.g., mandatory CPA missing, years of experience gap). NEVER use or infer protected personal characteristics (age, race, gender, disability, religion, etc.).
10. Hidden Competitive Advantages identify genuine background differentiators that the employer values.
11. Tailored Resume must maintain exact employers, titles, dates, degrees, and facts, while optimizing the Professional Headline, 3-5 line Executive Summary, 10-16 Core Competencies, 3-6 Selected Achievements, and Action+Scope+Method+Outcome bullets with rationales.
12. Cover Letter must be 1 page, structured (Opening, Employer Need, Candidate Evidence, Differentiator, Closing).
13. Interview Prep must generate 10 likely questions, answer strategies, STAR stories based on genuine candidate experience, questions to ask the hiring manager, 30s elevator pitch, 90s "tell me about yourself", and key themes.
14. Recruiter 10-Second Test (YES/MAYBE/NO with max 5 bullets) and Hiring Manager View (Why interview 3-5 points, Questions/concerns 3-5 points, What makes stronger).
15. Keyword matrix (Already Present, Present but Underused, Missing but Supported, Missing and NOT Supported).
16. Truthfulness Guardrail classifying each tailored change as Verified, Reworded, Inferred, or Unsupported (automatically excluded).
17. ATS Format QA score & checks (Standard headings, date formatting, parsing compatibility, etc.).

Return ONLY a valid JSON object conforming to the required schema.`;

    const prompt = `Perform a comprehensive job analysis and tailoring for the candidate and job posting below.

=== CANDIDATE PROFILE (SOURCE OF TRUTH) ===
Full Name: ${candidateProfile.fullName}
Headline: ${candidateProfile.headline}
Summary: ${candidateProfile.summary}
Target Titles: ${(candidateProfile.targetJobTitles || []).join(', ')}
Skills: ${(candidateProfile.skills || []).join(', ')}

EXPERIENCE:
${(candidateProfile.experience || [])
  .map(
    (e: any) =>
      `Role: ${e.title} at ${e.company} (${e.startDate} - ${e.endDate})\nTechnologies: ${(e.technologies || []).join(', ')}\nBullets:\n${(e.bullets || []).map((b: string) => `• ${b}`).join('\n')}`
  )
  .join('\n\n')}

EDUCATION:
${(candidateProfile.education || []).map((ed: any) => `• ${ed.degree} in ${ed.field}, ${ed.institution} (${ed.graduationYear})`).join('\n')}

CERTIFICATIONS:
${(candidateProfile.certifications || []).map((c: any) => `• ${c.name} - ${c.issuer} (${c.year || 'N/A'})`).join('\n')}

RAW RESUME TEXT:
${candidateProfile.rawResumeText || ''}

=== TARGET JOB POSTING ===
URL: ${jobUrl || 'Pasted Description'}
DESCRIPTION:
"""
${jobDescription}
"""

Output the complete analysis as a JSON object matching this TypeScript structure:
{
  "job": {
    "jobTitle": "string",
    "employer": "string",
    "department": "string",
    "location": "string",
    "workArrangement": "string",
    "salaryRange": "string",
    "employmentType": "string",
    "jobLevel": "string",
    "reportingRelationship": "string",
    "jobSummary": "string",
    "responsibilities": ["string"],
    "minimumQualifications": ["string"],
    "preferredQualifications": ["string"],
    "requiredSkills": ["string"],
    "preferredSkills": ["string"],
    "educationRequirements": "string",
    "certifications": ["string"],
    "technologyRequirements": ["string"],
    "leadershipRequirements": "string",
    "yearsOfExperience": "string",
    "industryExperience": "string",
    "financialOperationalScope": "string",
    "peopleManagementScope": "string",
    "keywords": ["string"],
    "repeatedKeywords": [{"word": "string", "count": 1}],
    "applicationDeadline": "string"
  },
  "scores": {
    "ats": {
      "ats_original": 64,
      "ats_tailored": 88,
      "improvement_points": 24,
      "improvement_explanation": ["string"],
      "breakdown": {
        "required_qualifications": { "score": 85, "weight": 30, "explanation": "string" },
        "core_responsibilities": { "score": 88, "weight": 20, "explanation": "string" },
        "skills_competencies": { "score": 80, "weight": 15, "explanation": "string" },
        "job_title_seniority": { "score": 90, "weight": 10, "explanation": "string" },
        "tools_systems_tech": { "score": 75, "weight": 10, "explanation": "string" },
        "education_certifications": { "score": 95, "weight": 5, "explanation": "string" },
        "industry_domain": { "score": 85, "weight": 5, "explanation": "string" },
        "ats_keyword_coverage": { "score": 82, "weight": 5, "explanation": "string" }
      },
      "strong_matches": ["string"],
      "partial_matches": ["string"],
      "missing_requirements": ["string"],
      "missing_high_value_keywords": ["string"],
      "potential_ats_risks": ["string"]
    },
    "qualification": {
      "score": 90,
      "assessment": "string",
      "factors": [{ "name": "string", "score": 92, "note": "string" }]
    },
    "interview": {
      "score": 84,
      "tier": "Very strong",
      "differentiating_factors": ["string"],
      "risk_factors": ["string"]
    },
    "outlook": {
      "rating": "STRONG",
      "range": "55–70%",
      "disclaimer": "This estimate represents candidate-to-role alignment, not the employer's actual hiring probability. Applicant volume, internal candidates, referrals, interview performance, compensation, hiring freezes, and other unknown factors can materially affect outcomes."
    },
    "confidence": {
      "level": "HIGH",
      "reasons": ["string"]
    }
  },
  "executiveAssessment": "string",
  "whyYouMatch": ["string"],
  "whatCouldHurt": ["string"],
  "howToImprove": ["string"],
  "requirements": [
    {
      "id": "req-1",
      "requirement": "string",
      "category": "Leadership | Management | Finance | Accounting | Analytics | Technology | Strategy | Operations | Communication | Project Management | Regulatory/Compliance | Education | Certification | Industry Knowledge | People Management | Technical Tools | Other",
      "classification": "REQUIRED | STRONGLY PREFERRED | PREFERRED | IMPLIED | OPTIONAL",
      "importance": 10,
      "candidateEvidence": "string",
      "matchLevel": "EXACT MATCH | STRONG MATCH | TRANSFERABLE MATCH | PARTIAL MATCH | WEAK MATCH | NOT FOUND",
      "atsImpact": "string",
      "recommendedAction": "string"
    }
  ],
  "keywords": [
    {
      "keyword": "string",
      "category": "Already Present | Present but Underused | Missing but Supported | Missing and NOT Supported",
      "jobCount": 5,
      "originalCount": 1,
      "tailoredCount": 4,
      "recommendation": "string"
    }
  ],
  "dealBreakers": [
    {
      "id": "db-1",
      "severity": "Critical | Significant | Minor",
      "issue": "string",
      "impact": "string",
      "mitigationStrategy": "string"
    }
  ],
  "competitiveAdvantages": [
    {
      "id": "adv-1",
      "advantage": "string",
      "candidateEvidence": "string",
      "employerValue": "string",
      "resumePlacement": "string",
      "coverLetterPlacement": "string",
      "interviewTalkingPoint": "string"
    }
  ],
  "gapBridging": [
    {
      "id": "gap-1",
      "missingOrPartialRequirement": "string",
      "transferableExperience": "string",
      "truthfulPositioning": "string",
      "guardrailNote": "string"
    }
  ],
  "hiringManagerView": {
    "whyInterview": ["string", "string", "string"],
    "questionsAndConcerns": ["string", "string", "string"],
    "whatMakesStronger": ["string", "string"]
  },
  "recruiterTest": {
    "continueReading": "YES",
    "keyTakeaways": ["bullet 1", "bullet 2", "bullet 3", "bullet 4", "bullet 5"],
    "firstImpression": "string"
  },
  "applicationStrategy": {
    "recommendation": "APPLY — HIGH PRIORITY | APPLY | APPLY WITH CAUTION | LOW PRIORITY | NOT RECOMMENDED",
    "strategicRationale": "string",
    "top3Changes": ["string", "string", "string"]
  },
  "tailoredResume": {
    "headline": "string",
    "summary": "string",
    "coreCompetencies": ["string"],
    "selectedAchievements": ["string"],
    "experience": [
      {
        "id": "exp-1",
        "originalCompany": "string",
        "originalTitle": "string",
        "tailoredTitle": "string",
        "dates": "string",
        "location": "string",
        "bullets": [
          {
            "id": "b-1",
            "originalText": "string",
            "tailoredText": "Action + Scope + Method + Outcome formatted bullet...",
            "reason": "string",
            "status": "accepted",
            "truthStatus": "Verified | Reworded | Inferred"
          }
        ]
      }
    ],
    "education": [
      {
        "degree": "string",
        "field": "string",
        "institution": "string",
        "year": "string"
      }
    ],
    "certifications": [
      {
        "name": "string",
        "issuer": "string",
        "year": "string"
      }
    ],
    "technicalSkills": ["string"]
  },
  "coverLetter": {
    "opening": "string",
    "employerNeed": "string",
    "candidateEvidence": "string",
    "differentiator": "string",
    "closing": "string",
    "fullText": "Full formatted 1-page cover letter text..."
  },
  "interviewPrep": {
    "likelyQuestions": [
      {
        "question": "string",
        "category": "Behavioral | Technical | Strategic | Leadership | Culture",
        "whyAsked": "string",
        "recommendedStrategy": "string",
        "candidateStarStory": {
          "situation": "string",
          "task": "string",
          "action": "string",
          "result": "string"
        }
      }
    ],
    "questionsToAsk": ["string", "string", "string", "string", "string"],
    "intro30Sec": "string",
    "tellMeAboutYourself90Sec": "string",
    "whyThisOrganization": "string",
    "whyThisPosition": "string",
    "whyHireYou": "string",
    "executiveThemes": ["string", "string", "string"]
  },
  "truthfulnessGuardrail": {
    "verified": [{ "section": "string", "text": "string", "evidence": "string" }],
    "reworded": [{ "section": "string", "text": "string", "originalFact": "string" }],
    "inferredNeedsApproval": [{ "section": "string", "text": "string", "reason": "string" }],
    "unsupportedExcluded": [{ "item": "string", "reason": "string" }]
  },
  "atsFormatQA": {
    "status": "PASS",
    "score": 96,
    "checks": [
      { "item": "Standard Heading Structure", "status": "PASS", "note": "Uses standard recognized resume headers (Experience, Education, Skills)." },
      { "item": "Date Formatting Consistency", "status": "PASS", "note": "Uses standard MM/YYYY chronological dates." },
      { "item": "Contact Information Parseability", "status": "PASS", "note": "Clear telephone, email, location in body header." },
      { "item": "Table & Multi-column Parsing Risk", "status": "PASS", "note": "Linear single-column format parses flawlessly in Workday, Taleo, Greenhouse." },
      { "item": "Keyword Stuffing Guard", "status": "PASS", "note": "Keywords integrated syntactically in context without unnatural duplication." },
      { "item": "Graphic / Icon OCR Interference", "status": "PASS", "note": "No icons replacing text strings." }
    ]
  }
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    const analysisId = 'analysis-' + Date.now();
    parsed.id = analysisId;
    parsed.analyzedAt = new Date().toISOString();

    res.json({ success: true, analysis: parsed });
  } catch (error: any) {
    console.error('Error in /api/analyze-job:', error);
    res.status(500).json({ success: false, error: error.message || 'Analysis failed' });
  }
});

// 4. Compare multiple saved jobs
app.post('/api/compare-jobs', async (req, res) => {
  try {
    const { jobs, candidateProfile } = req.body;
    if (!jobs || !Array.isArray(jobs) || jobs.length < 2) {
      return res.status(400).json({ error: 'Please provide at least 2 jobs to compare.' });
    }

    const ai = getGenAI();
    const prompt = `Compare these ${jobs.length} jobs for the candidate profile.

Candidate Profile Summary:
Name: ${candidateProfile.fullName}
Headline: ${candidateProfile.headline}
Skills: ${(candidateProfile.skills || []).join(', ')}

Jobs to compare:
${jobs
  .map(
    (j: any, i: number) => `
Job #${i + 1} (ID: ${j.id})
Company: ${j.company}
Position: ${j.position}
Location: ${j.location || 'N/A'}
Salary: ${j.salary || 'N/A'}
Original ATS: ${j.atsMatch || 70}%
Qualification Match: ${j.qualificationMatch || 80}%
Competitiveness: ${j.interviewCompetitiveness || 75}%
Description Snippet: ${typeof j.description === 'string' ? j.description.slice(0, 800) : ''}
`
  )
  .join('\n---\n')}

Perform a strategic comparison and recommend the BEST STRATEGIC FIT for the candidate.
Return JSON:
{
  "jobs": [
    {
      "id": "string",
      "company": "string",
      "position": "string",
      "location": "string",
      "salary": "string",
      "seniority": "string",
      "atsMatch": 85,
      "qualificationMatch": 90,
      "interviewCompetitiveness": 84,
      "majorGaps": ["string"],
      "competitiveAdvantages": ["string"],
      "careerGrowthPotential": "string"
    }
  ],
  "bestStrategicFit": {
    "jobId": "string",
    "company": "string",
    "position": "string",
    "reasoning": "Detailed executive strategic explanation why this is the highest leverage opportunity...",
    "strategicTakeaways": ["point 1", "point 2", "point 3"]
  }
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({ success: true, comparison: parsed });
  } catch (error: any) {
    console.error('Error in /api/compare-jobs:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 5. Career Learning Engine across multiple analyzed jobs
app.post('/api/career-insights', async (req, res) => {
  try {
    const { applications, candidateProfile } = req.body;
    const ai = getGenAI();

    const prompt = `You are a Chief Talent Strategist and Career Learning Engine.
Analyze the patterns across these ${applications?.length || 1} job postings that the candidate has explored, and cross-reference with the candidate's Master Career Profile.

Candidate Profile:
Name: ${candidateProfile?.fullName}
Current Skills: ${(candidateProfile?.skills || []).join(', ')}
Target Titles: ${(candidateProfile?.targetJobTitles || []).join(', ')}

Jobs Analyzed (${applications?.length || 0}):
${(applications || [])
  .map(
    (app: any, idx: number) => `
Job ${idx + 1}: ${app.position} at ${app.company}
Key Requirements & Keywords: ${JSON.stringify(app.analysis?.job?.keywords || app.analysis?.scores?.breakdown || [])}
`
  )
  .join('\n')}

Identify:
1. Frequently requested skills across these positions with percentages.
2. "Skills Worth Strengthening" (concrete skills that would drastically elevate the candidate's career trajectory, market value, and ATS score across target roles).
3. Emerging Market Themes in hiring for these roles.
4. Strategic Long-Term Career Advice.

Return JSON:
{
  "analyzedJobsCount": ${applications?.length || 1},
  "roleProfilesAnalyzed": ["Director of Finance", "VP of FP&A"],
  "frequentlyRequestedSkills": [
    {
      "skill": "Enterprise Cloud ERP (NetSuite/Workday)",
      "percentage": 85,
      "count": 5,
      "statusInProfile": "Strong",
      "recommendation": "Maintain prominent placement in headline and experience bullets."
    }
  ],
  "skillsWorthStrengthening": [
    {
      "skill": "string",
      "marketDemand": "Very High (found in 75% of target roles)",
      "currentEvidence": "Partial or No direct evidence in current resume",
      "learningAction": "Actionable certification or project recommendation",
      "roiImpact": "Estimated +12% increase in target salary and +18 ATS points for VP/C-suite roles"
    }
  ],
  "emergingMarketThemes": ["string", "string", "string"],
  "strategicCareerAdvice": ["string", "string", "string"]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({ success: true, insights: parsed });
  } catch (error: any) {
    console.error('Error in /api/career-insights:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CareerFit AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
