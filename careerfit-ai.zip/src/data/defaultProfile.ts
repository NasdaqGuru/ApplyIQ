import { CandidateProfile } from '../types';

export const defaultCandidateProfile: CandidateProfile = {
  id: 'profile-1',
  fullName: 'Alexandra Chen, MBA',
  email: 'a.chen.finance@example.com',
  phone: '(415) 555-0192',
  location: 'San Francisco, CA (Open to Remote / Hybrid)',
  linkedinUrl: 'https://linkedin.com/in/alexandra-chen-finance',
  portfolioUrl: 'https://alexandrachen.work',
  websiteUrl: 'https://alexandrachen.work',
  headline: 'Director of Corporate Finance & FP&A | Strategic Planning, Capital Allocation & Financial Systems Transformation',
  summary:
    'Results-driven Corporate Finance Director with 11+ years of progressive leadership spanning SaaS, technology, and enterprise manufacturing. Proven track record directing $180M+ P&Ls, leading cross-functional FP&A teams of 8+ professionals, spearheading multi-entity ERP modernization (Oracle NetSuite/Workday), and executing financial modeling that unlocked $34M in capital investments and $12M in annualized cost efficiencies. Adept in board-level storytelling, rolling forecasts, unit economics, and cross-functional operational partnership.',
  targetJobTitles: [
    'Director of Finance',
    'Senior Director of FP&A',
    'VP of Finance',
    'Head of Strategic Finance',
  ],
  targetSalary: '$210,000 - $260,000 + Equity',
  targetJobLevels: ['Director', 'Senior Director', 'Head of Department'],
  preferredIndustries: ['Enterprise Software (B2B SaaS)', 'FinTech', 'Cloud Technology', 'Digital Health'],
  workArrangement: 'remote',
  skills: [
    'Financial Planning & Analysis (FP&A)',
    'Corporate Financial Strategy',
    'P&L Management ($180M+)',
    'Enterprise Budgeting & Rolling Forecasts',
    'Executive & Board Presentations',
    'Oracle NetSuite & Cloud ERP Migration',
    'Tableau & Power BI Dashboard Architecture',
    'SaaS Unit Economics (CAC, LTV, NRR, ARR)',
    'Capital Allocation & Scenario Modeling',
    'M&A Financial Due Diligence',
    'Cross-Functional Leadership & Team Mentorship',
    'Internal Controls & SOX Compliance Alignment',
    'Cash Flow Optimization & Working Capital',
    'SQL for Financial Data Analytics',
  ],
  experience: [
    {
      id: 'exp-1',
      title: 'Director of Finance & FP&A',
      company: 'Apex Cloud Solutions',
      location: 'San Francisco, CA',
      startDate: '2021-04',
      endDate: 'Present',
      isCurrent: true,
      technologies: ['Oracle NetSuite', 'Tableau', 'Adaptive Insights', 'SQL', 'Workday'],
      bullets: [
        'Direct corporate FP&A operations, annual budgeting, and 3-year strategic financial planning for a $140M ARR enterprise SaaS organization across North America and EMEA.',
        'Lead and mentor a high-performing team of 8 financial analysts, senior managers, and business partners, achieving 95% retention and 4 internal promotions.',
        'Partner directly with CEO, CFO, and Board of Directors to deliver monthly executive reporting, variance analyses, board decks, and investor diligence packages.',
        'Spearheaded enterprise-wide ERP modernization and integration between NetSuite, Salesforce, and Tableau, reducing month-end close cycle by 4 days and eliminating manual data reconciliation across 5 entities.',
        'Architected dynamic SaaS unit economics engine (CAC, Payback, LTV, NRR, Gross Margin) that steered product pricing shifts and yielded a 14% uplift in customer lifetime value.',
        'Instituted zero-based budgeting framework across 12 operational cost centers, uncovering and capturing $8.4M in annualized operating expense efficiencies with zero headcount disruption.',
      ],
    },
    {
      id: 'exp-2',
      title: 'Senior Finance Manager — Strategic Planning & FP&A',
      company: 'Vanguard Enterprise Tech',
      location: 'San Jose, CA',
      startDate: '2017-08',
      endDate: '2021-03',
      isCurrent: false,
      technologies: ['Workday Financials', 'Excel/VBA', 'Power BI', 'Salesforce CRM'],
      bullets: [
        'Managed financial planning, forecasting, and commercial decision support for $95M product business unit, partnering closely with VP of Engineering and VP of Sales.',
        'Built 5-year multi-scenario financial forecast and discounted cash flow (DCF) models supporting a $34M strategic cloud infrastructure capital allocation.',
        'Designed real-time Power BI executive financial dashboards consolidating bookings, pipeline velocity, deferred revenue, and headcount capacity across 6 business divisions.',
        'Led financial due diligence and post-merger synergy integration for a $22M tuck-in acquisition, consolidating financial ledgers within 90 days.',
      ],
    },
    {
      id: 'exp-3',
      title: 'Senior Financial Analyst',
      company: 'Pinnacle Systems Corp',
      location: 'Palo Alto, CA',
      startDate: '2014-06',
      endDate: '2017-07',
      isCurrent: false,
      technologies: ['Oracle Financials', 'Hyperion Essbase', 'Excel', 'Access'],
      bullets: [
        'Delivered monthly operational variance analysis, OPEX forecasting, and headcount reconciliation for 8 corporate departments managing $45M in annual budget.',
        'Automated monthly executive reporting packages using Hyperion and advanced Excel macros, saving 25+ analyst hours per reporting period.',
        'Supported annual external audits and SOX 404 internal control walkthroughs with Big 4 auditors with zero material weaknesses noted.',
      ],
    },
  ],
  education: [
    {
      id: 'edu-1',
      degree: 'Master of Business Administration (MBA)',
      field: 'Finance & Strategic Management',
      institution: 'UC Berkeley, Haas School of Business',
      graduationYear: '2014',
    },
    {
      id: 'edu-2',
      degree: 'Bachelor of Science (B.S.)',
      field: 'Economics & Mathematics (Magna Cum Laude)',
      institution: 'University of California, Davis',
      graduationYear: '2011',
    },
  ],
  certifications: [
    {
      id: 'cert-1',
      name: 'Certified Corporate FP&A Professional (FPAC)',
      issuer: 'Association for Financial Professionals (AFP)',
      year: '2018',
    },
    {
      id: 'cert-2',
      name: 'Chartered Financial Analyst (CFA) - Level II Candidate',
      issuer: 'CFA Institute',
      year: '2019',
    },
  ],
  projects: [
    {
      id: 'proj-1',
      name: 'Enterprise Cloud ERP & Multi-Entity Consolidation',
      description:
        'Led multi-department technical rollout replacing disparate legacy accounting tools with unified Oracle NetSuite and Adaptive Planning architecture.',
      technologies: ['NetSuite', 'Adaptive Insights', 'Tableau', 'APIs'],
    },
    {
      id: 'proj-2',
      name: 'SaaS Metric & Cohort Retention Analytics Platform',
      description:
        'Developed automated cohort retention, net revenue expansion, and pricing elasticity model adopted by Executive Leadership and Board of Directors.',
      technologies: ['SQL', 'Tableau', 'Snowflake', 'Python'],
    },
  ],
  rawResumeText: `ALEXANDRA CHEN, MBA
San Francisco, CA | a.chen.finance@example.com | (415) 555-0192 | linkedin.com/in/alexandra-chen-finance

EXECUTIVE SUMMARY
Results-driven Corporate Finance Director with 11+ years of progressive leadership spanning SaaS, technology, and enterprise software. Proven track record directing $180M+ P&Ls, leading cross-functional FP&A teams of 8+ professionals, spearheading multi-entity ERP modernization (Oracle NetSuite/Workday), and executing financial modeling that unlocked $34M in capital investments and $12M in annualized cost efficiencies. Adept in board-level storytelling, rolling forecasts, unit economics, and cross-functional operational partnership.

CORE COMPETENCIES
Financial Strategy • P&L Management ($180M+) • Corporate FP&A • Enterprise Budgeting & Forecasting • Executive & Board Reporting • ERP & Financial Systems Transformation (NetSuite, Workday) • SaaS Unit Economics • Scenario Modeling • Team Leadership & Mentorship • M&A Due Diligence • Cash Flow Optimization • SOX Internal Controls

PROFESSIONAL EXPERIENCE

APEX CLOUD SOLUTIONS — San Francisco, CA
Director of Finance & FP&A | April 2021 – Present
• Direct corporate FP&A operations, annual budgeting, and 3-year strategic financial planning for a $140M ARR enterprise SaaS organization across North America and EMEA.
• Lead and mentor a high-performing team of 8 financial analysts, senior managers, and business partners, achieving 95% retention and 4 internal promotions.
• Partner directly with CEO, CFO, and Board of Directors to deliver monthly executive reporting, variance analyses, board decks, and investor diligence packages.
• Spearheaded enterprise-wide ERP modernization and integration between NetSuite, Salesforce, and Tableau, reducing month-end close cycle by 4 days and eliminating manual data reconciliation across 5 entities.
• Architected dynamic SaaS unit economics engine (CAC, Payback, LTV, NRR, Gross Margin) that steered product pricing shifts and yielded a 14% uplift in customer lifetime value.
• Instituted zero-based budgeting framework across 12 operational cost centers, uncovering and capturing $8.4M in annualized operating expense efficiencies with zero headcount disruption.

VANGUARD ENTERPRISE TECH — San Jose, CA
Senior Finance Manager — Strategic Planning & FP&A | August 2017 – March 2021
• Managed financial planning, forecasting, and commercial decision support for $95M product business unit, partnering closely with VP of Engineering and VP of Sales.
• Built 5-year multi-scenario financial forecast and discounted cash flow (DCF) models supporting a $34M strategic cloud infrastructure capital allocation.
• Designed real-time Power BI executive financial dashboards consolidating bookings, pipeline velocity, deferred revenue, and headcount capacity across 6 business divisions.
• Led financial due diligence and post-merger synergy integration for a $22M tuck-in acquisition, consolidating financial ledgers within 90 days.

PINNACLE SYSTEMS CORP — Palo Alto, CA
Senior Financial Analyst | June 2014 – July 2017
• Delivered monthly operational variance analysis, OPEX forecasting, and headcount reconciliation for 8 corporate departments managing $45M in annual budget.
• Automated monthly executive reporting packages using Hyperion and advanced Excel macros, saving 25+ analyst hours per reporting period.
• Supported annual external audits and SOX 404 internal control walkthroughs with Big 4 auditors with zero material weaknesses noted.

EDUCATION & CERTIFICATIONS
• MBA in Finance & Strategic Management — UC Berkeley, Haas School of Business (2014)
• B.S. in Economics & Mathematics (Magna Cum Laude) — UC Davis (2011)
• Certified Corporate FP&A Professional (FPAC) — Association for Financial Professionals (2018)
• CFA Level II Candidate — CFA Institute (2019)`,
  lastUpdated: new Date().toISOString(),
};

export const defaultProfile = defaultCandidateProfile;

