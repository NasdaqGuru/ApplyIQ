import React from 'react';
import { X, CheckCircle, Info, Calculator, ArrowRight } from 'lucide-react';
import { FullJobAnalysis } from '../types';

interface ScoreExplanationModalProps {
  isOpen: boolean;
  onClose: () => void;
  analysis: FullJobAnalysis;
}

export const ScoreExplanationModal: React.FC<ScoreExplanationModalProps> = ({
  isOpen,
  onClose,
  analysis,
}) => {
  if (!isOpen) return null;

  const { scores } = analysis;
  const { ats, qualification, interview, outlook, confidence } = scores;
  const bd = ats.breakdown;

  const weightingTable = [
    {
      factor: 'Required Qualifications',
      weight: 30,
      score: bd.required_qualifications?.score || 85,
      explanation: bd.required_qualifications?.explanation || 'Explicit mandatory qualifications verified against candidate background.',
    },
    {
      factor: 'Core Responsibilities',
      weight: 20,
      score: bd.core_responsibilities?.score || 88,
      explanation: bd.core_responsibilities?.explanation || 'Demonstrated capacity performing major operational and strategic duties.',
    },
    {
      factor: 'Skills & Competencies',
      weight: 15,
      score: bd.skills_competencies?.score || 80,
      explanation: bd.skills_competencies?.explanation || 'Hard and soft functional competencies listed in the job description.',
    },
    {
      factor: 'Job Title / Seniority Alignment',
      weight: 10,
      score: bd.job_title_seniority?.score || 90,
      explanation: bd.job_title_seniority?.explanation || 'Career level, team leadership scale, and decision-making scope.',
    },
    {
      factor: 'Tools / Systems / Technologies',
      weight: 10,
      score: bd.tools_systems_tech?.score || 75,
      explanation: bd.tools_systems_tech?.explanation || 'Named platforms, ERP, BI tools, and analytical software.',
    },
    {
      factor: 'Education / Certifications',
      weight: 5,
      score: bd.education_certifications?.score || 95,
      explanation: bd.education_certifications?.explanation || 'Degrees, certifications, and academic prerequisites.',
    },
    {
      factor: 'Industry / Domain Relevance',
      weight: 5,
      score: bd.industry_domain?.score || 85,
      explanation: bd.industry_domain?.explanation || 'Direct and transferable sector and vertical knowledge.',
    },
    {
      factor: 'ATS Keyword Coverage',
      weight: 5,
      score: bd.ats_keyword_coverage?.score || 82,
      explanation: bd.ats_keyword_coverage?.explanation || 'Meaningful semantic keyword distribution without stuffing.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto font-sans">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-3xl shadow-xl max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-100 dark:border-blue-900/40">
              <Calculator className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Scoring Transparency & Formula Breakdown
              </h2>
              <p className="text-[11px] text-slate-400">
                100% Weighted, Evidence-Based ATS & Qualification Algorithm
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 overflow-y-auto space-y-5 text-slate-700 dark:text-slate-300 text-xs">
          {/* Before vs After Highlight */}
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 rounded-lg p-3.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                  Before vs. After Tailoring
                </span>
                <div className="flex items-center gap-2.5 mt-0.5">
                  <span className="text-base font-semibold text-slate-700 dark:text-slate-300">
                    Original: {ats.ats_original}%
                  </span>
                  <ArrowRight className="w-4 h-4 text-slate-400" />
                  <span className="text-lg font-bold text-green-600 dark:text-green-400">
                    Tailored: {ats.ats_tailored}%
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-green-50 dark:bg-green-950/60 text-green-700 dark:text-green-300 border border-green-200 dark:border-green-800">
                    +{ats.improvement_points || ats.ats_tailored - ats.ats_original} pts
                  </span>
                </div>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 max-w-xs leading-relaxed">
                Zero invented qualifications. Score gains come exclusively from truthful phrasing, repositioning existing accomplishments, and aligning terminology.
              </div>
            </div>

            {ats.improvement_explanation && ats.improvement_explanation.length > 0 && (
              <div className="mt-2.5 pt-2.5 border-t border-slate-200 dark:border-slate-800 space-y-1">
                <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">Key Improvement Drivers:</span>
                <ul className="text-[11px] text-slate-600 dark:text-slate-400 space-y-1">
                  {ats.improvement_explanation.map((exp, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>{exp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Transparent Weighting Model Table */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-xs text-slate-900 dark:text-white">
                Transparent 100% Weighted ATS Model
              </h3>
              <span className="text-[11px] text-slate-400">Formula: Σ (Score × Weight) / 100</span>
            </div>

            <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-2.5">Category</th>
                    <th className="p-2.5 text-center">Weight</th>
                    <th className="p-2.5 text-center">Factor Score</th>
                    <th className="p-2.5">Calculation Details & Evidence</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {weightingTable.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="p-2.5 font-medium text-slate-900 dark:text-slate-200 text-xs">
                        {row.factor}
                      </td>
                      <td className="p-2.5 text-center font-bold text-blue-600 dark:text-blue-400 text-xs">
                        {row.weight}%
                      </td>
                      <td className="p-2.5 text-center">
                        <span className={`px-1.5 py-0.5 rounded text-[11px] font-semibold ${
                          row.score >= 85
                            ? 'bg-green-50 dark:bg-green-950/60 text-green-700 dark:text-green-400 border border-green-200 dark:border-green-800'
                            : row.score >= 70
                            ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 border border-blue-200 dark:border-blue-800'
                            : 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800'
                        }`}>
                          {row.score}%
                        </span>
                      </td>
                      <td className="p-2.5 text-slate-600 dark:text-slate-400 text-[11px]">
                        {row.explanation}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Qualification vs ATS vs Interview Competitiveness */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
              <div className="font-semibold text-slate-900 dark:text-white text-xs mb-0.5">
                Qualification Match ({qualification.score}%)
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                Measures whether the candidate can realistically perform the role based on real-world scope and complexity, independent of pure ATS keywords.
              </p>
            </div>

            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
              <div className="font-semibold text-slate-900 dark:text-white text-xs mb-0.5">
                Interview Competitiveness ({interview.score}/100)
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                Evidence-based benchmark comparing seniority, quantified accomplishments, strategic narrative, and market differentiators ({interview.tier}).
              </p>
            </div>

            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
              <div className="font-semibold text-slate-900 dark:text-white text-xs mb-0.5">
                Application Outlook ({outlook.rating})
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                Model-estimated candidate-to-role alignment range ({outlook.range}). Not a guaranteed probability of hire.
              </p>
            </div>
          </div>

          {/* Legal and Algorithmic Disclaimer */}
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 text-[11px] text-slate-500 dark:text-slate-400 flex items-start gap-2 border border-slate-200/60 dark:border-slate-800">
            <Info className="w-3.5 h-3.5 text-blue-600 mt-0.5 flex-shrink-0" />
            <span className="leading-relaxed">
              <strong>Notice:</strong> {outlook.disclaimer} Analysis confidence is rated as <strong>{confidence?.level}</strong> based on the completeness and clarity of the input posting and candidate profile.
            </span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-100 dark:border-slate-800 flex justify-end bg-slate-50/50 dark:bg-slate-800/30">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 font-semibold text-xs transition"
          >
            Close Breakdown
          </button>
        </div>
      </div>
    </div>
  );
};

