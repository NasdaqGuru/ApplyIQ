import React from 'react';
import {
  HelpCircle,
  TrendingUp,
  AlertTriangle,
  Award,
  Briefcase,
  ShieldCheck,
  Zap,
  CheckCircle2,
  ChevronRight,
  Info,
  Users,
  Flame,
} from 'lucide-react';
import { FullJobAnalysis } from '../types';

interface ScorecardHeaderProps {
  analysis: FullJobAnalysis;
  onOpenScoreModal: () => void;
  onNavigateToTab?: (tab: string) => void;
}

export const ScorecardHeader: React.FC<ScorecardHeaderProps> = ({
  analysis,
  onOpenScoreModal,
  onNavigateToTab,
}) => {
  const { scores, dealBreakers, executiveAssessment } = analysis;
  const { ats, qualification, interview, outlook, confidence } = scores;

  const criticalGapsCount = (dealBreakers || []).filter((db) => db.severity === 'Critical').length;
  const significantGapsCount = (dealBreakers || []).filter((db) => db.severity === 'Significant').length;

  const openings = analysis.job.numberOfOpenings || 1;
  const applicants = analysis.job.applicantCount || 18;
  const isEarlyApplicant = applicants < 25;

  return (
    <div id="scorecard-header-container" className="space-y-6 font-sans">
      {/* Top Role Header Banner */}
      <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-xl p-6 shadow-xs border border-slate-200 dark:border-slate-800 relative">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
                {analysis.job.employer}
              </span>
              {analysis.job.department && (
                <span className="px-2.5 py-0.5 rounded-md text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                  {analysis.job.department}
                </span>
              )}
              {analysis.job.location && (
                <span className="px-2.5 py-0.5 rounded-md text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
                  📍 {analysis.job.location}
                </span>
              )}
              {analysis.job.salaryRange && (
                <span className="px-2.5 py-0.5 rounded-md text-xs font-medium bg-green-50 dark:bg-green-950/40 text-green-700 dark:text-green-300 border border-green-100 dark:border-green-800">
                  💵 {analysis.job.salaryRange}
                </span>
              )}

              {/* LinkedIn-style Openings and Applicants pills */}
              <span className="px-2.5 py-0.5 rounded-md text-xs font-medium bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800 inline-flex items-center gap-1">
                <Users className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                {openings} {openings === 1 ? 'Current Opening' : 'Current Openings'}
              </span>

              {isEarlyApplicant ? (
                <span className="px-2.5 py-0.5 rounded-md text-xs font-medium bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-800 inline-flex items-center gap-1">
                  <Zap className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                  {applicants} applied • Early Applicant
                </span>
              ) : applicants > 100 ? (
                <span className="px-2.5 py-0.5 rounded-md text-xs font-medium bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-800 inline-flex items-center gap-1">
                  <Flame className="w-3 h-3 text-rose-600 dark:text-rose-400" />
                  {applicants} applied • High Demand
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-md text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 inline-flex items-center gap-1">
                  <Users className="w-3 h-3 text-slate-500" />
                  {applicants} applied
                </span>
              )}
            </div>

            <h1 className="text-2xl lg:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
              {analysis.job.jobTitle}
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-xs mt-1 max-w-2xl">
              Target role analysis grounded in your Master Profile with 100% anti-hallucination verification.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              id="btn-why-this-score"
              onClick={onOpenScoreModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition shadow-xs active:scale-98"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              Why This Score?
            </button>
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300">
              <span className="text-[11px] text-slate-400 dark:text-slate-500">Analysis Confidence:</span>
              <span className="text-green-600 dark:text-green-400 font-bold">{confidence?.level || 'HIGH'}</span>
            </div>
          </div>
        </div>

        {/* 6 Clean Score Metrics in Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6">
          {/* Card 1: ATS Match Original vs Tailored */}
          <div
            onClick={onOpenScoreModal}
            className="cursor-pointer bg-slate-50/70 dark:bg-slate-800/50 hover:bg-slate-100/80 dark:hover:bg-slate-800 border border-slate-200/90 dark:border-slate-700/80 rounded-xl p-3.5 transition group"
          >
            <div className="flex items-center justify-between text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500 tracking-wider mb-1">
              <span>ATS MATCH</span>
              <HelpCircle className="w-3 h-3 text-slate-400 group-hover:text-blue-600 transition" />
            </div>
            <div className="flex items-baseline">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">
                {ats.ats_original}
              </span>
              <span className="text-xs font-semibold text-slate-400 ml-1">/ 100</span>
            </div>
            <div className="flex items-center gap-1 text-[10px] font-bold text-green-600 dark:text-green-400 mt-1.5 bg-green-50 dark:bg-green-950/40 px-1.5 py-0.5 rounded border border-green-100 dark:border-green-800/60 w-fit">
              <TrendingUp className="w-2.5 h-2.5" />
              <span>Tailored: {ats.ats_tailored}%</span>
            </div>
          </div>

          {/* Card 2: Before -> After Score Improvement */}
          <div className="bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/90 dark:border-slate-700/80 rounded-xl p-3.5">
            <div className="text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500 tracking-wider mb-1">
              IMPROVEMENT
            </div>
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">
              +{ats.improvement_points || ats.ats_tailored - ats.ats_original}%
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5 font-medium">
              {ats.ats_original}% → {ats.ats_tailored}%
            </div>
          </div>

          {/* Card 3: Qualification Match */}
          <div className="bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/90 dark:border-slate-700/80 rounded-xl p-3.5">
            <div className="text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500 tracking-wider mb-1">
              QUALIFICATION
            </div>
            <div className="text-2xl font-bold text-slate-900 dark:text-white">
              {qualification.score}%
            </div>
            <div className="text-[10px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 px-1.5 py-0.5 rounded border border-blue-100 dark:border-blue-800/60 mt-1.5 w-fit">
              Elite Fit
            </div>
          </div>

          {/* Card 4: Interview Competitiveness */}
          <div className="bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/90 dark:border-slate-700/80 rounded-xl p-3.5">
            <div className="text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500 tracking-wider mb-1">
              INTERVIEW COMP.
            </div>
            <div className="flex items-baseline">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">
                {interview.score}
              </span>
              <span className="text-xs font-semibold text-slate-400 ml-1">/ 100</span>
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5 truncate">
              {interview.tier || 'Strong Tier'}
            </div>
          </div>

          {/* Card 5: Application Outlook */}
          <div className="bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/90 dark:border-slate-700/80 rounded-xl p-3.5">
            <div className="text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500 tracking-wider mb-1">
              OUTLOOK
            </div>
            <div className={`text-2xl font-bold tracking-tight ${
              outlook.rating === 'EXCEPTIONAL' || outlook.rating === 'VERY STRONG'
                ? 'text-green-600 dark:text-green-400'
                : outlook.rating === 'STRONG'
                ? 'text-blue-600 dark:text-blue-400'
                : 'text-amber-500 dark:text-amber-400'
            }`}>
              {outlook.rating}
            </div>
            <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
              {outlook.range}
            </div>
          </div>

          {/* Card 6: Critical Gaps */}
          <div
            onClick={() => onNavigateToTab?.('dealbreakers')}
            className={`cursor-pointer border rounded-xl p-3.5 transition group ${
              criticalGapsCount > 0
                ? 'bg-rose-50/80 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/60 text-rose-900 dark:text-rose-200'
                : significantGapsCount > 0
                ? 'bg-amber-50/80 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-200'
                : 'bg-slate-50/70 dark:bg-slate-800/50 border-slate-200/90 dark:border-slate-700/80 hover:bg-slate-100/80 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-wider mb-1">
              <span>DEAL BREAKERS</span>
              <AlertTriangle className="w-3 h-3 opacity-70 group-hover:opacity-100" />
            </div>
            <div className="text-2xl font-bold">
              {criticalGapsCount} <span className="text-xs font-normal opacity-80">Critical</span>
            </div>
            <div className="text-[11px] opacity-80 mt-1 truncate">
              {significantGapsCount} Significant gap{significantGapsCount !== 1 ? 's' : ''}
            </div>
          </div>
        </div>
      </div>

      {/* Executive Assessment Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3 flex items-center">
          Executive Assessment
          <span className="ml-2 text-[10px] font-normal text-slate-400 dark:text-slate-500">
            (Evidence-Grounded AI Synthesis)
          </span>
        </h3>

        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed italic border-l-2 border-blue-400 dark:border-blue-600 pl-4 mb-6">
          "{executiveAssessment}"
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
          {/* Why You Match */}
          <div className="bg-green-50/40 dark:bg-green-950/20 border border-green-100 dark:border-green-900/30 rounded-xl p-4">
            <div className="flex items-center gap-1.5 text-xs font-bold text-green-800 dark:text-green-300 mb-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
              <span>Why You Match</span>
            </div>
            <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 leading-relaxed">
              {(analysis.whyYouMatch || []).slice(0, 3).map((item, idx) => (
                <li key={idx} className="line-clamp-2">• {item}</li>
              ))}
            </ul>
          </div>

          {/* What Could Hurt */}
          <div className="bg-rose-50/40 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/30 rounded-xl p-4">
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-800 dark:text-rose-300 mb-2">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
              <span>Potential Vulnerabilities</span>
            </div>
            <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 leading-relaxed">
              {(analysis.whatCouldHurt || []).slice(0, 3).map((item, idx) => (
                <li key={idx} className="line-clamp-2">• {item}</li>
              ))}
            </ul>
          </div>

          {/* How to Improve */}
          <div className="bg-blue-50/40 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/30 rounded-xl p-4">
            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-800 dark:text-blue-300 mb-2">
              <TrendingUp className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>How to Position</span>
            </div>
            <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 leading-relaxed">
              {(analysis.howToImprove || []).slice(0, 3).map((item, idx) => (
                <li key={idx} className="line-clamp-2">• {item}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

