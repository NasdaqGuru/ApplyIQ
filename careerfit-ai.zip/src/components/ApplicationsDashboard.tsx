import React, { useState, useMemo } from 'react';
import {
  Plus,
  ArrowRight,
  Layers,
  Search,
  Trash2,
  CheckSquare,
  Square,
  Users,
  Zap,
  Flame,
  Filter,
  RotateCcw,
  Briefcase,
  MapPin,
  TrendingUp,
} from 'lucide-react';
import { SavedOpportunity } from '../types';

interface ApplicationsDashboardProps {
  opportunities: SavedOpportunity[];
  currentAnalysisId: string | null;
  onSelectOpportunity: (id: string) => void;
  onUpdateOpportunity: (updated: SavedOpportunity) => void;
  onDeleteOpportunity: (id: string) => void;
  onOpenAnalyzeModal: () => void;
  onCompareSelected: (ids: string[]) => void;
}

export const ApplicationsDashboard: React.FC<ApplicationsDashboardProps> = ({
  opportunities,
  currentAnalysisId,
  onSelectOpportunity,
  onUpdateOpportunity,
  onDeleteOpportunity,
  onOpenAnalyzeModal,
  onCompareSelected,
}) => {
  const [search, setSearch] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [stateFilter, setStateFilter] = useState<string>('ALL');
  const [openingsFilter, setOpeningsFilter] = useState<string>('ALL');
  const [applicantFilter, setApplicantFilter] = useState<string>('ALL');

  // Dynamic available states from current data
  const availableStates = useMemo(() => {
    const states = new Set<string>();
    opportunities.forEach((op) => {
      if (op.state) {
        states.add(op.state.toUpperCase());
      } else if (op.location) {
        const match = op.location.match(/\b([A-Z]{2})\b/);
        if (match) states.add(match[1]);
      }
    });
    return Array.from(states).sort();
  }, [opportunities]);

  // Filter logic
  const filtered = useMemo(() => {
    return opportunities.filter((op) => {
      // 1. Search Query
      const q = search.toLowerCase().trim();
      const matchesSearch =
        !q ||
        op.jobTitle.toLowerCase().includes(q) ||
        op.company.toLowerCase().includes(q) ||
        op.location.toLowerCase().includes(q) ||
        (op.state && op.state.toLowerCase().includes(q));

      // 2. Status Filter
      const matchesStatus = statusFilter === 'ALL' || op.status === statusFilter;

      // 3. State Filter
      const opState = op.state?.toUpperCase() || (op.location.match(/\b([A-Z]{2})\b/)?.[1] ?? '');
      const matchesState =
        stateFilter === 'ALL' ||
        opState === stateFilter.toUpperCase() ||
        (stateFilter === 'Remote' && (op.location.toLowerCase().includes('remote') || op.state?.toLowerCase() === 'remote'));

      // 4. Current Openings Filter
      const openings = op.numberOfOpenings ?? 1;
      let matchesOpenings = true;
      if (openingsFilter === '1') {
        matchesOpenings = openings === 1;
      } else if (openingsFilter === '2+') {
        matchesOpenings = openings >= 2;
      } else if (openingsFilter === '3+') {
        matchesOpenings = openings >= 3;
      }

      // 5. LinkedIn-Style Applicant Count Filter
      const applicants = op.applicantCount ?? 20;
      let matchesApplicants = true;
      if (applicantFilter === 'early') {
        matchesApplicants = applicants < 25; // LinkedIn: Be an early applicant (<25)
      } else if (applicantFilter === '25-50') {
        matchesApplicants = applicants >= 25 && applicants <= 50;
      } else if (applicantFilter === '50-100') {
        matchesApplicants = applicants > 50 && applicants <= 100;
      } else if (applicantFilter === '100+') {
        matchesApplicants = applicants > 100;
      }

      return matchesSearch && matchesStatus && matchesState && matchesOpenings && matchesApplicants;
    });
  }, [opportunities, search, statusFilter, stateFilter, openingsFilter, applicantFilter]);

  const hasActiveFilters =
    search.trim() !== '' ||
    statusFilter !== 'ALL' ||
    stateFilter !== 'ALL' ||
    openingsFilter !== 'ALL' ||
    applicantFilter !== 'ALL';

  const handleResetFilters = () => {
    setSearch('');
    setStatusFilter('ALL');
    setStateFilter('ALL');
    setOpeningsFilter('ALL');
    setApplicantFilter('ALL');
  };

  // Pipeline aggregate statistics
  const totalOpeningsCount = useMemo(() => {
    return opportunities.reduce((acc, op) => acc + (op.numberOfOpenings ?? 1), 0);
  }, [opportunities]);

  const earlyApplicantOpportunitiesCount = useMemo(() => {
    return opportunities.filter((op) => (op.applicantCount ?? 20) < 25).length;
  }, [opportunities]);

  const activePipelineCount = useMemo(() => {
    return opportunities.filter((op) => ['Applied', 'Interviewing', 'Offer'].includes(op.status)).length;
  }, [opportunities]);

  const toggleSelect = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      if (selectedIds.length >= 5) {
        alert('You can compare up to 5 opportunities simultaneously.');
        return;
      }
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handleStatusChange = (op: SavedOpportunity, newStatus: SavedOpportunity['status']) => {
    onUpdateOpportunity({
      ...op,
      status: newStatus,
      updatedAt: new Date().toISOString(),
    });
  };

  const handlePriorityChange = (op: SavedOpportunity, newPriority: SavedOpportunity['priority']) => {
    onUpdateOpportunity({
      ...op,
      priority: newPriority,
      updatedAt: new Date().toISOString(),
    });
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-5 sm:p-6 shadow-xs border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              Pipeline Intelligence
            </span>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {opportunities.length} Target Roles Tracked
            </span>
          </div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">
            Target Job Pipeline & Version History
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 max-w-xl leading-relaxed">
            Track and compare tailored resume versions, state locations, openings, and LinkedIn applicant competition across all target opportunities.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {selectedIds.length >= 2 && (
            <button
              onClick={() => onCompareSelected(selectedIds)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-xs font-semibold transition"
            >
              <Layers className="w-3.5 h-3.5" />
              Compare Selected ({selectedIds.length})
            </button>
          )}

          <button
            onClick={onOpenAnalyzeModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            Analyze New Job
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs">
            <span>Total Roles Tracked</span>
            <Briefcase className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
            {opportunities.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Across all locations & pipelines</div>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs">
            <span>Total Open Positions</span>
            <Users className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 mt-1">
            {totalOpeningsCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Aggregated active openings</div>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs">
            <span>Early Applicant (&lt;25)</span>
            <Zap className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {earlyApplicantOpportunitiesCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">High probability response window</div>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs">
            <span>Active Pipeline</span>
            <TrendingUp className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-1">
            {activePipelineCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Applied, Interviewing, Offer</div>
        </div>
      </div>

      {/* Filter and Search Bar with State, Openings, and LinkedIn Applicant Filters */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden">
        {/* Top Control Bar: Status Tabs & Keyword Search */}
        <div className="p-3.5 sm:p-4 border-b border-slate-100 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Status Pills */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-slate-400 font-medium mr-1 text-[11px]">Status:</span>
            {['ALL', 'Discovered', 'Tailoring', 'Applied', 'Interviewing', 'Offer', 'Archived'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-md transition text-xs font-medium ${
                  statusFilter === st
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 border border-slate-100 dark:border-slate-700'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search roles, companies, locations..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Secondary Filter Bar: State / Region, # of Openings, and Applicant Volume (LinkedIn style) */}
        <div className="p-3.5 sm:p-4 bg-slate-50/70 dark:bg-slate-850/50 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 font-medium">
              <Filter className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>Filters:</span>
            </div>

            {/* 1. STATE / REGION FILTER */}
            <div className="flex items-center gap-1.5">
              <label htmlFor="filter-state-select" className="text-slate-500 dark:text-slate-400 text-[11px] font-medium flex items-center gap-1">
                <MapPin className="w-3 h-3" /> State:
              </label>
              <select
                id="filter-state-select"
                value={stateFilter}
                onChange={(e) => setStateFilter(e.target.value)}
                className={`px-2.5 py-1 rounded-md border text-xs font-medium focus:outline-none transition ${
                  stateFilter !== 'ALL'
                    ? 'bg-blue-50 dark:bg-blue-950/50 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 font-semibold'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <option value="ALL">All States / Regions</option>
                <option value="CA">California (CA)</option>
                <option value="NY">New York (NY)</option>
                <option value="MA">Massachusetts (MA)</option>
                <option value="TX">Texas (TX)</option>
                <option value="WA">Washington (WA)</option>
                <option value="Remote">Remote</option>
                {availableStates
                  .filter((s) => !['CA', 'NY', 'MA', 'TX', 'WA', 'REMOTE'].includes(s))
                  .map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
              </select>
            </div>

            {/* 2. NUMBER OF CURRENT OPENINGS FILTER */}
            <div className="flex items-center gap-1.5">
              <label htmlFor="filter-openings-select" className="text-slate-500 dark:text-slate-400 text-[11px] font-medium flex items-center gap-1">
                <Users className="w-3 h-3" /> Openings:
              </label>
              <select
                id="filter-openings-select"
                value={openingsFilter}
                onChange={(e) => setOpeningsFilter(e.target.value)}
                className={`px-2.5 py-1 rounded-md border text-xs font-medium focus:outline-none transition ${
                  openingsFilter !== 'ALL'
                    ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-300 dark:border-indigo-700 text-indigo-700 dark:text-indigo-300 font-semibold'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <option value="ALL">All Openings</option>
                <option value="1">1 Opening (Single)</option>
                <option value="2+">2+ Current Openings</option>
                <option value="3+">3+ Current Openings (Hiring Surge)</option>
              </select>
            </div>

            {/* 3. LINKEDIN-STYLE APPLICANT COUNT FILTER */}
            <div className="flex items-center gap-1.5">
              <label htmlFor="filter-applicants-select" className="text-slate-500 dark:text-slate-400 text-[11px] font-medium flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-500" /> LinkedIn Applicants:
              </label>
              <select
                id="filter-applicants-select"
                value={applicantFilter}
                onChange={(e) => setApplicantFilter(e.target.value)}
                className={`px-2.5 py-1 rounded-md border text-xs font-medium focus:outline-none transition ${
                  applicantFilter !== 'ALL'
                    ? 'bg-amber-50 dark:bg-amber-950/50 border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-300 font-semibold'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <option value="ALL">All Applicant Volumes</option>
                <option value="early">⚡ Early Applicant (&lt; 25 applied)</option>
                <option value="25-50">👥 25 - 50 applied</option>
                <option value="50-100">📊 50 - 100 applied</option>
                <option value="100+">🔥 &gt; 100 applied (High Competition)</option>
              </select>
            </div>
          </div>

          {/* Active Filter Count & Reset Button */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-[11px]">
              Showing <strong className="text-slate-900 dark:text-white">{filtered.length}</strong> of{' '}
              {opportunities.length}
            </span>

            {hasActiveFilters && (
              <button
                onClick={handleResetFilters}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-200/70 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 text-xs font-medium transition"
              >
                <RotateCcw className="w-3 h-3" />
                Reset Filters
              </button>
            )}
          </div>
        </div>

        {/* Opportunity List Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-medium border-b border-slate-100 dark:border-slate-800 text-[11px]">
              <tr>
                <th className="p-3 w-10 text-center">
                  <span className="sr-only">Select</span>
                </th>
                <th className="p-3 min-w-[220px]">Opportunity & Role</th>
                <th className="p-3 text-center w-28">State / Region</th>
                <th className="p-3 text-center w-28">Openings</th>
                <th className="p-3 text-center w-36">Applicants (LinkedIn)</th>
                <th className="p-3 text-center w-28">ATS Score</th>
                <th className="p-3 text-center w-28">Fit Outlook</th>
                <th className="p-3 w-32">Priority</th>
                <th className="p-3 w-36">Status</th>
                <th className="p-3 text-right w-32">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((op) => {
                const isSelected = selectedIds.includes(op.id);
                const isCurrent = op.analysisId === currentAnalysisId;
                const stateDisplay = op.state || op.location.match(/\b([A-Z]{2})\b/)?.[1] || 'US';
                const openings = op.numberOfOpenings ?? 1;
                const applicants = op.applicantCount ?? 20;

                return (
                  <tr
                    key={op.id}
                    className={`hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition ${
                      isCurrent ? 'bg-blue-50/20 dark:bg-blue-950/10' : ''
                    }`}
                  >
                    {/* Multi-select checkbox */}
                    <td className="p-3 text-center">
                      <button
                        onClick={() => toggleSelect(op.id)}
                        className="text-slate-400 hover:text-blue-600 transition"
                      >
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-blue-600" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>
                    </td>

                    {/* Role & Company */}
                    <td className="p-3">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onSelectOpportunity(op.analysisId)}
                            className="font-bold text-xs text-slate-900 dark:text-white hover:text-blue-600 transition text-left"
                          >
                            {op.jobTitle}
                          </button>
                          {isCurrent && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                              Active
                            </span>
                          )}
                        </div>
                        <div className="text-slate-400 text-[11px] flex items-center gap-1.5">
                          <span className="font-medium text-slate-600 dark:text-slate-300">{op.company}</span>
                          <span>•</span>
                          <span>{op.location}</span>
                          {op.salary && (
                            <>
                              <span>•</span>
                              <span className="text-green-600 dark:text-green-400">{op.salary}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* State / Region Badge */}
                    <td className="p-3 text-center">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                        📍 {stateDisplay}
                      </span>
                    </td>

                    {/* Current Openings Badge */}
                    <td className="p-3 text-center">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800">
                        <Users className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                        {openings} {openings === 1 ? 'Opening' : 'Openings'}
                      </span>
                    </td>

                    {/* LinkedIn-style Applicants Badge */}
                    <td className="p-3 text-center">
                      {applicants < 25 ? (
                        <span
                          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-800"
                          title="Early Applicant: Under 25 people have applied on LinkedIn"
                        >
                          <Zap className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                          {applicants} applied (Early)
                        </span>
                      ) : applicants > 100 ? (
                        <span
                          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-medium bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-800"
                          title="High Competition: Over 100 applicants"
                        >
                          <Flame className="w-3 h-3 text-rose-600 dark:text-rose-400" />
                          {applicants} applied (High)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-medium bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
                          <Users className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                          {applicants} applied
                        </span>
                      )}
                    </td>

                    {/* ATS Score Before -> After */}
                    <td className="p-3 text-center">
                      <div className="inline-flex flex-col items-center">
                        <span className="text-xs font-bold text-green-600 dark:text-green-400">
                          {op.tailoredScore}%
                        </span>
                        <span className="text-[10px] text-slate-400">
                          Orig: {op.originalScore}% (+{op.tailoredScore - op.originalScore}%)
                        </span>
                      </div>
                    </td>

                    {/* Fit Outlook */}
                    <td className="p-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        op.outlook === 'EXCEPTIONAL' || op.outlook === 'VERY STRONG'
                          ? 'bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300 border border-green-100 dark:border-green-800'
                          : op.outlook === 'STRONG'
                          ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-100 dark:border-blue-800'
                          : 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border border-amber-100 dark:border-amber-800'
                      }`}>
                        {op.outlook}
                      </span>
                    </td>

                    {/* Priority Selector */}
                    <td className="p-3">
                      <select
                        value={op.priority}
                        onChange={(e) => handlePriorityChange(op, e.target.value as any)}
                        className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-2 py-1 text-slate-700 dark:text-slate-300 font-medium focus:outline-none"
                      >
                        <option value="High">High Priority</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                      </select>
                    </td>

                    {/* Status Selector */}
                    <td className="p-3">
                      <select
                        value={op.status}
                        onChange={(e) => handleStatusChange(op, e.target.value as any)}
                        className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md px-2 py-1 text-slate-700 dark:text-slate-300 font-medium focus:outline-none"
                      >
                        <option value="Discovered">Discovered</option>
                        <option value="Tailoring">Tailoring</option>
                        <option value="Applied">Applied</option>
                        <option value="Interviewing">Interviewing</option>
                        <option value="Offer">Offer Received</option>
                        <option value="Archived">Archived</option>
                      </select>
                    </td>

                    {/* Actions */}
                    <td className="p-3 text-right space-x-1.5">
                      <button
                        onClick={() => onSelectOpportunity(op.analysisId)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100 text-xs font-semibold transition"
                      >
                        Open <ArrowRight className="w-3 h-3" />
                      </button>

                      {opportunities.length > 1 && (
                        <button
                          onClick={() => onDeleteOpportunity(op.id)}
                          className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                          title="Delete opportunity"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filtered.length === 0 && (
            <div className="p-8 text-center text-slate-400 space-y-2">
              <p className="text-xs">No opportunities match your selected filter criteria.</p>
              <div className="flex items-center justify-center gap-2">
                <button
                  onClick={handleResetFilters}
                  className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-xs hover:bg-slate-200"
                >
                  Reset All Filters
                </button>
                <button
                  onClick={onOpenAnalyzeModal}
                  className="px-3.5 py-1.5 rounded-lg bg-blue-600 text-white font-semibold text-xs"
                >
                  Analyze a New Job
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
