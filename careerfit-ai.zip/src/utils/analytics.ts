/**
 * Mock Analytics Service
 * Tracks user engagement events, interactions, and feature usage.
 */

export interface AnalyticsEvent {
  id: string;
  eventName: string;
  timestamp: string;
  properties?: Record<string, unknown>;
}

class MockAnalyticsService {
  private readonly storageKey = 'careerfit_analytics_events';
  private events: AnalyticsEvent[] = [];

  constructor() {
    this.loadEvents();
  }

  private loadEvents() {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        this.events = JSON.parse(stored);
      }
    } catch {
      this.events = [];
    }
  }

  /**
   * Log an event with custom properties to console and storage
   */
  public track(eventName: string, properties: Record<string, unknown> = {}): AnalyticsEvent {
    const event: AnalyticsEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      eventName,
      timestamp: new Date().toISOString(),
      properties: {
        ...properties,
        userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
        url: typeof window !== 'undefined' ? window.location.href : '',
      },
    };

    this.events.unshift(event);
    if (this.events.length > 100) {
      this.events = this.events.slice(0, 100);
    }

    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.events));
    } catch {
      // Ignore localStorage quotas
    }

    // Structured console logging for dev visibility
    console.info(
      `%c[Analytics] 📊 Event: ${eventName}`,
      'color: #2563eb; font-weight: bold; background: #eff6ff; padding: 2px 6px; border-radius: 4px;',
      event.properties
    );

    return event;
  }

  /**
   * Convenience method to track top-bar Analyze Job button clicks
   */
  public trackAnalyzeJobClick(location: string = 'header_top_button', extraData?: Record<string, unknown>) {
    return this.track('analyze_job_clicked', {
      source: location,
      buttonId: '#btn-top-analyze-job',
      ...extraData,
    });
  }

  /**
   * Get all captured analytics events
   */
  public getEvents(): AnalyticsEvent[] {
    return [...this.events];
  }
}

export const analytics = new MockAnalyticsService();
