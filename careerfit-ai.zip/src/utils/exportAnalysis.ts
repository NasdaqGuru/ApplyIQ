import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { FullJobAnalysis, CandidateProfile } from '../types';

/**
 * Generate a comprehensive Markdown summary of the Job Analysis for clipboard or plaintext export.
 */
export function generateAnalysisMarkdown(analysis: FullJobAnalysis, profile?: CandidateProfile): string {
  const job = analysis.job;
  const scores = analysis.scores;

  const lines: string[] = [
    `# CAREERFIT AI — COMPREHENSIVE JOB FIT & ATS ANALYSIS`,
    `Generated: ${new Date().toLocaleDateString('en-US', { dateStyle: 'full' })}`,
    `Candidate: ${profile?.fullName || 'Candidate Profile'}`,
    ``,
    `--------------------------------------------------------------------------------`,
    `## TARGET OPPORTUNITY`,
    `--------------------------------------------------------------------------------`,
    `• Position: ${job.jobTitle}`,
    `• Employer: ${job.employer}`,
    `• Location: ${job.location || 'Not Specified'}`,
    `• Salary / Comp: ${job.salaryRange || 'Not Specified'}`,
    `• Department / Level: ${job.department || 'N/A'} • ${job.jobLevel || 'N/A'}`,
    ``,
    `--------------------------------------------------------------------------------`,
    `## STRATEGIC FIT & SCORING SUMMARY`,
    `--------------------------------------------------------------------------------`,
    `• ATS Match (Original):  ${scores.ats.ats_original}%`,
    `• ATS Match (Tailored):  ${scores.ats.ats_tailored}% (+${scores.ats.improvement_points || scores.ats.ats_tailored - scores.ats.ats_original} pts)`,
    `• Qualification Score:   ${scores.qualification.score}%`,
    `• Interview Ready Score: ${scores.interview.score}/100 (${scores.interview.tier})`,
    `• Application Outlook:   ${scores.outlook.rating} (${scores.outlook.range})`,
    `• Application Strategy:  ${analysis.applicationStrategy?.recommendation || 'APPLY'}`,
    ``,
    `--------------------------------------------------------------------------------`,
    `## EXECUTIVE ASSESSMENT`,
    `--------------------------------------------------------------------------------`,
    analysis.executiveAssessment || 'Candidate shows strong alignment with core role demands.',
    ``,
    `--------------------------------------------------------------------------------`,
    `## KEY DRIVERS & REPUTATIONAL ADVANTAGES`,
    `--------------------------------------------------------------------------------`,
  ];

  if (analysis.competitiveAdvantages && analysis.competitiveAdvantages.length > 0) {
    analysis.competitiveAdvantages.forEach((adv, idx) => {
      lines.push(`${idx + 1}. ${adv.advantage}`);
      lines.push(`   • Candidate Evidence: ${adv.candidateEvidence}`);
      lines.push(`   • Employer Value: ${adv.employerValue}`);
      if (adv.interviewTalkingPoint) {
        lines.push(`   • Interview Talking Point: ${adv.interviewTalkingPoint}`);
      }
    });
  } else if (analysis.whyYouMatch && analysis.whyYouMatch.length > 0) {
    analysis.whyYouMatch.forEach((reason, idx) => {
      lines.push(`${idx + 1}. ${reason}`);
    });
  } else {
    lines.push(`• Strong alignment with core technical and leadership demands.`);
  }

  lines.push(``);
  lines.push(`--------------------------------------------------------------------------------`);
  lines.push(`## DEAL-BREAKERS & RISK VULNERABILITIES`);
  lines.push(`--------------------------------------------------------------------------------`);

  if (analysis.dealBreakers && analysis.dealBreakers.length > 0) {
    analysis.dealBreakers.forEach((db, idx) => {
      lines.push(`${idx + 1}. [${db.severity.toUpperCase()}] ${db.issue}`);
      lines.push(`   • Potential Impact: ${db.impact}`);
      lines.push(`   • Mitigation Strategy: ${db.mitigationStrategy}`);
    });
  } else if (analysis.whatCouldHurt && analysis.whatCouldHurt.length > 0) {
    analysis.whatCouldHurt.forEach((risk, idx) => {
      lines.push(`${idx + 1}. ${risk}`);
    });
  } else {
    lines.push(`• No critical deal-breakers detected.`);
  }

  lines.push(``);
  lines.push(`--------------------------------------------------------------------------------`);
  lines.push(`## REQUIREMENT & COMPETENCY BREAKDOWN`);
  lines.push(`--------------------------------------------------------------------------------`);

  analysis.requirements.forEach((req, idx) => {
    lines.push(`${idx + 1}. ${req.requirement}`);
    lines.push(`   • Category: ${req.category} | Classification: ${req.classification}`);
    lines.push(`   • Match Status: ${req.matchLevel}`);
    lines.push(`   • Candidate Evidence: ${req.candidateEvidence}`);
    if (req.recommendedAction) {
      lines.push(`   • Recommendation: ${req.recommendedAction}`);
    }
  });

  if (analysis.interviewPrep?.likelyQuestions && analysis.interviewPrep.likelyQuestions.length > 0) {
    lines.push(``);
    lines.push(`--------------------------------------------------------------------------------`);
    lines.push(`## ANTICIPATED INTERVIEW QUESTIONS & TALKING POINTS`);
    lines.push(`--------------------------------------------------------------------------------`);

    analysis.interviewPrep.likelyQuestions.forEach((q, idx) => {
      lines.push(`${idx + 1}. ${q.question} (${q.category || 'Core'})`);
      lines.push(`   • Strategy: ${q.recommendedStrategy}`);
      if (q.candidateStarStory?.result) {
        lines.push(`   • Star Story Result: ${q.candidateStarStory.result}`);
      }
    });
  }

  if (analysis.recruiterTest) {
    lines.push(``);
    lines.push(`--------------------------------------------------------------------------------`);
    lines.push(`## RECRUITER 10-SECOND TEST & HIRING VIEW`);
    lines.push(`--------------------------------------------------------------------------------`);
    lines.push(`• Continue Reading: ${analysis.recruiterTest.continueReading}`);
    lines.push(`• First Impression: ${analysis.recruiterTest.firstImpression}`);
    if (analysis.recruiterTest.keyTakeaways?.length > 0) {
      lines.push(`• Key Takeaways: ${analysis.recruiterTest.keyTakeaways.join('; ')}`);
    }
  }

  lines.push(``);
  lines.push(`================================================================================`);
  lines.push(`CareerFit AI • Algorithmic Career Intelligence Engine`);
  lines.push(`================================================================================`);

  return lines.join('\n');
}

/**
 * Copy analysis to the user's system clipboard.
 */
export async function copyAnalysisToClipboard(
  analysis: FullJobAnalysis,
  profile?: CandidateProfile
): Promise<boolean> {
  try {
    const text = generateAnalysisMarkdown(analysis, profile);
    if (navigator?.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    } else {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.left = '-999999px';
      textarea.style.top = '-999999px';
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      const successful = document.execCommand('copy');
      document.body.removeChild(textarea);
      return successful;
    }
  } catch (err) {
    console.error('Failed to copy analysis to clipboard:', err);
    return false;
  }
}

/**
 * Generate a PDF document and trigger download using jsPDF and jsPDF-AutoTable.
 */
export function exportAnalysisToPdf(analysis: FullJobAnalysis, profile?: CandidateProfile): void {
  try {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 14;
    const contentWidth = pageWidth - margin * 2;
    let currentY = 14;

    // Header Background Bar
    doc.setFillColor(30, 41, 59); // slate-800
    doc.rect(0, 0, pageWidth, 28, 'F');

    // Title in Header
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(255, 255, 255);
    doc.text('CAREERFIT AI — STRATEGIC JOB FIT REPORT', margin, 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(203, 213, 225); // slate-300
    const subheader = `${analysis.job.jobTitle} at ${analysis.job.employer} | Candidate: ${profile?.fullName || 'Master Profile'}`;
    doc.text(subheader, margin, 18);
    doc.text(`Generated on ${new Date().toLocaleDateString('en-US', { dateStyle: 'medium' })}`, margin, 23);

    currentY = 34;

    // Section 1: Executive Scorecard Grid
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text('EXECUTIVE SCORECARD & MATCH METRICS', margin, currentY);
    currentY += 4;

    const scores = analysis.scores;
    const metricBoxes = [
      { label: 'ATS ORIGINAL', value: `${scores.ats.ats_original}%`, color: [100, 116, 139] },
      { label: 'ATS TAILORED', value: `${scores.ats.ats_tailored}%`, color: [16, 185, 129] },
      { label: 'QUALIFICATION', value: `${scores.qualification.score}%`, color: [37, 99, 235] },
      { label: 'INTERVIEW READY', value: `${scores.interview.score}/100`, color: [79, 70, 229] },
    ];

    const boxWidth = (contentWidth - 9) / 4;
    metricBoxes.forEach((box, i) => {
      const boxX = margin + i * (boxWidth + 3);
      doc.setFillColor(248, 250, 252); // slate-50
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.roundedRect(boxX, currentY, boxWidth, 16, 2, 2, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.5);
      doc.setTextColor(100, 116, 139);
      doc.text(box.label, boxX + boxWidth / 2, currentY + 5, { align: 'center' });

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(box.color[0], box.color[1], box.color[2]);
      doc.text(box.value, boxX + boxWidth / 2, currentY + 12.5, { align: 'center' });
    });

    currentY += 21;

    // Section 2: Opportunity & Alignment Summary
    doc.setFillColor(241, 245, 249); // slate-100
    doc.roundedRect(margin, currentY, contentWidth, 15, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(30, 41, 59);
    doc.text(`Application Outlook: ${scores.outlook.rating} (${scores.outlook.range}) • Strategy: ${analysis.applicationStrategy?.recommendation || 'APPLY'}`, margin + 3, currentY + 5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(71, 85, 105);
    const summaryText = analysis.executiveAssessment || 
      `Candidate demonstrates strong core competencies for ${analysis.job.jobTitle}. Tailoring improves overall score to ${scores.ats.ats_tailored}%.`;
    const wrappedSummary = doc.splitTextToSize(summaryText, contentWidth - 6);
    doc.text(wrappedSummary, margin + 3, currentY + 10);

    currentY += 19;

    // Section 3: Requirements Table (AutoTable)
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    doc.text('REQUIREMENTS & EVIDENCE MATRIX', margin, currentY);
    currentY += 3;

    const tableRows = analysis.requirements.map((req) => [
      req.requirement,
      req.category,
      req.classification,
      req.matchLevel,
      req.candidateEvidence || 'Verified in master profile',
    ]);

    autoTable(doc, {
      startY: currentY,
      margin: { left: margin, right: margin },
      head: [['Requirement', 'Category', 'Classification', 'Match Status', 'Candidate Evidence']],
      body: tableRows,
      theme: 'grid',
      headStyles: {
        fillColor: [30, 41, 59],
        textColor: [255, 255, 255],
        fontSize: 7,
        fontStyle: 'bold',
        cellPadding: 2,
      },
      bodyStyles: {
        fontSize: 6.5,
        cellPadding: 1.8,
        textColor: [51, 65, 85],
      },
      columnStyles: {
        0: { cellWidth: 48 },
        1: { cellWidth: 24 },
        2: { cellWidth: 26 },
        3: { cellWidth: 26 },
        4: { cellWidth: 'auto' },
      },
      didDrawPage: () => {
        doc.setFontSize(6.5);
        doc.setTextColor(148, 163, 184);
        doc.text(
          `CareerFit AI • Page ${doc.getNumberOfPages()} • Confidential Career Analysis`,
          pageWidth / 2,
          doc.internal.pageSize.getHeight() - 6,
          { align: 'center' }
        );
      },
    });

    const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY || currentY + 40;
    currentY = finalY + 8;

    // Check if new page is needed for Advantages and Deal Breakers
    if (currentY > 230) {
      doc.addPage();
      currentY = 18;
    }

    // Section 4: Competitive Advantages & Deal Breakers Grid
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    doc.text('COMPETITIVE ADVANTAGES & RISK MITIGATION', margin, currentY);
    currentY += 4;

    const halfWidth = (contentWidth - 5) / 2;

    // Left Box: Advantages
    doc.setFillColor(240, 253, 244); // green-50
    doc.setDrawColor(187, 247, 208); // green-200
    doc.roundedRect(margin, currentY, halfWidth, 36, 2, 2, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(22, 101, 52); // green-800
    doc.text('TOP COMPETITIVE ADVANTAGES', margin + 3, currentY + 5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(51, 65, 85);
    let advY = currentY + 10;
    const advantages = analysis.competitiveAdvantages || [];
    if (advantages.length > 0) {
      advantages.slice(0, 3).forEach((adv) => {
        const text = `• ${adv.advantage}`;
        const splitText = doc.splitTextToSize(text, halfWidth - 6);
        doc.text(splitText, margin + 3, advY);
        advY += splitText.length * 3.2 + 1;
      });
    } else {
      doc.text('• Strong alignment with core role demands and verified track record.', margin + 3, advY);
    }

    // Right Box: Deal Breakers
    const rightBoxX = margin + halfWidth + 5;
    doc.setFillColor(254, 242, 242); // rose-50
    doc.setDrawColor(254, 202, 202); // rose-200
    doc.roundedRect(rightBoxX, currentY, halfWidth, 36, 2, 2, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(153, 27, 27); // rose-800
    doc.text('PRIMARY DEAL-BREAKERS / RISKS', rightBoxX + 3, currentY + 5);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6.5);
    doc.setTextColor(51, 65, 85);
    let dbY = currentY + 10;
    const dealBreakers = analysis.dealBreakers || [];
    if (dealBreakers.length > 0) {
      dealBreakers.slice(0, 3).forEach((db) => {
        const text = `• [${db.severity}] ${db.issue}`;
        const splitText = doc.splitTextToSize(text, halfWidth - 6);
        doc.text(splitText, rightBoxX + 3, dbY);
        dbY += splitText.length * 3.2 + 1;
      });
    } else {
      doc.text('• No critical blocker issues identified.', rightBoxX + 3, dbY);
    }

    currentY += 42;

    // Interview Prep summary if space allows or on next page
    if (analysis.interviewPrep?.likelyQuestions && analysis.interviewPrep.likelyQuestions.length > 0) {
      if (currentY > 230) {
        doc.addPage();
        currentY = 18;
      }

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9.5);
      doc.setTextColor(15, 23, 42);
      doc.text('KEY INTERVIEW TALKING POINTS & QUESTIONS', margin, currentY);
      currentY += 4;

      analysis.interviewPrep.likelyQuestions.slice(0, 3).forEach((q, idx) => {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7);
        doc.setTextColor(30, 41, 59);
        doc.text(`Q${idx + 1}: ${q.question}`, margin, currentY);
        currentY += 3.5;

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(6.5);
        doc.setTextColor(71, 85, 105);
        const ans = `Strategy: ${q.recommendedStrategy || 'Emphasize architectural depth and concrete metrics'}`;
        const splitAns = doc.splitTextToSize(ans, contentWidth);
        doc.text(splitAns, margin + 3, currentY);
        currentY += splitAns.length * 3.2 + 2;
      });
    }

    // Save the PDF file
    const safeTitle = (analysis.job.jobTitle || 'Job')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 30);
    const safeCompany = (analysis.job.employer || 'Company')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 20);
    const fileName = `CareerFit_${safeCompany}_${safeTitle}_Analysis.pdf`;

    doc.save(fileName);
  } catch (err) {
    console.error('Failed to export PDF via jsPDF:', err);
    window.print();
  }
}
