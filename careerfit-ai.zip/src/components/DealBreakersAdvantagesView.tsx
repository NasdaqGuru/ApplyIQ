import React from 'react';
import {
  Award,
  Sparkles,
  ShieldAlert,
  Clock,
  Compass,
} from 'lucide-react';
import { FullJobAnalysis } from '../types';

interface DealBreakersAdvantagesViewProps {
  analysis: FullJobAnalysis;
  onNavigateToTab?: (tab: string) => void;
}

export const DealBreakersAdvantagesView: React.FC<DealBreakersAdvantagesViewProps> = ({
  analysis,
}) => {
  const { dealBreakers, competitiveAdvantages, gapBridging, applicationStrategy } = analysis;

  const getSeverityBadge = (severity: 'Critical' | 'Significant' | 'Minor') => {
    switch (severity) {
      case 'Critical':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border border-rose-100 dark:border-rose-800">
            Critical Risk
          </span>
        );
      case 'Significant':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-100 dark:border-amber-800">
            Significant Gap
          </span>
        );
      case 'Minor':
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
            Minor Variance
          </span>
        );
    }
  };

  const getRecommendationBadge = (rec: string) => {
    if (rec.includes('HIGH PRIORITY')) {
      return (
        <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-300 border border-green-200 dark:border-green-800 uppercase tracking-wide">
          {rec}
        </span>
      );
    }
    if (rec.includes('TARGETED')) {
      return (
        <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 border border-blue-200 dark:border-blue-800 uppercase tracking-wide">
          {rec}
        </span>
      );
    }
    return (
      <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-800 uppercase tracking-wide">
        {rec}
      </span>
    );
  };

  return (
    <div className="space-y-6 font-sans">
      {/* SECTION 1: OVERALL APPLICATION STRATEGY BANNER */}
      {applicationStrategy && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Strategic Application Decision
              </span>
              <h2 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                Executive Action Recommendation
              </h2>
            </div>
            <div>{getRecommendationBadge(applicationStrategy.recommendation)}</div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1.5">
              <span className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] block">
                🎯 Core Strategic Rationale:
              </span>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 text-xs">
                {applicationStrategy.strategicRationale}
              </p>
            </div>

            <div className="space-y-1.5">
              <span className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px] block">
                ✅ Top Mandatory Tweaks Before Submitting:
              </span>
              <ul className="space-y-2">
                {(applicationStrategy.top3Changes || []).map((change, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2.5 p-2 rounded-lg bg-green-50/40 dark:bg-green-950/20 border border-green-100 dark:border-green-900/30 text-green-900 dark:text-green-200 text-xs"
                  >
                    <span className="w-4 h-4 rounded-full bg-green-600 text-white font-bold flex items-center justify-center text-[10px] flex-shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed">{change}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: HIDDEN COMPETITIVE ADVANTAGES */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-100 dark:border-blue-800">
            <Award className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Hidden Competitive Advantages
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Strengths that set you apart from typical applicants and where to highlight them.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(competitiveAdvantages || []).map((adv, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-800/40 space-y-3 text-xs"
            >
              <div className="flex items-start justify-between gap-2">
                <h4 className="font-bold text-slate-900 dark:text-white text-xs">
                  {adv.advantage}
                </h4>
                <Sparkles className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
              </div>

              <div>
                <span className="font-bold text-slate-400 block mb-0.5 text-[11px]">Verified Profile Evidence:</span>
                <p className="text-slate-700 dark:text-slate-300 text-xs">{adv.candidateEvidence}</p>
              </div>

              <div>
                <span className="font-bold text-slate-400 block mb-0.5 text-[11px]">Why Employers Value It:</span>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-xs">{adv.employerValue}</p>
              </div>

              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-blue-700 dark:text-blue-300 font-medium text-xs">
                <strong>Placement Advice:</strong> {adv.placementRecommendation}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 3: POTENTIAL DEAL BREAKERS & VULNERABILITIES */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="w-9 h-9 rounded-lg bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center border border-rose-100 dark:border-rose-800">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Potential Deal Breakers & Honest Mitigations
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Clear identification of candidate vulnerabilities and truthful mitigation strategies.
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {(dealBreakers || []).map((db, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-xl border text-xs space-y-2.5 ${
                db.severity === 'Critical'
                  ? 'bg-rose-50/20 dark:bg-rose-950/10 border-rose-100 dark:border-rose-900/30'
                  : 'bg-amber-50/20 dark:bg-amber-950/10 border-amber-100 dark:border-amber-900/30'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="font-bold text-xs text-slate-900 dark:text-white">
                  {db.dealBreaker}
                </div>
                {getSeverityBadge(db.severity)}
              </div>

              <div>
                <span className="font-bold text-slate-400 block mb-0.5 text-[11px]">Why It Matters to Hiring Team:</span>
                <p className="text-slate-700 dark:text-slate-300 text-xs">{db.whyItMatters}</p>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="font-bold text-blue-700 dark:text-blue-400 block mb-1 text-xs">
                  🛡️ Truthful Mitigation Strategy:
                </span>
                <p className="text-slate-700 dark:text-slate-300 leading-relaxed text-xs">
                  {db.mitigationStrategy}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 4: GAP BRIDGING RECOMMENDATIONS */}
      {gapBridging && gapBridging.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-100 dark:border-blue-800">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Skill Gap-Bridging & Rapid Upskilling Path
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Actionable learning paths, certifications, and portfolio projects to convert weaknesses into strengths.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {gapBridging.map((gap, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-800/40 space-y-2.5 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 dark:text-white text-xs">
                    {gap.missingSkill}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      gap.isBridgeable
                        ? 'bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300 border border-green-100 dark:border-green-800'
                        : 'bg-rose-50 text-rose-700 border border-rose-100'
                    }`}
                  >
                    {gap.isBridgeable ? 'Bridgeable' : 'Hard Blocker'}
                  </span>
                </div>

                <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-xs">
                  {gap.recommendation}
                </p>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-200 dark:border-slate-700">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-blue-500" />
                    Estimated Time: <strong>{gap.timeToBridge}</strong>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

