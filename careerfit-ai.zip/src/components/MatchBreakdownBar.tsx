import React from 'react';
import { FullJobAnalysis } from '../types';

interface MatchBreakdownBarProps {
  analysis: FullJobAnalysis;
}

export const MatchBreakdownBar: React.FC<MatchBreakdownBarProps> = ({ analysis }) => {
  const bd = analysis.scores.ats.breakdown;

  const categories = [
    {
      name: 'Required Qualifications',
      score: bd.required_qualifications?.score || 92,
      color: 'bg-blue-600 dark:bg-blue-500',
    },
    {
      name: 'Leadership & Seniority',
      score: bd.job_title_seniority?.score || 95,
      color: 'bg-indigo-600 dark:bg-indigo-500',
    },
    {
      name: 'Core Responsibilities',
      score: bd.core_responsibilities?.score || 90,
      color: 'bg-cyan-600 dark:bg-cyan-500',
    },
    {
      name: 'Technology & Tool Stack',
      score: bd.tools_systems_tech?.score || 75,
      color: 'bg-amber-500 dark:bg-amber-400',
    },
    {
      name: 'Industry & Domain Knowledge',
      score: bd.industry_domain?.score || 85,
      color: 'bg-emerald-600 dark:bg-emerald-500',
    },
    {
      name: 'Education & Credentials',
      score: bd.education_certifications?.score || 100,
      color: 'bg-teal-600 dark:bg-teal-500',
    },
    {
      name: 'ATS Keyword Alignment',
      score: bd.ats_keyword_coverage?.score || 86,
      color: 'bg-purple-600 dark:bg-purple-500',
    },
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs font-sans">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Category Match Breakdown
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Granular candidate alignment across primary competency pillars
          </p>
        </div>
        <div className="text-xs font-semibold px-2.5 py-1 rounded-md bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
          Composite Score: <strong className="text-blue-600 dark:text-blue-400">{analysis.scores.ats.ats_tailored}%</strong>
        </div>
      </div>

      <div className="space-y-4">
        {categories.map((cat, idx) => {
          return (
            <div key={idx} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-700 dark:text-slate-300">
                  {cat.name}
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {cat.score}%
                </span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
                <div
                  className={`h-full ${cat.color} transition-all duration-700 rounded-full`}
                  style={{ width: `${cat.score}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

