import React, { useState, useEffect } from 'react';
import {
  Menu,
  X,
  Sparkles,
  Plus,
  ArrowRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import {
  CandidateProfile,
  FullJobAnalysis,
  SavedOpportunity,
  JobComparisonResult,
  CareerInsightSummary,
} from './types';
import { defaultProfile } from './data/defaultProfile';
import { defaultAnalysis } from './data/defaultAnalysis';
import { sampleJobs } from './data/sampleJobs';

import { Navigation } from './components/Navigation';
import { ScorecardHeader } from './components/ScorecardHeader';
import { ScoreExplanationModal } from './components/ScoreExplanationModal';
import { MatchBreakdownBar } from './components/MatchBreakdownBar';
import { RequirementsTable } from './components/RequirementsTable';
import { ResumeEditor } from './components/ResumeEditor';
import { CoverLetterView } from './components/CoverLetterView';
import { InterviewPrepView } from './components/InterviewPrepView';
import { HiringRecruiterView } from './components/HiringRecruiterView';
import { KeywordsView } from './components/KeywordsView';
import { DealBreakersAdvantagesView } from './components/DealBreakersAdvantagesView';
import { ApplicationsDashboard } from './components/ApplicationsDashboard';
import { JobComparisonView } from './components/JobComparisonView';
import { CareerInsightsView } from './components/CareerInsightsView';
import { CandidateProfileView } from './components/CandidateProfileView';
import { AnalyzeJobModal } from './components/AnalyzeJobModal';
import { ExportAnalysisMenu } from './components/ExportAnalysisMenu';
import { analytics } from './utils/analytics';

export default function App() {
  // LocalStorage-backed state or defaults
  const [profile, setProfile] = useState<CandidateProfile>(() => {
    const saved = localStorage.getItem('careerfit_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return defaultProfile;
  });

  const [analyses, setAnalyses] = useState<Record<string, FullJobAnalysis>>(() => {
    const saved = localStorage.getItem('careerfit_analyses');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Object.keys(parsed).length > 0) return parsed;
      } catch (e) {
        console.error(e);
      }
    }
    return { [defaultAnalysis.id]: defaultAnalysis };
  });

  const [currentAnalysisId, setCurrentAnalysisId] = useState<string>(() => {
    const saved = localStorage.getItem('careerfit_current_id');
    if (saved && analyses[saved]) return saved;
    return defaultAnalysis.id;
  });

  const [opportunities, setOpportunities] = useState<SavedOpportunity[]>(() => {
    const saved = localStorage.getItem('careerfit_opportunities');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0) return parsed;
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: 'op-1',
        jobId: sampleJobs[0].id,
        analysisId: defaultAnalysis.id,
        jobTitle: sampleJobs[0].jobTitle,
        company: sampleJobs[0].employer,
        location: sampleJobs[0].location || 'San Francisco, CA',
        state: 'CA',
        numberOfOpenings: 2,
        applicantCount: 18,
        salary: sampleJobs[0].salaryRange,
        originalScore: defaultAnalysis.scores.ats.ats_original,
        tailoredScore: defaultAnalysis.scores.ats.ats_tailored,
        outlook: defaultAnalysis.scores.outlook.rating,
        status: 'Tailoring',
        priority: 'High',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'op-2',
        jobId: sampleJobs[1]?.id || 'job-2',
        analysisId: 'sample-finpulse',
        jobTitle: sampleJobs[1]?.jobTitle || 'Senior Director of Finance & Operations',
        company: sampleJobs[1]?.employer || 'FinPulse Global Technologies',
        location: sampleJobs[1]?.location || 'New York, NY / Remote',
        state: 'NY',
        numberOfOpenings: 1,
        applicantCount: 74,
        salary: '$240,000 - $285,000 + 25% Bonus',
        originalScore: 78,
        tailoredScore: 92,
        outlook: 'VERY STRONG',
        status: 'Interviewing',
        priority: 'High',
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'op-3',
        jobId: sampleJobs[2]?.id || 'job-3',
        analysisId: 'sample-nexus',
        jobTitle: sampleJobs[2]?.jobTitle || 'Head of FP&A & Strategic Finance',
        company: sampleJobs[2]?.employer || 'Nexus Health AI',
        location: sampleJobs[2]?.location || 'Boston, MA / Remote',
        state: 'MA',
        numberOfOpenings: 3,
        applicantCount: 12,
        salary: '$215,000 - $250,000 + Stock Options',
        originalScore: 72,
        tailoredScore: 89,
        outlook: 'STRONG',
        status: 'Applied',
        priority: 'Medium',
        createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'op-4',
        jobId: sampleJobs[3]?.id || 'job-4',
        analysisId: 'sample-vertex',
        jobTitle: sampleJobs[3]?.jobTitle || 'VP of Finance & Corporate Development',
        company: sampleJobs[3]?.employer || 'Vertex Cloud Platforms',
        location: sampleJobs[3]?.location || 'Austin, TX (Hybrid)',
        state: 'TX',
        numberOfOpenings: 4,
        applicantCount: 142,
        salary: '$260,000 - $310,000 + Equity',
        originalScore: 81,
        tailoredScore: 95,
        outlook: 'EXCEPTIONAL',
        status: 'Offer',
        priority: 'High',
        createdAt: new Date(Date.now() - 86400000 * 7).toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'op-5',
        jobId: sampleJobs[4]?.id || 'job-5',
        analysisId: 'sample-apex',
        jobTitle: sampleJobs[4]?.jobTitle || 'Senior Manager, Strategic Financial Planning',
        company: sampleJobs[4]?.employer || 'Apex BioTech Innovations',
        location: sampleJobs[4]?.location || 'Seattle, WA (Remote)',
        state: 'WA',
        numberOfOpenings: 1,
        applicantCount: 38,
        salary: '$185,000 - $215,000 + Bonus',
        originalScore: 68,
        tailoredScore: 85,
        outlook: 'MODERATE',
        status: 'Discovered',
        priority: 'Low',
        createdAt: new Date(Date.now() - 86400000 * 9).toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];
  });

  const [activeTab, setActiveTab] = useState<string>('overview');
  const [isScoreModalOpen, setIsScoreModalOpen] = useState(false);
  const [isAnalyzeModalOpen, setIsAnalyzeModalOpen] = useState(false);
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('careerfit_dark') === 'true';
  });

  // Insights state
  const [careerInsights, setCareerInsights] = useState<CareerInsightSummary | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('careerfit_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('careerfit_analyses', JSON.stringify(analyses));
  }, [analyses]);

  useEffect(() => {
    localStorage.setItem('careerfit_opportunities', JSON.stringify(opportunities));
  }, [opportunities]);

  useEffect(() => {
    localStorage.setItem('careerfit_current_id', currentAnalysisId);
  }, [currentAnalysisId]);

  useEffect(() => {
    localStorage.setItem('careerfit_dark', isDarkMode.toString());
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Current active analysis
  const currentAnalysis = analyses[currentAnalysisId] || defaultAnalysis;

  // Handle analysis completion
  const handleAnalysisComplete = (newAnalysis: FullJobAnalysis) => {
    setAnalyses((prev) => ({
      ...prev,
      [newAnalysis.id]: newAnalysis,
    }));
    setCurrentAnalysisId(newAnalysis.id);

    // Add to pipeline
    const newOpportunity: SavedOpportunity = {
      id: `op-${Date.now()}`,
      jobId: `job-${Date.now()}`,
      analysisId: newAnalysis.id,
      jobTitle: newAnalysis.job.jobTitle,
      company: newAnalysis.job.employer,
      location: newAnalysis.job.location || 'Remote',
      state: newAnalysis.job.state || 'CA',
      numberOfOpenings: newAnalysis.job.numberOfOpenings || 1,
      applicantCount: newAnalysis.job.applicantCount || 20,
      salary: newAnalysis.job.salaryRange,
      originalScore: newAnalysis.scores.ats.ats_original,
      tailoredScore: newAnalysis.scores.ats.ats_tailored,
      outlook: newAnalysis.scores.outlook.rating,
      status: 'Discovered',
      priority: 'High',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setOpportunities((prev) => [newOpportunity, ...prev]);
    setActiveTab('overview');
  };

  // Update current analysis
  const handleUpdateAnalysis = (updated: FullJobAnalysis) => {
    setAnalyses((prev) => ({
      ...prev,
      [updated.id]: updated,
    }));
  };

  // Switch active opportunity
  const handleSelectOpportunity = (analysisId: string) => {
    if (analyses[analysisId]) {
      setCurrentAnalysisId(analysisId);
      setActiveTab('overview');
      setIsMobileNavOpen(false);
    }
  };

  // Update opportunity in pipeline
  const handleUpdateOpportunity = (updated: SavedOpportunity) => {
    setOpportunities((prev) => prev.map((op) => (op.id === updated.id ? updated : op)));
  };

  // Delete opportunity
  const handleDeleteOpportunity = (opId: string) => {
    setOpportunities((prev) => prev.filter((op) => op.id !== opId));
  };

  // Trigger compare view for selected IDs
  const handleCompareSelected = (selectedOpIds: string[]) => {
    const targetAnalysisIds = opportunities
      .filter((op) => selectedOpIds.includes(op.id))
      .map((op) => op.analysisId)
      .filter((id) => Boolean(analyses[id]));

    setCompareIds(targetAnalysisIds);
    setActiveTab('compare');
  };

  const compareAnalysesList = compareIds.length > 0
    ? compareIds.map((id) => analyses[id]).filter(Boolean)
    : Object.values(analyses);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100 antialiased">
      {/* DESKTOP FIXED SIDEBAR NAVIGATION */}
      <div className="hidden lg:flex flex-shrink-0">
        <Navigation
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
          }}
          currentAnalysis={currentAnalysis}
          onOpenAnalyzeModal={() => setIsAnalyzeModalOpen(true)}
          isDarkMode={isDarkMode}
          onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          opportunityCount={opportunities.length}
        />
      </div>

      {/* MOBILE DRAWER NAVIGATION */}
      {isMobileNavOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden bg-slate-900/80 backdrop-blur-xs">
          <div className="w-72 bg-slate-900 h-full shadow-2xl flex flex-col">
            <div className="p-4 flex justify-between items-center border-b border-slate-800">
              <span className="font-bold text-white text-sm">CareerFit AI</span>
              <button
                onClick={() => setIsMobileNavOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <Navigation
                activeTab={activeTab}
                onSelectTab={(tab) => {
                  setActiveTab(tab);
                  setIsMobileNavOpen(false);
                }}
                currentAnalysis={currentAnalysis}
                onOpenAnalyzeModal={() => {
                  setIsMobileNavOpen(false);
                  setIsAnalyzeModalOpen(true);
                }}
                isDarkMode={isDarkMode}
                onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
                opportunityCount={opportunities.length}
              />
            </div>
          </div>
          <div className="flex-1" onClick={() => setIsMobileNavOpen(false)} />
        </div>
      )}

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#F8FAFC] dark:bg-slate-950">
        {/* Top Minimalist Header */}
        <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-4 sm:px-8 shrink-0 z-20">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setIsMobileNavOpen(true)}
              className="p-1.5 rounded-lg lg:hidden text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate max-w-[200px] sm:max-w-md">
                {currentAnalysis?.job?.jobTitle || 'Career Intelligence'}
              </h2>
              {currentAnalysis && (
                <span className="hidden sm:inline-flex px-2 py-0.5 rounded-md text-[10px] font-semibold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
                  {currentAnalysis.job.employer}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-2.5">
            <button
              onClick={() => setActiveTab('profile')}
              className="hidden sm:inline-flex px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition"
            >
              Master Profile
            </button>
            <ExportAnalysisMenu analysis={currentAnalysis} profile={profile} />
            <button
              id="btn-top-analyze-job"
              onClick={() => {
                analytics.trackAnalyzeJobClick('header_top_button', {
                  currentJobTitle: currentAnalysis?.job?.jobTitle,
                  currentEmployer: currentAnalysis?.job?.employer,
                  currentScore: currentAnalysis?.scores?.ats?.ats_tailored,
                });
                setIsAnalyzeModalOpen(true);
              }}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition flex items-center gap-1.5 active:scale-98"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Analyze Job</span>
            </button>
          </div>
        </header>

        {/* Scrollable Main Body */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl w-full mx-auto font-sans">
          {/* TAB: OVERVIEW & SCORES */}
          {activeTab === 'overview' && currentAnalysis && (
            <div className="space-y-6">
              <ScorecardHeader
                analysis={currentAnalysis}
                onOpenScoreModal={() => setIsScoreModalOpen(true)}
                onNavigateToTab={(tab) => setActiveTab(tab)}
              />

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  <MatchBreakdownBar analysis={currentAnalysis} />
                  <RequirementsTable requirements={currentAnalysis.requirements} />
                </div>

                <div className="space-y-6">
                  <HiringRecruiterView analysis={currentAnalysis} />
                </div>
              </div>
            </div>
          )}

          {/* TAB: REQUIREMENTS MATRIX */}
          {activeTab === 'requirements' && currentAnalysis && (
            <div className="space-y-6">
              <RequirementsTable requirements={currentAnalysis.requirements} />
            </div>
          )}

          {/* TAB: TAILORED RESUME */}
          {activeTab === 'resume' && currentAnalysis && (
            <div className="space-y-6">
              <ResumeEditor
                profile={profile}
                analysis={currentAnalysis}
                onUpdateAnalysis={handleUpdateAnalysis}
              />
            </div>
          )}

          {/* TAB: COVER LETTER */}
          {activeTab === 'coverletter' && currentAnalysis && (
            <div className="space-y-6">
              <CoverLetterView
                profile={profile}
                analysis={currentAnalysis}
                onUpdateAnalysis={handleUpdateAnalysis}
              />
            </div>
          )}

          {/* TAB: INTERVIEW PREP & STAR */}
          {activeTab === 'interview' && currentAnalysis && (
            <div className="space-y-6">
              <InterviewPrepView
                profile={profile}
                analysis={currentAnalysis}
              />
            </div>
          )}

          {/* TAB: RECRUITER & HIRING MANAGER LENS */}
          {activeTab === 'hiring-manager' && currentAnalysis && (
            <div className="space-y-6">
              <HiringRecruiterView analysis={currentAnalysis} />
            </div>
          )}

          {/* TAB: ATS KEYWORDS */}
          {activeTab === 'keywords' && currentAnalysis && (
            <div className="space-y-6">
              <KeywordsView analysis={currentAnalysis} />
            </div>
          )}

          {/* TAB: DEAL BREAKERS & ADVANTAGES */}
          {activeTab === 'dealbreakers' && currentAnalysis && (
            <div className="space-y-6">
              <DealBreakersAdvantagesView
                analysis={currentAnalysis}
                onNavigateToTab={(tab) => setActiveTab(tab)}
              />
            </div>
          )}

          {/* TAB: APPLICATIONS PIPELINE & HISTORY */}
          {activeTab === 'pipeline' && (
            <div className="space-y-6">
              <ApplicationsDashboard
                opportunities={opportunities}
                currentAnalysisId={currentAnalysisId}
                onSelectOpportunity={handleSelectOpportunity}
                onUpdateOpportunity={handleUpdateOpportunity}
                onDeleteOpportunity={handleDeleteOpportunity}
                onOpenAnalyzeModal={() => setIsAnalyzeModalOpen(true)}
                onCompareSelected={handleCompareSelected}
              />
            </div>
          )}

          {/* TAB: MULTI-JOB COMPARE */}
          {activeTab === 'compare' && (
            <div className="space-y-6">
              <JobComparisonView
                analyses={compareAnalysesList}
                onSelectJob={handleSelectOpportunity}
              />
            </div>
          )}

          {/* TAB: CAREER INSIGHTS */}
          {activeTab === 'career-insights' && (
            <div className="space-y-6">
              <CareerInsightsView
                analyses={Object.values(analyses)}
                insights={careerInsights}
                onOpenAnalyzeModal={() => setIsAnalyzeModalOpen(true)}
              />
            </div>
          )}

          {/* TAB: MASTER CAREER PROFILE */}
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <CandidateProfileView
                profile={profile}
                onUpdateProfile={(updated) => setProfile(updated)}
              />
            </div>
          )}
        </main>
      </div>

      {/* "WHY THIS SCORE?" MODAL */}
      {currentAnalysis && (
        <ScoreExplanationModal
          isOpen={isScoreModalOpen}
          onClose={() => setIsScoreModalOpen(false)}
          analysis={currentAnalysis}
        />
      )}

      {/* ANALYZE JOB MODAL */}
      <AnalyzeJobModal
        isOpen={isAnalyzeModalOpen}
        onClose={() => setIsAnalyzeModalOpen(false)}
        profile={profile}
        onAnalysisComplete={handleAnalysisComplete}
      />
    </div>
  );
}
