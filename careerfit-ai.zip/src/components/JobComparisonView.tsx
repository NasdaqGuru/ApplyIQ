import React from 'react';
import {
  Layers,
  Award,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  MapPin,
  Users,
  Zap,
} from 'lucide-react';
import { FullJobAnalysis, JobComparisonResult } from '../types';

interface JobComparisonViewProps {
  analyses: FullJobAnalysis[];
  comparisonResult?: JobComparisonResult | null;
  onSelectJob: (analysisId: string) => void;
}

export const JobComparisonView: React.FC<JobComparisonViewProps> = ({
  analyses,
  comparisonResult,
  onSelectJob,
}) => {
  if (analyses.length < 2) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center space-y-3 font-sans">
        <Layers className="w-10 h-10 text-slate-300 mx-auto" />
        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          Select at least 2 opportunities to compare
        </h3>
        <p className="text-xs text-slate-500 max-w-md mx-auto">
          Head to the Pipeline dashboard and select checkboxes next to 2 to 5 opportunities to view side-by-side strategic comparisons.
        </p>
      </div>
    );
  }

  // Determine top fit heuristic
  const sortedByFit = [...analyses].sort(
    (a, b) => b.scores.ats.ats_tailored - a.scores.ats.ats_tailored
  );
  const bestFitJob = sortedByFit[0];

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner with AI Best Strategic Fit Recommendation */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                Comparative Intelligence
              </span>
              <span className="text-slate-300 dark:text-slate-700">•</span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Evaluating {analyses.length} opportunities side-by-side
              </span>
            </div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">
              Multi-Job Strategic Comparison
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 max-w-xl leading-relaxed">
              Evaluating opportunities side-by-side on ATS match, risk exposure, and career growth potential.
            </p>
          </div>

          <div className="p-3 bg-blue-50/70 dark:bg-blue-950/40 rounded-lg border border-blue-100 dark:border-blue-900/50 flex items-center gap-3">
            <Award className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
            <div className="text-xs">
              <span className="text-slate-500 dark:text-slate-400 block text-[10px] font-medium">Highest Strategic Fit:</span>
              <strong className="text-slate-900 dark:text-white text-xs">
                {bestFitJob.job.jobTitle} at {bestFitJob.job.employer} ({bestFitJob.scores.ats.ats_tailored}%)
              </strong>
            </div>
          </div>
        </div>

        {comparisonResult?.overallRecommendation && (
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-100 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            <strong className="text-slate-900 dark:text-white">Strategic Summary:</strong> {comparisonResult.overallRecommendation}
          </div>
        )}
      </div>

      {/* Side-by-Side Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {analyses.map((item) => {
          const isBest = item.id === bestFitJob.id;
          const criticalGaps = (item.dealBreakers || []).filter((db) => db.severity === 'Critical').length;

          return (
            <div
              key={item.id}
              className={`bg-white dark:bg-slate-900 border rounded-xl p-5 shadow-xs flex flex-col justify-between space-y-5 relative transition ${
                isBest
                  ? 'border-blue-500 dark:border-blue-400 ring-2 ring-blue-500/10'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              {isBest && (
                <div className="absolute -top-2.5 right-4 px-2.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-blue-600 text-white shadow-xs">
                  Best Match
                </div>
              )}

              {/* Job Header */}
              <div className="space-y-1">
                <div className="text-[11px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                  {item.job.employer}
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                  {item.job.jobTitle}
                </h3>
                <div className="text-xs text-slate-400 space-y-0.5 pt-0.5">
                  {item.job.location && (
                    <div className="flex items-center gap-1.5 text-[11px]">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>{item.job.location}</span>
                    </div>
                  )}
                  {item.job.salaryRange && (
                    <div className="flex items-center gap-1.5 text-green-600 dark:text-green-400 font-medium text-[11px]">
                      <DollarSign className="w-3 h-3" />
                      <span>{item.job.salaryRange}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 pt-1">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800">
                      <Users className="w-3 h-3" />
                      {item.job.numberOfOpenings || 1} {item.job.numberOfOpenings === 1 ? 'Opening' : 'Openings'}
                    </span>
                    {(item.job.applicantCount || 20) < 25 ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-800">
                        <Zap className="w-3 h-3 text-emerald-600" />
                        {item.job.applicantCount || 18} applied (Early)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                        <Users className="w-3 h-3 text-slate-500" />
                        {item.job.applicantCount || 20} applied
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Scorecard Metrics */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 uppercase font-medium block">
                    ATS Match
                  </span>
                  <div className="text-lg font-bold text-green-600 dark:text-green-400 mt-0.5">
                    {item.scores.ats.ats_tailored}%
                  </div>
                  <span className="text-[10px] text-slate-400">
                    Orig: {item.scores.ats.ats_original}%
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 uppercase font-medium block">
                    Qualification
                  </span>
                  <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-0.5">
                    {item.scores.qualification.score}%
                  </div>
                  <span className="text-[10px] text-slate-400">
                    Fit: {item.scores.outlook.rating}
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 uppercase font-medium block">
                    Interview Ready
                  </span>
                  <div className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                    {item.scores.interview.score}
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {item.scores.interview.tier}
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 uppercase font-medium block">
                    Deal Breakers
                  </span>
                  <div className={`text-lg font-bold mt-0.5 ${criticalGaps > 0 ? 'text-rose-600' : 'text-slate-800 dark:text-slate-200'}`}>
                    {criticalGaps}
                  </div>
                  <span className="text-[10px] text-slate-400">
                    Critical Risks
                  </span>
                </div>
              </div>

              {/* Key Advantage & Key Risk */}
              <div className="space-y-2 text-xs">
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 rounded-lg space-y-0.5">
                  <span className="font-semibold text-green-700 dark:text-green-400 flex items-center gap-1 text-[11px]">
                    <CheckCircle2 className="w-3 h-3 text-green-600" />
                    Top Advantage
                  </span>
                  <p className="text-slate-600 dark:text-slate-400 text-[11px] line-clamp-2">
                    {item.competitiveAdvantages?.[0]?.advantage || item.whyYouMatch?.[0] || 'Strong leadership alignment'}
                  </p>
                </div>

                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 rounded-lg space-y-0.5">
                  <span className="font-semibold text-rose-700 dark:text-rose-400 flex items-center gap-1 text-[11px]">
                    <AlertTriangle className="w-3 h-3 text-rose-600" />
                    Primary Vulnerability
                  </span>
                  <p className="text-slate-600 dark:text-slate-400 text-[11px] line-clamp-2">
                    {item.dealBreakers?.[0]?.dealBreaker || item.whatCouldHurt?.[0] || 'Specific domain tech overlap'}
                  </p>
                </div>
              </div>

              {/* Action Button */}
              <button
                onClick={() => onSelectJob(item.id)}
                className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition flex items-center justify-center gap-1.5 shadow-xs"
              >
                Open Full Analysis <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

