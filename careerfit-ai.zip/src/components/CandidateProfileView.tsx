import React, { useState } from 'react';
import {
  User,
  FileText,
  Upload,
  Sparkles,
  ShieldCheck,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Building,
  GraduationCap,
  Award,
  Link as LinkIcon,
  Save,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { CandidateProfile, WorkExperience, EducationItem, CertificationItem } from '../types';

interface CandidateProfileViewProps {
  profile: CandidateProfile;
  onUpdateProfile: (profile: CandidateProfile) => void;
}

export const CandidateProfileView: React.FC<CandidateProfileViewProps> = ({
  profile,
  onUpdateProfile,
}) => {
  const [formData, setFormData] = useState<CandidateProfile>(profile);
  const [pastedText, setPastedText] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [newSkill, setNewSkill] = useState('');

  // Handle parse resume from raw text or file
  const handleParseRawText = async (textToParse: string) => {
    if (!textToParse.trim()) {
      setParseError('Please paste or upload resume text to parse.');
      return;
    }

    setIsParsing(true);
    setParseError(null);

    try {
      const res = await fetch('/api/parse-resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resumeText: textToParse }),
      });

      if (!res.ok) {
        throw new Error(`Failed to parse resume: ${res.statusText}`);
      }

      const parsed: CandidateProfile = await res.json();
      setFormData(parsed);
      onUpdateProfile(parsed);
      setShowSuccessToast(true);
      setTimeout(() => setShowSuccessToast(false), 3000);
      setPastedText('');
    } catch (err: any) {
      console.error(err);
      setParseError(err.message || 'Error parsing resume text. Please check format.');
    } finally {
      setIsParsing(false);
    }
  };

  // Handle file upload (txt, docx, pdf text)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        handleParseRawText(content);
      }
    };
    reader.readAsText(file);
  };

  const handleSaveProfile = () => {
    onUpdateProfile(formData);
    setShowSuccessToast(true);
    setTimeout(() => setShowSuccessToast(false), 3000);
  };

  const handleAddSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData({
        ...formData,
        skills: [...formData.skills, newSkill.trim()],
      });
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setFormData({
      ...formData,
      skills: formData.skills.filter((s) => s !== skillToRemove),
    });
  };

  const handleAddExperience = () => {
    const newExp: WorkExperience = {
      id: `exp-${Date.now()}`,
      company: 'New Company',
      title: 'Job Title',
      location: 'City, State',
      startDate: '2023',
      endDate: 'Present',
      bullets: ['Led key initiatives delivering measurable results.'],
    };
    setFormData({
      ...formData,
      experience: [newExp, ...formData.experience],
    });
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              Source of Truth
            </span>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Immutable Candidate Record
            </span>
          </div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">
            Master Career Profile
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 max-w-xl leading-relaxed">
            CareerFit AI uses your Master Profile as the sole factual anchor. Nothing is fabricated or exaggerated beyond these documented facts.
          </p>
        </div>

        <button
          onClick={handleSaveProfile}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition shadow-xs"
        >
          <Save className="w-3.5 h-3.5" />
          Save Master Profile
        </button>
      </div>

      {showSuccessToast && (
        <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/60 border border-green-200 dark:border-green-800 text-green-700 dark:text-green-300 text-xs font-semibold shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            <span>Master Career Profile saved and updated successfully!</span>
          </div>
        </div>
      )}

      {/* Parse or Upload Section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              AI Resume Parser & Import
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">PDF / DOCX text / Plain text</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-2.5">
            <textarea
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder="Paste raw resume text here to automatically extract and populate your structured master profile..."
              rows={4}
              className="w-full p-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            {parseError && (
              <div className="p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{parseError}</span>
              </div>
            )}
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => handleParseRawText(pastedText)}
                disabled={isParsing || !pastedText.trim()}
                className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5 transition"
              >
                {isParsing ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    Parsing with AI...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3 h-3" />
                    Parse Resume Text
                  </>
                )}
              </button>

              <label className="cursor-pointer px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium flex items-center gap-1.5 transition">
                <Upload className="w-3 h-3" />
                Upload Resume File (.txt)
                <input
                  type="file"
                  accept=".txt,.md,.json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs space-y-1.5">
            <div className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 text-xs">
              <ShieldCheck className="w-3.5 h-3.5 text-green-600" />
              <span>Anti-Hallucination Anchor</span>
            </div>
            <p className="text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">
              Every detail in this Master Profile serves as the ground truth. CareerFit AI is constrained to never fabricate companies, titles, or metrics that are absent from this record.
            </p>
          </div>
        </div>
      </div>

      {/* Editable Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Left Column: Personal Info, Headline, Skills */}
        <div className="space-y-4 sm:space-y-6">
          {/* Personal Info */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-xs space-y-3.5 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-xs flex items-center gap-2">
              <User className="w-3.5 h-3.5 text-blue-600" />
              Contact Information
            </h3>

            <div className="space-y-2.5">
              <div>
                <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                  Full Name:
                </label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                  Headline:
                </label>
                <input
                  type="text"
                  value={formData.headline}
                  onChange={(e) => setFormData({ ...formData, headline: e.target.value })}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                    Email:
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                    Phone:
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                  Location:
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                  LinkedIn / Portfolio URL:
                </label>
                <input
                  type="text"
                  value={formData.linkedinUrl || ''}
                  onChange={(e) => setFormData({ ...formData, linkedinUrl: e.target.value })}
                  placeholder="https://linkedin.com/in/..."
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Skills Management */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-xs space-y-3.5 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-xs flex items-center justify-between">
              <span>Skills & Competencies</span>
              <span className="text-slate-400 font-normal text-[11px]">{formData.skills.length} skills</span>
            </h3>

            <div className="flex gap-2">
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddSkill()}
                placeholder="Add skill (e.g., Python)..."
                className="flex-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
              />
              <button
                onClick={handleAddSkill}
                className="px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5 max-h-60 overflow-y-auto pt-1">
              {formData.skills.map((skill, idx) => (
                <span
                  key={idx}
                  className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-[11px]"
                >
                  <span>{skill}</span>
                  <button
                    onClick={() => handleRemoveSkill(skill)}
                    className="text-slate-400 hover:text-rose-500 text-xs"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Summary & Work Experience */}
        <div className="lg:col-span-2 space-y-4 sm:space-y-6">
          {/* Executive Summary */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-xs space-y-2.5 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-xs">
              Master Executive Summary
            </h3>
            <textarea
              value={formData.summary}
              onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
              rows={4}
              className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white leading-relaxed text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Work Experience */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-xs space-y-3.5 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Building className="w-3.5 h-3.5 text-blue-600" />
                <h3 className="font-bold text-slate-900 dark:text-white text-xs">
                  Documented Work Experience
                </h3>
              </div>
              <button
                onClick={handleAddExperience}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 font-semibold text-xs hover:bg-blue-100 transition"
              >
                <Plus className="w-3 h-3" />
                Add Position
              </button>
            </div>

            <div className="space-y-4">
              {formData.experience.map((exp, expIdx) => (
                <div
                  key={exp.id}
                  className="p-3.5 rounded-lg bg-slate-50/50 dark:bg-slate-800/30 border border-slate-100 dark:border-slate-800 space-y-2.5"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="font-medium text-slate-700 dark:text-slate-300 block mb-0.5 text-[11px]">
                        Company Name:
                      </label>
                      <input
                        type="text"
                        value={exp.company}
                        onChange={(e) => {
                          const updated = [...formData.experience];
                          updated[expIdx].company = e.target.value;
                          setFormData({ ...formData, experience: updated });
                        }}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="font-medium text-slate-700 dark:text-slate-300 block mb-0.5 text-[11px]">
                        Job Title:
                      </label>
                      <input
                        type="text"
                        value={exp.title}
                        onChange={(e) => {
                          const updated = [...formData.experience];
                          updated[expIdx].title = e.target.value;
                          setFormData({ ...formData, experience: updated });
                        }}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="font-medium text-slate-700 dark:text-slate-300 block mb-0.5 text-[11px]">
                        Dates (Start - End):
                      </label>
                      <input
                        type="text"
                        value={`${exp.startDate} - ${exp.endDate}`}
                        onChange={(e) => {
                          const parts = e.target.value.split('-');
                          const updated = [...formData.experience];
                          updated[expIdx].startDate = parts[0]?.trim() || '';
                          updated[expIdx].endDate = parts[1]?.trim() || '';
                          setFormData({ ...formData, experience: updated });
                        }}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="font-medium text-slate-700 dark:text-slate-300 block mb-0.5 text-[11px]">
                        Location:
                      </label>
                      <input
                        type="text"
                        value={exp.location || ''}
                        onChange={(e) => {
                          const updated = [...formData.experience];
                          updated[expIdx].location = e.target.value;
                          setFormData({ ...formData, experience: updated });
                        }}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Bullet points */}
                  <div>
                    <label className="font-medium text-slate-700 dark:text-slate-300 block mb-0.5 text-[11px]">
                      Achievement Bullets (One per line):
                    </label>
                    <textarea
                      value={exp.bullets.join('\n')}
                      onChange={(e) => {
                        const updated = [...formData.experience];
                        updated[expIdx].bullets = e.target.value.split('\n').filter((b) => b.trim().length > 0);
                        setFormData({ ...formData, experience: updated });
                      }}
                      rows={3}
                      className="w-full p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 leading-relaxed font-sans text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
