import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  Copy,
  Check,
  Edit3,
  CheckCircle2,
} from 'lucide-react';
import { CandidateProfile, FullJobAnalysis } from '../types';
import {
  downloadCoverLetterDocx,
  printFormattedDocument,
  getExportFilenames,
} from '../utils/exportUtils';

interface CoverLetterViewProps {
  profile: CandidateProfile;
  analysis: FullJobAnalysis;
  onUpdateAnalysis: (updated: FullJobAnalysis) => void;
}

export const CoverLetterView: React.FC<CoverLetterViewProps> = ({
  profile,
  analysis,
  onUpdateAnalysis,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [copied, setCopied] = useState(false);
  const cl = analysis.coverLetter;
  const filenames = getExportFilenames(profile, analysis);

  const [formData, setFormData] = useState({
    opening: cl.opening,
    employerNeed: cl.employerNeed,
    candidateEvidence: cl.candidateEvidence,
    differentiator: cl.differentiator,
    closing: cl.closing,
  });

  const handleSave = () => {
    const fullText = [
      `Dear Hiring Committee,`,
      '',
      formData.opening,
      '',
      formData.employerNeed,
      '',
      formData.candidateEvidence,
      '',
      formData.differentiator,
      '',
      formData.closing,
      '',
      `Sincerely,`,
      profile.fullName,
    ].join('\n\n');

    onUpdateAnalysis({
      ...analysis,
      coverLetter: {
        ...formData,
        fullText,
      },
    });
    setIsEditing(false);
  };

  const handleCopy = () => {
    const fullText = [
      profile.fullName.toUpperCase(),
      `${profile.location} | ${profile.email} | ${profile.phone}`,
      '',
      new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      '',
      `Hiring Committee`,
      analysis.job.employer,
      `Re: Application for ${analysis.job.jobTitle}`,
      '',
      'Dear Hiring Committee,',
      '',
      formData.opening,
      '',
      formData.employerNeed,
      '',
      formData.candidateEvidence,
      '',
      formData.differentiator,
      '',
      formData.closing,
      '',
      'Sincerely,',
      profile.fullName,
    ].join('\n');

    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Action Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" />
              Strategic One-Page Cover Letter
            </h2>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
              Role Tailored
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Addresses employer core challenges without repeating standard resume bullets
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {isEditing ? (
            <button
              onClick={handleSave}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-600 hover:bg-green-700 text-white text-xs font-semibold shadow-xs transition"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Save Changes
            </button>
          ) : (
            <button
              onClick={() => setIsEditing(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium transition"
            >
              <Edit3 className="w-3.5 h-3.5" />
              Edit Sections
            </button>
          )}

          <button
            onClick={() => downloadCoverLetterDocx(profile, analysis)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition"
          >
            <Download className="w-3.5 h-3.5" />
            Word (.docx)
          </button>

          <button
            onClick={() => printFormattedDocument('printable-cover-letter', filenames.coverLetterPdf)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium transition"
          >
            <Printer className="w-3.5 h-3.5" />
            Print / PDF
          </button>

          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
            title="Copy Cover Letter Text"
          >
            {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Structured Cover Letter Canvas */}
      <div
        id="printable-cover-letter"
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 sm:p-12 shadow-xs max-w-4xl mx-auto space-y-6 text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-normal"
      >
        {/* Candidate Header */}
        <div className="border-b border-slate-100 dark:border-slate-800 pb-4 text-center space-y-1">
          <h1 className="text-xl font-bold text-slate-900 dark:text-white uppercase tracking-tight">
            {profile.fullName}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {profile.location}  •  {profile.email}  •  {profile.phone}
            {profile.linkedinUrl && <span>  •  {profile.linkedinUrl}</span>}
          </p>
        </div>

        {/* Date & Employer Recipient Info */}
        <div className="space-y-1 text-xs text-slate-600 dark:text-slate-400 pt-1">
          <div>
            {new Date().toLocaleDateString('en-US', {
              month: 'long',
              day: 'numeric',
              year: 'numeric',
            })}
          </div>
          <div className="font-semibold text-slate-900 dark:text-white pt-1">
            Hiring Leadership Team
          </div>
          <div>{analysis.job.employer}</div>
          {analysis.job.location && <div>{analysis.job.location}</div>}
          <div className="font-medium text-slate-800 dark:text-slate-200 pt-1">
            <strong>Re:</strong> Application for {analysis.job.jobTitle}
          </div>
        </div>

        <div className="pt-2 font-medium">Dear Hiring Committee,</div>

        {/* SECTION 1: OPENING */}
        <div className="space-y-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            Opening & Compelling Fit
          </div>
          {isEditing ? (
            <textarea
              value={formData.opening}
              onChange={(e) => setFormData({ ...formData, opening: e.target.value })}
              rows={3}
              className="w-full p-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          ) : (
            <p>{formData.opening}</p>
          )}
        </div>

        {/* SECTION 2: EMPLOYER NEED */}
        <div className="space-y-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            Employer Need & Strategic Context
          </div>
          {isEditing ? (
            <textarea
              value={formData.employerNeed}
              onChange={(e) => setFormData({ ...formData, employerNeed: e.target.value })}
              rows={4}
              className="w-full p-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          ) : (
            <p>{formData.employerNeed}</p>
          )}
        </div>

        {/* SECTION 3: CANDIDATE EVIDENCE */}
        <div className="space-y-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            Proven Candidate Evidence
          </div>
          {isEditing ? (
            <textarea
              value={formData.candidateEvidence}
              onChange={(e) => setFormData({ ...formData, candidateEvidence: e.target.value })}
              rows={4}
              className="w-full p-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          ) : (
            <p>{formData.candidateEvidence}</p>
          )}
        </div>

        {/* SECTION 4: DIFFERENTIATOR */}
        <div className="space-y-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            Distinctive Value & Differentiator
          </div>
          {isEditing ? (
            <textarea
              value={formData.differentiator}
              onChange={(e) => setFormData({ ...formData, differentiator: e.target.value })}
              rows={3}
              className="w-full p-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          ) : (
            <p>{formData.differentiator}</p>
          )}
        </div>

        {/* SECTION 5: CLOSING */}
        <div className="space-y-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            Professional Closing
          </div>
          {isEditing ? (
            <textarea
              value={formData.closing}
              onChange={(e) => setFormData({ ...formData, closing: e.target.value })}
              rows={2}
              className="w-full p-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          ) : (
            <p>{formData.closing}</p>
          )}
        </div>

        {/* Sign-off */}
        <div className="pt-3 space-y-1 text-xs">
          <div>Sincerely,</div>
          <div className="font-bold text-xs text-slate-900 dark:text-white pt-1">
            {profile.fullName}
          </div>
        </div>
      </div>
    </div>
  );
};

