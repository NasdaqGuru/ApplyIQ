import { Document, Paragraph, TextRun, HeadingLevel, AlignmentType, Packer, BorderStyle } from 'docx';
import { CandidateProfile, FullJobAnalysis } from '../types';

function sanitizeFilename(text: string): string {
  return text.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/_+/g, '_');
}

export function getExportFilenames(profile: CandidateProfile, analysis: FullJobAnalysis) {
  const nameParts = profile.fullName.trim().split(' ');
  const firstName = nameParts[0] || 'Candidate';
  const lastName = nameParts.length > 1 ? nameParts[nameParts.length - 1] : 'Resume';
  const company = analysis.job.employer || 'Company';
  const position = analysis.job.jobTitle || 'Role';

  const base = `${sanitizeFilename(firstName)}_${sanitizeFilename(lastName)}_${sanitizeFilename(company)}_${sanitizeFilename(position)}`;
  return {
    resumeDocx: `${base}_Resume.docx`,
    resumePdf: `${base}_Resume.pdf`,
    coverLetterDocx: `${base}_Cover_Letter.docx`,
    coverLetterPdf: `${base}_Cover_Letter.pdf`,
    matchReportPdf: `${base}_Match_Analysis.pdf`,
  };
}

export async function downloadResumeDocx(profile: CandidateProfile, analysis: FullJobAnalysis) {
  const tailored = analysis.tailoredResume;
  const filenames = getExportFilenames(profile, analysis);

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 720, // 0.5 in
              right: 720,
              bottom: 720,
              left: 720,
            },
          },
        },
        children: [
          // Name Header
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: profile.fullName.toUpperCase(),
                bold: true,
                size: 32, // 16pt
                font: 'Calibri',
                color: '1A202C',
              }),
            ],
          }),

          // Contact info line
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 },
            children: [
              new TextRun({
                text: `${profile.location}  |  ${profile.email}  |  ${profile.phone}${profile.linkedinUrl ? `  |  ${profile.linkedinUrl}` : ''}`,
                size: 19, // 9.5pt
                font: 'Calibri',
                color: '4A5568',
              }),
            ],
          }),

          // Target Headline
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 240 },
            children: [
              new TextRun({
                text: tailored.headline || profile.headline,
                bold: true,
                size: 22,
                font: 'Calibri',
                color: '2B6CB0',
              }),
            ],
          }),

          // Summary Section Heading
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 200, after: 100 },
            border: {
              bottom: {
                color: '2B6CB0',
                space: 1,
                style: BorderStyle.SINGLE,
                size: 6,
              },
            },
            children: [
              new TextRun({
                text: 'EXECUTIVE SUMMARY',
                bold: true,
                size: 22,
                font: 'Calibri',
                color: '1A202C',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 200 },
            children: [
              new TextRun({
                text: tailored.summary,
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),

          // Core Competencies Heading
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 160, after: 100 },
            border: {
              bottom: {
                color: '2B6CB0',
                space: 1,
                style: BorderStyle.SINGLE,
                size: 6,
              },
            },
            children: [
              new TextRun({
                text: 'CORE COMPETENCIES & EXPERTISE',
                bold: true,
                size: 22,
                font: 'Calibri',
                color: '1A202C',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 200 },
            children: [
              new TextRun({
                text: (tailored.coreCompetencies || []).join('  •  '),
                size: 20,
                font: 'Calibri',
                bold: true,
                color: '2D3748',
              }),
            ],
          }),

          // Selected Achievements Heading (if present)
          ...(tailored.selectedAchievements && tailored.selectedAchievements.length > 0
            ? [
                new Paragraph({
                  heading: HeadingLevel.HEADING_2,
                  spacing: { before: 160, after: 100 },
                  border: {
                    bottom: {
                      color: '2B6CB0',
                      space: 1,
                      style: BorderStyle.SINGLE,
                      size: 6,
                    },
                  },
                  children: [
                    new TextRun({
                      text: 'SELECTED KEY ACHIEVEMENTS',
                      bold: true,
                      size: 22,
                      font: 'Calibri',
                      color: '1A202C',
                    }),
                  ],
                }),
                ...tailored.selectedAchievements.map(
                  (ach) =>
                    new Paragraph({
                      bullet: { level: 0 },
                      spacing: { after: 60 },
                      children: [
                        new TextRun({
                          text: ach,
                          size: 20,
                          font: 'Calibri',
                        }),
                      ],
                    })
                ),
              ]
            : []),

          // Professional Experience Heading
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 200, after: 100 },
            border: {
              bottom: {
                color: '2B6CB0',
                space: 1,
                style: BorderStyle.SINGLE,
                size: 6,
              },
            },
            children: [
              new TextRun({
                text: 'PROFESSIONAL EXPERIENCE',
                bold: true,
                size: 22,
                font: 'Calibri',
                color: '1A202C',
              }),
            ],
          }),

          // Experience entries
          ...tailored.experience.flatMap((exp) => [
            new Paragraph({
              spacing: { before: 140, after: 40 },
              children: [
                new TextRun({
                  text: `${exp.originalCompany}`,
                  bold: true,
                  size: 21,
                  font: 'Calibri',
                }),
                new TextRun({
                  text: `  |  ${exp.originalTitle}${exp.location ? ` — ${exp.location}` : ''}`,
                  italics: true,
                  size: 20,
                  font: 'Calibri',
                }),
                new TextRun({
                  text: `\t${exp.dates}`,
                  bold: true,
                  size: 20,
                  font: 'Calibri',
                }),
              ],
            }),
            ...exp.bullets.map((bullet) => {
              const activeText =
                bullet.status === 'original'
                  ? bullet.originalText
                  : bullet.tailoredText || bullet.originalText;
              return new Paragraph({
                bullet: { level: 0 },
                spacing: { after: 50 },
                children: [
                  new TextRun({
                    text: activeText,
                    size: 20,
                    font: 'Calibri',
                  }),
                ],
              });
            }),
          ]),

          // Education Section
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 200, after: 100 },
            border: {
              bottom: {
                color: '2B6CB0',
                space: 1,
                style: BorderStyle.SINGLE,
                size: 6,
              },
            },
            children: [
              new TextRun({
                text: 'EDUCATION & CREDENTIALS',
                bold: true,
                size: 22,
                font: 'Calibri',
                color: '1A202C',
              }),
            ],
          }),
          ...(profile.education || []).map(
            (edu) =>
              new Paragraph({
                spacing: { after: 40 },
                children: [
                  new TextRun({
                    text: `${edu.degree} in ${edu.field}`,
                    bold: true,
                    size: 20,
                    font: 'Calibri',
                  }),
                  new TextRun({
                    text: ` — ${edu.institution} (${edu.graduationYear})`,
                    size: 20,
                    font: 'Calibri',
                  }),
                ],
              })
          ),
          ...(profile.certifications || []).map(
            (cert) =>
              new Paragraph({
                spacing: { after: 40 },
                children: [
                  new TextRun({
                    text: `• ${cert.name}`,
                    bold: true,
                    size: 20,
                    font: 'Calibri',
                  }),
                  new TextRun({
                    text: ` — ${cert.issuer} ${cert.year ? `(${cert.year})` : ''}`,
                    size: 20,
                    font: 'Calibri',
                  }),
                ],
              })
          ),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filenames.resumeDocx;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export async function downloadCoverLetterDocx(profile: CandidateProfile, analysis: FullJobAnalysis) {
  const cl = analysis.coverLetter;
  const filenames = getExportFilenames(profile, analysis);

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1000,
              right: 1000,
              bottom: 1000,
              left: 1000,
            },
          },
        },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: profile.fullName.toUpperCase(),
                bold: true,
                size: 28,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 300 },
            children: [
              new TextRun({
                text: `${profile.location}  |  ${profile.email}  |  ${profile.phone}`,
                size: 19,
                font: 'Calibri',
                color: '4A5568',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 200 },
            children: [
              new TextRun({
                text: new Date().toLocaleDateString('en-US', {
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric',
                }),
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 200 },
            children: [
              new TextRun({
                text: `Hiring Team\n${analysis.job.employer}\nRe: Application for ${analysis.job.jobTitle}`,
                bold: true,
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 180 },
            children: [
              new TextRun({
                text: 'Dear Hiring Committee,',
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 180 },
            children: [
              new TextRun({
                text: cl.opening,
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 180 },
            children: [
              new TextRun({
                text: cl.employerNeed,
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 180 },
            children: [
              new TextRun({
                text: cl.candidateEvidence,
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 180 },
            children: [
              new TextRun({
                text: cl.differentiator,
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 240 },
            children: [
              new TextRun({
                text: cl.closing,
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            spacing: { after: 60 },
            children: [
              new TextRun({
                text: 'Sincerely,',
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: profile.fullName,
                bold: true,
                size: 20,
                font: 'Calibri',
              }),
            ],
          }),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filenames.coverLetterDocx;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportPlainTextResume(profile: CandidateProfile, analysis: FullJobAnalysis) {
  const tailored = analysis.tailoredResume;
  const lines: string[] = [
    profile.fullName.toUpperCase(),
    `${profile.location} | ${profile.email} | ${profile.phone}${profile.linkedinUrl ? ` | ${profile.linkedinUrl}` : ''}`,
    '',
    `TARGET POSITION: ${tailored.headline || profile.headline}`,
    '',
    '=== EXECUTIVE SUMMARY ===',
    tailored.summary,
    '',
    '=== CORE COMPETENCIES ===',
    (tailored.coreCompetencies || []).join(' • '),
    '',
  ];

  if (tailored.selectedAchievements && tailored.selectedAchievements.length > 0) {
    lines.push('=== KEY ACHIEVEMENTS ===');
    tailored.selectedAchievements.forEach((ach) => lines.push(`• ${ach}`));
    lines.push('');
  }

  lines.push('=== PROFESSIONAL EXPERIENCE ===');
  tailored.experience.forEach((exp) => {
    lines.push(`${exp.originalCompany} | ${exp.originalTitle} | ${exp.dates}`);
    exp.bullets.forEach((b) => {
      const txt = b.status === 'original' ? b.originalText : b.tailoredText || b.originalText;
      lines.push(`• ${txt}`);
    });
    lines.push('');
  });

  lines.push('=== EDUCATION & CREDENTIALS ===');
  (profile.education || []).forEach((e) => {
    lines.push(`${e.degree} in ${e.field} - ${e.institution} (${e.graduationYear})`);
  });
  (profile.certifications || []).forEach((c) => {
    lines.push(`• ${c.name} - ${c.issuer} ${c.year ? `(${c.year})` : ''}`);
  });

  const fullText = lines.join('\n');
  const blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${profile.fullName.replace(/\s+/g, '_')}_ATS_Resume.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function printFormattedDocument(elementId: string, title: string) {
  const element = document.getElementById(elementId);
  if (!element) return;

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    window.print();
    return;
  }

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>${title}</title>
        <style>
          @page { margin: 15mm; }
          body {
            font-family: Calibri, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            color: #1A202C;
            line-height: 1.5;
            padding: 10px;
            font-size: 13px;
          }
          h1, h2, h3 { color: #1A365D; margin-top: 12px; margin-bottom: 6px; }
          h1 { font-size: 20px; text-align: center; }
          h2 { font-size: 14px; border-bottom: 1.5px solid #2B6CB0; padding-bottom: 3px; text-transform: uppercase; }
          .header-meta { text-align: center; font-size: 11px; color: #4A5568; margin-bottom: 15px; }
          .headline { text-align: center; font-weight: bold; color: #2B6CB0; margin-bottom: 15px; font-size: 14px; }
          .exp-header { font-weight: bold; display: flex; justify-content: space-between; margin-top: 10px; }
          ul { margin-top: 4px; margin-bottom: 8px; padding-left: 20px; }
          li { margin-bottom: 3px; }
          @media print {
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        ${element.innerHTML}
      </body>
    </html>
  `);
  printWindow.document.close();
  printWindow.focus();
  setTimeout(() => {
    printWindow.print();
    printWindow.close();
  }, 250);
}
