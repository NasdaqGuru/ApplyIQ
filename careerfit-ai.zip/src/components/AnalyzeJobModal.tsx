import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Link as LinkIcon,
  FileText,
  Building,
  AlertCircle,
  RefreshCw,
  Zap,
  Globe,
  Briefcase,
} from 'lucide-react';
import { CandidateProfile, FullJobAnalysis, JobPosting } from '../types';
import { sampleJobs } from '../data/sampleJobs';

interface AnalyzeJobModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: CandidateProfile;
  onAnalysisComplete: (analysis: FullJobAnalysis) => void;
}

export const AnalyzeJobModal: React.FC<AnalyzeJobModalProps> = ({
  isOpen,
  onClose,
  profile,
  onAnalysisComplete,
}) => {
  if (!isOpen) return null;

  const [inputMode, setInputMode] = useState<'url' | 'paste' | 'preset'>('url');
  const [jobUrl, setJobUrl] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [employer, setEmployer] = useState('');
  const [location, setLocation] = useState('');
  const [state, setState] = useState('CA');
  const [numberOfOpenings, setNumberOfOpenings] = useState<number>(1);
  const [applicantCount, setApplicantCount] = useState<number>(20);
  const [descriptionText, setDescriptionText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Handle Preset Selection
  const handleSelectPreset = (sample: typeof sampleJobs[0]) => {
    setJobTitle(sample.jobTitle);
    setEmployer(sample.employer);
    setLocation(sample.location || '');
    setState(sample.state || 'CA');
    setNumberOfOpenings(sample.numberOfOpenings || 1);
    setApplicantCount(sample.applicantCount || 20);
    setDescriptionText(sample.description);
    setInputMode('paste');
  };

  // Run full extraction and analysis
  const handleAnalyze = async () => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      let finalJob: JobPosting;

      if (inputMode === 'url') {
        if (!jobUrl.trim()) {
          throw new Error('Please enter a valid job posting URL.');
        }

        setStatusMessage('Extracting job details from URL with Google Search...');
        const extractRes = await fetch('/api/extract-job-url', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: jobUrl }),
        });

        if (!extractRes.ok) {
          throw new Error(`Failed to extract job from URL: ${extractRes.statusText}`);
        }

        const extracted = await extractRes.json();
        finalJob = {
          id: `job-${Date.now()}`,
          jobTitle: extracted.jobTitle || 'Target Role',
          employer: extracted.employer || 'Employer',
          location: extracted.location || '',
          state: extracted.state || state || 'CA',
          numberOfOpenings: extracted.numberOfOpenings || numberOfOpenings || 1,
          applicantCount: extracted.applicantCount || applicantCount || 25,
          url: jobUrl,
          description: extracted.description || '',
          salaryRange: extracted.salaryRange || '',
          department: extracted.department || '',
        };
      } else {
        if (!jobTitle.trim() || !employer.trim() || !descriptionText.trim()) {
          throw new Error('Please provide Job Title, Employer, and Job Description.');
        }

        finalJob = {
          id: `job-${Date.now()}`,
          jobTitle,
          employer,
          location,
          state,
          numberOfOpenings,
          applicantCount,
          description: descriptionText,
        };
      }

      setStatusMessage('Executing 8-part weighted ATS & qualification audit with Gemini...');
      const analyzeRes = await fetch('/api/analyze-job', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          job: finalJob,
          profile,
        }),
      });

      if (!analyzeRes.ok) {
        throw new Error(`Analysis failed: ${analyzeRes.statusText}`);
      }

      const fullAnalysis: FullJobAnalysis = await analyzeRes.json();
      onAnalysisComplete(fullAnalysis);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'An error occurred during analysis.');
    } finally {
      setIsLoading(false);
      setStatusMessage('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-100 dark:border-blue-900/40">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Analyze Target Opportunity
              </h2>
              <p className="text-[11px] text-slate-400">
                Grounded against {profile.fullName}'s Master Career Profile
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isLoading}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input Mode Selector */}
        <div className="p-5 space-y-4 text-xs text-slate-700 dark:text-slate-300">
          <div className="flex bg-slate-100 dark:bg-slate-800/80 p-1 rounded-lg text-xs font-medium">
            <button
              onClick={() => setInputMode('url')}
              className={`flex-1 py-1.5 rounded-md flex items-center justify-center gap-1.5 transition text-xs ${
                inputMode === 'url'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              Job URL
            </button>
            <button
              onClick={() => setInputMode('paste')}
              className={`flex-1 py-1.5 rounded-md flex items-center justify-center gap-1.5 transition text-xs ${
                inputMode === 'paste'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              Paste Description
            </button>
            <button
              onClick={() => setInputMode('preset')}
              className={`flex-1 py-1.5 rounded-md flex items-center justify-center gap-1.5 transition text-xs ${
                inputMode === 'preset'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              Sample Roles
            </button>
          </div>

          {/* MODE 1: JOB POSTING URL */}
          {inputMode === 'url' && (
            <div className="space-y-3">
              <div>
                <label className="font-semibold text-slate-900 dark:text-white block mb-1 text-xs">
                  Job Posting URL (LinkedIn, Greenhouse, Lever, Indeed, Company Site):
                </label>
                <div className="relative">
                  <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="url"
                    value={jobUrl}
                    onChange={(e) => setJobUrl(e.target.value)}
                    placeholder="https://boards.greenhouse.io/company/jobs/123456"
                    className="w-full pl-9 pr-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 rounded-lg text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">
                Gemini uses Google Search grounding to retrieve the exact requirements, responsibilities, compensation, and qualifications directly from the source page.
              </div>
            </div>
          )}

          {/* MODE 2: PASTE JOB DESCRIPTION */}
          {inputMode === 'paste' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="font-semibold text-slate-900 dark:text-white block mb-1 text-xs">
                    Job Title *
                  </label>
                  <input
                    type="text"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    placeholder="e.g. VP of Engineering"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-900 dark:text-white block mb-1 text-xs">
                    Company / Employer *
                  </label>
                  <input
                    type="text"
                    value={employer}
                    onChange={(e) => setEmployer(e.target.value)}
                    placeholder="e.g. Stripe, Airbnb"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-900 dark:text-white block mb-1 text-xs">
                    Location
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. San Francisco, CA"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-100 dark:border-slate-800">
                <div>
                  <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                    State / Region
                  </label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none"
                  >
                    <option value="CA">California (CA)</option>
                    <option value="NY">New York (NY)</option>
                    <option value="MA">Massachusetts (MA)</option>
                    <option value="TX">Texas (TX)</option>
                    <option value="WA">Washington (WA)</option>
                    <option value="IL">Illinois (IL)</option>
                    <option value="CO">Colorado (CO)</option>
                    <option value="Remote">Remote / Nationwide</option>
                  </select>
                </div>

                <div>
                  <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                    # of Current Openings
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={numberOfOpenings}
                    onChange={(e) => setNumberOfOpenings(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-medium text-slate-700 dark:text-slate-300 block mb-1 text-[11px]">
                    Applicants Applied (LinkedIn)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={1000}
                    value={applicantCount}
                    onChange={(e) => setApplicantCount(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-900 dark:text-white block mb-1 text-xs">
                  Full Job Description Text *
                </label>
                <textarea
                  value={descriptionText}
                  onChange={(e) => setDescriptionText(e.target.value)}
                  rows={6}
                  placeholder="Paste the full job description text with requirements and responsibilities..."
                  className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white leading-relaxed text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* MODE 3: PRESET SAMPLE ROLES */}
          {inputMode === 'preset' && (
            <div className="space-y-2.5">
              <span className="font-semibold text-slate-900 dark:text-white block text-xs">
                Choose a pre-configured sample target role:
              </span>
              <div className="grid grid-cols-1 gap-2">
                {sampleJobs.map((sample) => (
                  <button
                    key={sample.id}
                    onClick={() => handleSelectPreset(sample)}
                    className="p-3 text-left rounded-lg border border-slate-200 dark:border-slate-700 hover:border-blue-500 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-blue-50/40 dark:hover:bg-blue-950/20 transition flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-white text-xs">
                        {sample.jobTitle}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {sample.employer} • {sample.location}
                      </div>
                    </div>
                    <span className="px-2.5 py-1 rounded bg-blue-600 text-white font-medium text-[10px]">
                      Select Preset
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Error display */}
          {errorMessage && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Loading status message */}
          {isLoading && (
            <div className="p-3.5 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 text-blue-700 dark:text-blue-300 text-xs flex items-center gap-3">
              <RefreshCw className="w-4 h-4 animate-spin flex-shrink-0" />
              <div className="space-y-0.5">
                <div className="font-semibold">Analyzing Opportunity...</div>
                <div className="text-slate-500 dark:text-slate-400 text-[11px]">{statusMessage}</div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30">
          <button
            onClick={onClose}
            disabled={isLoading}
            className="px-3 py-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-900"
          >
            Cancel
          </button>

          <button
            onClick={handleAnalyze}
            disabled={isLoading}
            className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-1.5 shadow-xs transition"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                Auditing Fit...
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                Run AI Match Analysis
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
