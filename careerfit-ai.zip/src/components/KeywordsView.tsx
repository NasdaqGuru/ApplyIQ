import React, { useState } from 'react';
import {
  Tag,
  ShieldCheck,
  Search,
} from 'lucide-react';
import { ATSKeywordItem, FullJobAnalysis } from '../types';

interface KeywordsViewProps {
  analysis: FullJobAnalysis;
}

export const KeywordsView: React.FC<KeywordsViewProps> = ({ analysis }) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const keywords = analysis.keywords || [];

  const categories = [
    'ALL',
    'Already Present',
    'Present but Underused',
    'Missing but Supported',
    'Missing and NOT Supported',
  ];

  const filtered = keywords.filter((k) => {
    const matchesSearch = !search || k.keyword.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'ALL' || k.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryBadge = (cat: ATSKeywordItem['category']) => {
    switch (cat) {
      case 'Already Present':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-green-50 dark:bg-green-950/40 text-green-700 dark:text-green-300 border border-green-100 dark:border-green-800">
            Already Present
          </span>
        );
      case 'Present but Underused':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
            Present but Underused
          </span>
        );
      case 'Missing but Supported':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-100 dark:border-purple-800">
            Missing but Supported
          </span>
        );
      case 'Missing and NOT Supported':
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-100 dark:border-rose-800">
            Missing & Unsupported (Do Not Add)
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Tag className="w-4 h-4 text-blue-600" />
                ATS Keyword Intelligence & Density Matrix
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
                {keywords.length} Tracked Keywords
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Categorizes employer terminology and guards against keyword stuffing.
            </p>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300">
            <ShieldCheck className="w-4 h-4 text-green-500" />
            <span>Keyword Stuffing QA: <strong>PASS (Natural Distribution)</strong></span>
          </div>
        </div>

        {/* 4 Category Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-3.5 rounded-xl border border-green-100 dark:border-green-900/40 bg-green-50/40 dark:bg-green-950/20">
            <span className="text-[10px] font-bold text-green-800 dark:text-green-300 block uppercase tracking-wider">
              Already Present
            </span>
            <div className="text-xl font-bold text-green-900 dark:text-green-200 mt-0.5">
              {keywords.filter((k) => k.category === 'Already Present').length}
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-blue-100 dark:border-blue-900/40 bg-blue-50/40 dark:bg-blue-950/20">
            <span className="text-[10px] font-bold text-blue-800 dark:text-blue-300 block uppercase tracking-wider">
              Underused
            </span>
            <div className="text-xl font-bold text-blue-900 dark:text-blue-200 mt-0.5">
              {keywords.filter((k) => k.category === 'Present but Underused').length}
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-purple-100 dark:border-purple-900/40 bg-purple-50/40 dark:bg-purple-950/20">
            <span className="text-[10px] font-bold text-purple-800 dark:text-purple-300 block uppercase tracking-wider">
              Missing (Supported)
            </span>
            <div className="text-xl font-bold text-purple-900 dark:text-purple-200 mt-0.5">
              {keywords.filter((k) => k.category === 'Missing but Supported').length}
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-rose-100 dark:border-rose-900/40 bg-rose-50/40 dark:bg-rose-950/20">
            <span className="text-[10px] font-bold text-rose-800 dark:text-rose-300 block uppercase tracking-wider">
              Missing (Unsupported)
            </span>
            <div className="text-xl font-bold text-rose-900 dark:text-rose-200 mt-0.5">
              {keywords.filter((k) => k.category === 'Missing and NOT Supported').length}
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-1 text-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-md transition text-xs font-medium ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white font-bold shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search keyword..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Frequency Comparison Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-100 dark:border-slate-800">
              <tr>
                <th className="p-3.5">Target Keyword</th>
                <th className="p-3.5">Classification</th>
                <th className="p-3.5 text-center">Job Frequency</th>
                <th className="p-3.5 text-center">Original Resume</th>
                <th className="p-3.5 text-center">Tailored Resume</th>
                <th className="p-3.5">Optimization Recommendation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((k, idx) => (
                <tr key={idx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition">
                  <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                    {k.keyword}
                  </td>
                  <td className="p-3.5">
                    {getCategoryBadge(k.category)}
                  </td>
                  <td className="p-3.5 text-center font-bold text-slate-800 dark:text-slate-200">
                    {k.jobCount}x
                  </td>
                  <td className="p-3.5 text-center text-slate-500">
                    {k.originalCount}x
                  </td>
                  <td className="p-3.5 text-center font-bold text-green-600 dark:text-green-400">
                    {k.tailoredCount}x
                  </td>
                  <td className="p-3.5 text-slate-600 dark:text-slate-300">
                    {k.recommendation}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filtered.length === 0 && (
            <div className="p-8 text-center text-slate-400">
              No keywords match the search filter.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

