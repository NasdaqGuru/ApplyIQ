import React, { useState } from 'react';
import {
  MessageSquare,
  Sparkles,
  Clock,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { CandidateProfile, FullJobAnalysis } from '../types';

interface InterviewPrepViewProps {
  profile: CandidateProfile;
  analysis: FullJobAnalysis;
}

export const InterviewPrepView: React.FC<InterviewPrepViewProps> = ({
  analysis,
}) => {
  const prep = analysis.interviewPrep;
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);
  const [activeTab, setActiveTab] = useState<'questions' | 'pitches' | 'ask-manager' | 'themes'>('questions');

  return (
    <div className="space-y-6 font-sans">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-5 sm:p-6 shadow-xs border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              Executive Interview Simulator
            </span>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Competitiveness: {analysis.scores.interview.score}/100 ({analysis.scores.interview.tier})
            </span>
          </div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">
            Interview Intelligence & STAR Mastery
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 max-w-xl leading-relaxed">
            10 role-specific questions with evidence-based STAR stories drawn strictly from your documented career achievements.
          </p>
        </div>

        {/* Quick Subnav Tabs */}
        <div className="flex flex-wrap gap-1.5 bg-slate-50 dark:bg-slate-800/80 p-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs">
          <button
            onClick={() => setActiveTab('questions')}
            className={`px-3 py-1.5 rounded-md transition font-medium text-xs ${
              activeTab === 'questions' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-semibold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            10 Likely Questions
          </button>
          <button
            onClick={() => setActiveTab('pitches')}
            className={`px-3 py-1.5 rounded-md transition font-medium text-xs ${
              activeTab === 'pitches' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-semibold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Pitches & Core Answers
          </button>
          <button
            onClick={() => setActiveTab('ask-manager')}
            className={`px-3 py-1.5 rounded-md transition font-medium text-xs ${
              activeTab === 'ask-manager' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-semibold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Questions to Ask
          </button>
          <button
            onClick={() => setActiveTab('themes')}
            className={`px-3 py-1.5 rounded-md transition font-medium text-xs ${
              activeTab === 'themes' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-semibold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Executive Themes
          </button>
        </div>
      </div>

      {/* TAB 1: 10 LIKELY QUESTIONS & STAR STORIES */}
      {activeTab === 'questions' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between pb-1">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Target Interview Questions & Grounded STAR Stories
            </h3>
            <span className="text-[11px] text-slate-400">
              Click to expand STAR breakdown
            </span>
          </div>

          <div className="space-y-2.5">
            {(prep.likelyQuestions || []).map((item, idx) => {
              const isExpanded = expandedIndex === idx;
              return (
                <div
                  key={idx}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden transition"
                >
                  <button
                    onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                    className="w-full p-3.5 sm:p-4 text-left flex items-start justify-between gap-3 hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition"
                  >
                    <div className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                            {item.category || 'Competency'}
                          </span>
                        </div>
                        <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1">
                          {item.question}
                        </h4>
                      </div>
                    </div>

                    <div className="text-slate-400 mt-1">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </button>

                  {isExpanded && (
                    <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-800/10 space-y-3.5 text-xs">
                      {/* Why Asked & Strategy */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="p-3 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                          <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                            Why the Hiring Manager Asks This:
                          </span>
                          <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]">
                            {item.whyAsked}
                          </p>
                        </div>
                        <div className="p-3 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                          <span className="font-bold text-blue-600 dark:text-blue-400 block mb-1">
                            Recommended Strategy:
                          </span>
                          <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]">
                            {item.recommendedStrategy}
                          </p>
                        </div>
                      </div>

                      {/* STAR STORY */}
                      {item.candidateStarStory && (
                        <div className="p-3.5 bg-white dark:bg-slate-800 rounded-lg border border-blue-100 dark:border-blue-900/40 space-y-2">
                          <div className="flex items-center gap-1.5 text-xs font-bold text-blue-700 dark:text-blue-300">
                            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                            <span>Candidate STAR Response (Truthfully Grounded in Master Profile)</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                            <div className="p-2.5 rounded-md bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
                              <span className="font-bold text-slate-900 dark:text-white block mb-0.5 text-[11px]">
                                [S] Situation:
                              </span>
                              <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                                {item.candidateStarStory.situation}
                              </p>
                            </div>

                            <div className="p-2.5 rounded-md bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
                              <span className="font-bold text-slate-900 dark:text-white block mb-0.5 text-[11px]">
                                [T] Task:
                              </span>
                              <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                                {item.candidateStarStory.task}
                              </p>
                            </div>

                            <div className="p-2.5 rounded-md bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
                              <span className="font-bold text-slate-900 dark:text-white block mb-0.5 text-[11px]">
                                [A] Action:
                              </span>
                              <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                                {item.candidateStarStory.action}
                              </p>
                            </div>

                            <div className="p-2.5 rounded-md bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
                              <span className="font-bold text-green-600 dark:text-green-400 block mb-0.5 text-[11px]">
                                [R] Result (Grounded Metrics):
                              </span>
                              <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                                {item.candidateStarStory.result}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: PITCHES & CORE ANSWERS */}
      {activeTab === 'pitches' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* 30-Second Elevator Pitch */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-xs space-y-2.5">
            <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-bold text-xs">
              <Clock className="w-3.5 h-3.5" />
              <span>30-Second Elevator Pitch</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
              "{prep.intro30Sec}"
            </p>
            <div className="text-[11px] text-slate-400">
              Ideal for initial greetings, recruiter phone screens, and networking openings.
            </div>
          </div>

          {/* 90-Second "Tell Me About Yourself" */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-xs space-y-2.5">
            <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-bold text-xs">
              <MessageSquare className="w-3.5 h-3.5" />
              <span>90-Second "Tell Me About Yourself" Narrative</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
              "{prep.tellMeAboutYourself90Sec}"
            </p>
            <div className="text-[11px] text-slate-400">
              Connects past career trajectory directly to this employer's current inflection point.
            </div>
          </div>

          {/* Why This Organization? */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-xs space-y-2.5">
            <div className="font-bold text-xs text-slate-900 dark:text-white">
              Why {analysis.job.employer}?
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
              "{prep.whyThisOrganization}"
            </p>
          </div>

          {/* Why Should We Hire You? */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-xs space-y-2.5">
            <div className="font-bold text-xs text-slate-900 dark:text-white">
              Why Should We Hire You? (Value Proposition)
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
              "{prep.whyHireYou}"
            </p>
          </div>
        </div>
      )}

      {/* TAB 3: QUESTIONS TO ASK THE HIRING MANAGER */}
      {activeTab === 'ask-manager' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              High-Impact Strategic Questions to Ask the Hiring Team
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Demonstrates strategic foresight, operational depth, and proactive leadership.
            </p>
          </div>

          <div className="space-y-2">
            {(prep.questionsToAsk || []).map((q, idx) => (
              <div
                key={idx}
                className="flex items-start gap-2.5 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs"
              >
                <span className="w-5 h-5 rounded-md bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-bold flex items-center justify-center flex-shrink-0 text-[10px]">
                  {idx + 1}
                </span>
                <span className="font-medium text-slate-800 dark:text-slate-200 leading-relaxed text-[11px]">
                  "{q}"
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: EXECUTIVE INTERVIEW THEMES */}
      {activeTab === 'themes' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Executive Positioning Themes & Core Narrative Anchors
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Key thematic talking points to reinforce throughout all interview rounds.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
            {(prep.executiveThemes || []).map((theme, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-1.5 text-xs"
              >
                <div className="w-6 h-6 rounded-md bg-blue-600 text-white font-bold flex items-center justify-center text-[10px]">
                  #{idx + 1}
                </div>
                <h4 className="font-semibold text-xs text-slate-900 dark:text-white">
                  {theme}
                </h4>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

