import React from 'react';
import {
  UserCheck,
  Eye,
  CheckCircle2,
  HelpCircle,
  TrendingUp,
  ThumbsUp,
  Sparkles,
} from 'lucide-react';
import { FullJobAnalysis } from '../types';

interface HiringRecruiterViewProps {
  analysis: FullJobAnalysis;
}

export const HiringRecruiterView: React.FC<HiringRecruiterViewProps> = ({ analysis }) => {
  const { hiringManagerView, recruiterTest } = analysis;

  return (
    <div className="space-y-6 font-sans">
      {/* SECTION 1: RECRUITER 10-SECOND TEST */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-100 dark:border-blue-800">
              <Eye className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Recruiter's 10-Second Initial Scan Test
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Simulating how a talent acquisition screener evaluates your profile within the first 10 seconds.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Continue reading?</span>
            <span
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wide uppercase border ${
                recruiterTest.continueReading === 'YES'
                  ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-300 border-green-200 dark:border-green-800'
                  : recruiterTest.continueReading === 'MAYBE'
                  ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                  : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200 dark:border-rose-800'
              }`}
            >
              {recruiterTest.continueReading}
            </span>
          </div>
        </div>

        {/* First Impression & Key 5 Takeaways */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 space-y-2">
            <span className="font-bold text-slate-900 dark:text-white block text-xs">
              ⚡ Initial 10-Second Impression:
            </span>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-xs">
              "{recruiterTest.firstImpression}"
            </p>
          </div>

          <div className="md:col-span-2 p-4 bg-slate-50/60 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 space-y-2">
            <span className="font-bold text-slate-900 dark:text-white block text-xs">
              📋 Top 5 Instant Recruiter Takeaways:
            </span>
            <ul className="space-y-1.5 text-slate-700 dark:text-slate-300">
              {(recruiterTest.keyTakeaways || []).map((t, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                  <span className="leading-relaxed text-xs">{t}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* SECTION 2: IF I WERE THE HIRING MANAGER */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-100 dark:border-blue-800">
            <UserCheck className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              If I Were the Hiring Manager (Department Lead Lens)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Deep operational perspective on why you should be interviewed, potential risks, and optimization advice.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Column 1: Why I would interview you */}
          <div className="p-4 rounded-xl border border-green-100 dark:border-green-900/30 bg-green-50/30 dark:bg-green-950/10 space-y-3">
            <div className="flex items-center gap-1.5 font-bold text-green-900 dark:text-green-200 text-xs">
              <ThumbsUp className="w-3.5 h-3.5 text-green-600" />
              <span>Why I Would Interview You</span>
            </div>
            <ul className="space-y-2 text-slate-700 dark:text-slate-300">
              {(hiringManagerView.whyInterview || []).map((point, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-200 text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed text-xs">{point}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 2: Questions I would have */}
          <div className="p-4 rounded-xl border border-amber-100 dark:border-amber-900/30 bg-amber-50/30 dark:bg-amber-950/10 space-y-3">
            <div className="flex items-center gap-1.5 font-bold text-amber-900 dark:text-amber-200 text-xs">
              <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
              <span>Questions & Concerns I'd Have</span>
            </div>
            <ul className="space-y-2 text-slate-700 dark:text-slate-300">
              {(hiringManagerView.questionsAndConcerns || []).map((q, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-amber-100 dark:bg-amber-800 text-amber-800 dark:text-amber-200 text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    ?
                  </span>
                  <span className="leading-relaxed text-xs">{q}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: What would make application stronger */}
          <div className="p-4 rounded-xl border border-blue-100 dark:border-blue-900/30 bg-blue-50/30 dark:bg-blue-950/10 space-y-3">
            <div className="flex items-center gap-1.5 font-bold text-blue-900 dark:text-blue-200 text-xs">
              <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
              <span>What Would Make It Stronger</span>
            </div>
            <ul className="space-y-2 text-slate-700 dark:text-slate-300">
              {(hiringManagerView.whatMakesStronger || []).map((tip, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <Sparkles className="w-3 h-3 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="leading-relaxed text-xs">{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

