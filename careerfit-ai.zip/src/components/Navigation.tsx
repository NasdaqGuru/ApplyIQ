import React from 'react';
import {
  LayoutDashboard,
  TableProperties,
  FileText,
  Mail,
  MessageSquare,
  UserCheck,
  Tag,
  ShieldAlert,
  Briefcase,
  TrendingUp,
  User,
  Plus,
  Moon,
  Sun,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { FullJobAnalysis } from '../types';

interface NavigationProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  currentAnalysis: FullJobAnalysis | null;
  onOpenAnalyzeModal: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  opportunityCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  currentAnalysis,
  onOpenAnalyzeModal,
  isDarkMode,
  onToggleDarkMode,
  opportunityCount,
}) => {
  const navItems = [
    {
      id: 'overview',
      label: 'Dashboard Overview',
      icon: LayoutDashboard,
      badge: currentAnalysis ? `${currentAnalysis.scores.ats.ats_tailored}%` : undefined,
      badgeColor: 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-300 border-green-100 dark:border-green-800/60',
      section: 'PRIMARY FIT',
    },
    {
      id: 'requirements',
      label: 'Requirement Matrix',
      icon: TableProperties,
      badge: currentAnalysis ? `${currentAnalysis.requirements.length}` : undefined,
      badgeColor: 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 border-blue-100 dark:border-blue-800/60',
      section: 'PRIMARY FIT',
    },
    {
      id: 'resume',
      label: 'Resume & Tailoring',
      icon: FileText,
      badge: currentAnalysis ? `+${currentAnalysis.scores.ats.improvement_points}%` : undefined,
      badgeColor: 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-300 border-green-100 dark:border-green-800/60',
      section: 'PRIMARY FIT',
    },
    {
      id: 'coverletter',
      label: 'Executive Cover Letter',
      icon: Mail,
      section: 'PRIMARY FIT',
    },
    {
      id: 'interview',
      label: 'Interview Prep & STAR',
      icon: MessageSquare,
      badge: currentAnalysis ? `${currentAnalysis.scores.interview.score}/100` : undefined,
      badgeColor: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700',
      section: 'INSIGHTS & STRATEGY',
    },
    {
      id: 'hiring-manager',
      label: 'Recruiter & Hiring Lens',
      icon: UserCheck,
      section: 'INSIGHTS & STRATEGY',
    },
    {
      id: 'keywords',
      label: 'Keyword Distribution',
      icon: Tag,
      badge: currentAnalysis ? `${currentAnalysis.keywords?.length || 0}` : undefined,
      section: 'INSIGHTS & STRATEGY',
    },
    {
      id: 'dealbreakers',
      label: 'Deal Breakers & Edges',
      icon: ShieldAlert,
      badge: currentAnalysis && currentAnalysis.dealBreakers.filter(d => d.severity === 'Critical').length > 0
        ? `${currentAnalysis.dealBreakers.filter(d => d.severity === 'Critical').length} Risk`
        : undefined,
      badgeColor: 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-100 dark:border-rose-800/60',
      section: 'INSIGHTS & STRATEGY',
    },
    {
      id: 'pipeline',
      label: 'Pipeline Tracker',
      icon: Briefcase,
      badge: `${opportunityCount}`,
      badgeColor: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300',
      section: 'PORTFOLIO & CAREER',
    },
    {
      id: 'compare',
      label: 'Multi-Job Compare',
      icon: TrendingUp,
      section: 'PORTFOLIO & CAREER',
    },
    {
      id: 'career-insights',
      label: 'Career Learning',
      icon: Sparkles,
      section: 'PORTFOLIO & CAREER',
    },
    {
      id: 'profile',
      label: 'Master Profile',
      icon: User,
      section: 'PORTFOLIO & CAREER',
    },
  ];

  return (
    <aside className="w-64 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 flex flex-col h-screen border-r border-slate-200 dark:border-slate-800 flex-shrink-0 select-none z-30 font-sans">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-blue-600 dark:text-blue-400">
            CareerFit <span className="text-slate-400 font-bold">AI</span>
          </h1>
          <p className="text-[11px] text-slate-400 dark:text-slate-500 font-medium mt-0.5">
            Clean Minimalist Career Intelligence
          </p>
        </div>
      </div>

      {/* New Analysis Action Button */}
      <div className="p-4 border-b border-slate-100 dark:border-slate-800/80">
        <button
          id="btn-nav-analyze-job"
          onClick={onOpenAnalyzeModal}
          className="w-full py-2.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-xs transition active:scale-98"
        >
          <Plus className="w-4 h-4" />
          Analyze Target Job
        </button>

        {/* Active Role Mini Widget */}
        {currentAnalysis && (
          <div className="mt-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 text-xs">
            <div className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-bold tracking-wider">
              Active Target Role
            </div>
            <div className="font-semibold text-slate-900 dark:text-white truncate mt-0.5">
              {currentAnalysis.job.jobTitle}
            </div>
            <div className="text-slate-500 dark:text-slate-400 truncate text-[11px] mt-0.5">
              {currentAnalysis.job.employer}
            </div>
          </div>
        )}
      </div>

      {/* Navigation Links Scrollable */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 text-xs">
        {['PRIMARY FIT', 'INSIGHTS & STRATEGY', 'PORTFOLIO & CAREER'].map((sec) => (
          <div key={sec}>
            <div className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-3">
              {sec}
            </div>
            <nav className="space-y-1">
              {navItems.filter((i) => i.section === sec).map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition ${
                      isActive
                        ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 font-semibold'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}`} />
                      <span className="truncate text-xs font-medium">{item.label}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          isActive
                            ? 'bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800'
                            : item.badgeColor || 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      {/* Footer / User Profile & Theme Toggle */}
      <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center overflow-hidden">
            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-slate-800 text-blue-700 dark:text-blue-300 flex items-center justify-center text-xs font-bold shrink-0">
              AC
            </div>
            <div className="ml-2.5 overflow-hidden">
              <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                Alexandra Chen
              </p>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 truncate flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-500 shrink-0" />
                Verified Master Profile
              </p>
            </div>
          </div>

          <button
            onClick={onToggleDarkMode}
            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition"
            title="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </aside>
  );
};

